﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SpriteTilemapEditor
{
	class Palette
	{
		private Color[] colors = new Color[16];

		public Color this[int index]
		{
			get
			{
				if (index >= 16 || index < 0) throw new IndexOutOfRangeException("Attempt to access an invalid palette entry.");
				return colors[index];
			}
			set
			{
				if (index >= 16 || index < 0) throw new IndexOutOfRangeException("Attempt to access an invalid palette entry.");
				colors[index] = value;
			}
		}

		static public void OpenFromZSNESSaveState(string filePath, Palette[] palettes)
		{
			byte[] b = System.IO.File.ReadAllBytes(filePath);

			for (int i = 0, j = 0; i < 512; i+=2, j++)
			{
				ushort SNESColor = (ushort)((b[i + 0x619] << 8) | (b[i + 0x618]));
				palettes[j >> 4][j & 0xF] = (j & 0xF) == 0 ? Color.FromArgb(0) : FromSNES(SNESColor);
			}

		}

		static public void OpenFromYYCHRPal(string filePath, Palette[] palettes)
		{
			byte[] b = System.IO.File.ReadAllBytes(filePath);

			if (b.Length != 0x300)
				throw new Exception("The specified YY-CHR palette file was not the expected 0x300 bytes.");
			int currentPalette = 0;
			int currentIndex = 0;
			for (int i = 0; i < 0x300; i+=3)
			{
				palettes[currentPalette][currentIndex] = Color.FromArgb(b[i], b[i + 1], b[i + 2]);
				currentIndex++;
				if (currentIndex == 0x10)
				{
					currentIndex = 0;
					currentPalette++;
				}
			}
		}

		static public Color FromSNES(ushort SNESColor)
		{
			int r = (SNESColor & 0x1F), g = (SNESColor & 0x3E0) >> 5, b = SNESColor >> 10;
			
			return Color.FromArgb(r << 3, g << 3, b << 3);
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SpriteTilemapEditor
{
	public partial class Form1 : Form
	{

		int[,,] spriteGFXMap = new int[7,0x100,4];

		public Form1()
		{
			InitializeComponent();
		}

		string basePath = @"C:\Users\Matthew\Desktop\Emulation\Modification\SMW\Hack\Graphics\";

		Palette[] palettes = new Palette[0x10];

		RawGFX[] graphics = new RawGFX[4];

		private int currentPalette = 0;

		private bool loaded = false;

		private ushort currentTileIndex = 0;

		Bitmap[] currentTileGFX = new Bitmap[4];
		Point[] currentTilePos = new Point[4];

		Tilemap currentTilemap;
		Tile currentTile;

		private bool formReady = false;

		byte[] ROM;
		byte[] Header;

		string path;

		bool ignoreSelectorClicks = false;

		bool refreshGraphics = false;

		private void Init()
		{
			for (int i = 0; i < 0x10; i++)
				palettes[i] = new Palette();

			for (int i = 0; i < 4; i++)
				graphics[i] = new RawGFX();

			gfxSelector1.Value = 0;
			gfxSelector2.Value = 1;
			gfxSelector3.Value = 0x13;
			gfxSelector4.Value = 2;

			SwapGraphics(gfxSelector1, null);
			SwapGraphics(gfxSelector2, null);
			SwapGraphics(gfxSelector3, null);
			SwapGraphics(gfxSelector4, null);

			graphics[0].Palette = palettes[0];
			graphics[1].Palette = palettes[0];
			graphics[2].Palette = palettes[0];
			graphics[3].Palette = palettes[0];

			Palette.OpenFromYYCHRPal("Default.pal", palettes);

			InitTilemaps();
			SetROMToTiles();

		}

		private void numericUpDown1_ValueChanged(object sender, EventArgs e)
		{
			//pictureBox2.Refresh();
			currentPalette = (int)numericUpDown1.Value;
			if (formReady == false) return;
			graphics[0].Palette = palettes[currentPalette];
			graphics[1].Palette = palettes[currentPalette];
			graphics[2].Palette = palettes[currentPalette];
			graphics[3].Palette = palettes[currentPalette];
			refreshGraphics = true;
			//gfxBox.Refresh();
		}

		private void SwapGraphics(object sender, EventArgs e)
		{
			NumericUpDown n = (NumericUpDown)sender;
			int i = Convert.ToInt32(n.Tag);
			OpenGFX(i, (int)n.Value);
		}

		private void pictureBox2_Paint(object sender, PaintEventArgs e)
		{
			if (!formReady) return;
			for (int i = 0; i < 16; i++)
			{
				SolidBrush b = new SolidBrush(palettes[(int)numericUpDown1.Value][i]);
				e.Graphics.FillRectangle(b, i * 16, 0, i * 16 + 16, 16);
			}
		}

		private void OpenGFX(int boxNumber, int fileIndex)
		{
			string fileName = basePath + "GFX" + fileIndex.ToString("X2") + ".bin";
			graphics[boxNumber].SetData(System.IO.File.ReadAllBytes(fileName));
			graphics[boxNumber].BPP = 4;
			//gfxBox.Refresh();
			refreshGraphics = true;
		}

		private void RefreshTileBoxes()
		{
			shouldRefreshTileBox = true;
			tileBox.Refresh();
			shouldRefreshTileBox = false;
		}

		bool shouldRefreshTileBox = false;
		private void RefreshTileBox(object sender, PaintEventArgs e)
		{
			if (!shouldRefreshTileBox) return;
			if (!formReady) return;
			if (currentTile == null) return;
			if (currentTileGFX[0] == null || currentTileGFX[1] == null || currentTileGFX[2] == null || currentTileGFX[3] == null) return;
			const int size = 16;

			e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
			e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;

			Bitmap target;
			int bx, by, tx, ty;

			try
			{
				//e.Graphics.DrawImage(currentTileGFX[0], 00, 00, 32 * size, 32 * size);
				int numberOfTiles;
				if (currentTile.Size) numberOfTiles = 4; else numberOfTiles = 1;
				if (currentTile.Size) target = new Bitmap(256, 256); else target = new Bitmap(128, 128);

				

				for (int tileIndex = 0; tileIndex < numberOfTiles; tileIndex++)
					for (bx = 0; bx < 8; bx++)
						for (by = 0; by < 8; by++)
						{
							int addX = 0, addY = 0;
							if (tileIndex == 1) addX = 8;
							if (tileIndex == 2) addY = 8;
							if (tileIndex == 3) addX = addY = 8;

							tx = (bx + addX) * size;
							ty = (by + addY) * size;

							for (int i = 0; i < size; i++) for (int j = 0; j < size; j++)
								target.SetPixel(tx + i, ty + j, currentTileGFX[tileIndex].GetPixel(bx, by));
						}


					/*e.Graphics.DrawImage(currentTileGFX[0], 00, 00, 32 * size, 32 * size);
					e.Graphics.DrawImage(currentTileGFX[1], 30 * size, 00 * size, 32 * size, 32 * size);
					e.Graphics.DrawImage(currentTileGFX[2], 00 * size, 30 * size, 32 * size, 32 * size);
					e.Graphics.DrawImage(currentTileGFX[3], 30 * size, 30 * size, 32 * size, 32 * size);*/
				if (checkBox3.Checked && checkBox4.Checked && checkBox5.Checked == false) target.RotateFlip(RotateFlipType.RotateNoneFlipXY);
				else if (checkBox3.Checked) target.RotateFlip(RotateFlipType.RotateNoneFlipX);
				else if (checkBox4.Checked && checkBox5.Checked == false) target.RotateFlip(RotateFlipType.RotateNoneFlipY);
				tileBox.Image = target;
			}
			catch (Exception ex)
			{
			}
			shouldRefreshTileBox = false;
		}

		private void setCurrentTilePos(int startX, int startY)
		{
			if (!formReady) return;
			currentTilePos[0].X = startX;
			currentTilePos[0].Y = startY;

			currentTileIndex = (ushort)(currentTilePos[0].X + currentTilePos[0].Y * 0x10);

			//Text = currentTileIndex.ToString("X2");

			currentTilePos[3] = currentTilePos[2] = currentTilePos[1] = currentTilePos[0];

			currentTilePos[1].X += 1;

			currentTilePos[2].Y += 1;

			currentTilePos[3].X += 1;
			currentTilePos[3].Y += 1;

			try
			{
				for (int i = 0; i < 4; i++)
				{
					currentTilePos[i].X &= 0x0F;
					currentTilePos[i].Y &= 0x1FF;

					currentTileGFX[i] = graphics[startY >> 3].GetTile(currentTilePos[i].X + (currentTilePos[i].Y & 0x7) * 0x10);
				}
			}
			catch (Exception ex)
			{

			}

			currentTile.TileIndex = currentTileIndex;

			//RefreshTileBoxes();

			//gfxBox.Refresh();

			refreshGraphics = true;
		}

		private void gfxBox1_MouseMove(object sender, MouseEventArgs e)
		{
			if (!formReady) return;
			if (currentTile == null) return;
			if (ignoreSelectorClicks) return;
			if (currentTile.TileEditable == false) return;
			if (e.Button != System.Windows.Forms.MouseButtons.Left) return;

			setCurrentTilePos(e.X / 16, e.Y / 16);
			//currentTilemap.SetData(ROM);
		}

		private void pictureBox1_Paint(object sender, PaintEventArgs e)
		{
			try
			{
				if (!formReady) return;
				if (currentTile == null) return;
				e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
				for (int i = 0; i < 4; i++)
				{
					if (graphics[i].MainBitmap == null) return;
					e.Graphics.DrawImage(graphics[i].MainBitmap, 0, i * 128, 256, 128);
				}


				SolidBrush invalidBrush = new SolidBrush(Color.FromArgb(128, 0, 0, 0));

				if (currentTile.PropertyEditable == false)
				{
					if (currentTile.Page == true)
						e.Graphics.FillRectangle(invalidBrush, 0, 0, 256, 256);
					else
						e.Graphics.FillRectangle(invalidBrush, 0, 255, 256, 256);
				}


				Pen p = new Pen(Color.Red);
				p.Width = 2;

				if (currentTile.Size == true)
				{
					e.Graphics.DrawLine(p, currentTilePos[0].X * 16, currentTilePos[0].Y * 16, currentTilePos[0].X * 16 + 16, currentTilePos[0].Y * 16);
					e.Graphics.DrawLine(p, currentTilePos[0].X * 16, currentTilePos[0].Y * 16, currentTilePos[0].X * 16, currentTilePos[0].Y * 16 + 16);

					e.Graphics.DrawLine(p, currentTilePos[1].X * 16, currentTilePos[1].Y * 16, currentTilePos[1].X * 16 + 16, currentTilePos[1].Y * 16);
					e.Graphics.DrawLine(p, currentTilePos[1].X * 16 + 16, currentTilePos[1].Y * 16, currentTilePos[1].X * 16 + 16, currentTilePos[1].Y * 16 + 16);

					e.Graphics.DrawLine(p, currentTilePos[2].X * 16, currentTilePos[2].Y * 16, currentTilePos[2].X * 16, currentTilePos[2].Y * 16 + 16);
					e.Graphics.DrawLine(p, currentTilePos[2].X * 16, currentTilePos[2].Y * 16 + 16, currentTilePos[2].X * 16 + 16, currentTilePos[2].Y * 16 + 16);

					e.Graphics.DrawLine(p, currentTilePos[3].X * 16 + 16, currentTilePos[3].Y * 16, currentTilePos[3].X * 16 + 16, currentTilePos[3].Y * 16 + 16);
					e.Graphics.DrawLine(p, currentTilePos[3].X * 16, currentTilePos[3].Y * 16 + 16, currentTilePos[3].X * 16 + 16, currentTilePos[3].Y * 16 + 16);
				}
				else
				{
					e.Graphics.DrawRectangle(p, currentTilePos[0].X * 16, currentTilePos[0].Y * 16, 16, 16);
				}

				//tileBox.Refresh();
				refreshGraphics = true;
			}
			catch (Exception ex)
			{

			}
		}

		private void Form1_Shown(object sender, EventArgs e)
		{
			loaded = true;
		}

		private void InitStandardSprites()
		{
			const int stdprop = 0x07F3FE;
			Tilemap Spr00 = new Tilemap("Green koopa, no shell", "Note: Tilemap is shared with all other non-blue shelless koopas.  You may change the page, however.", new Tile[] {
							new Tile("Walking 1", 0x019B8C, stdprop + 0, true),
							new Tile("Walking 2", 0x019B8D, stdprop + 0, true),
							new Tile("Walking 3", 0x019B8E, stdprop + 0, true),
							new Tile("Unused?", 0x019B8F, stdprop + 0, true),
							new Tile("Kicking", 0x019B90, stdprop + 0, true),
							new Tile("Sliding 1", 0x019B91, stdprop + 0, true),
							new Tile("Sliding 2", 0x019B92, stdprop + 0, true),
							new Tile("Sliding 3", 0x0189F5, stdprop + 0, true),
							new Tile("Flattened", 0x01E729, stdprop + 0, 0x01E753)});


			Tilemap Spr01 = new Tilemap("Red koopa, no shell", "Note: Tilemap is shared with all other non-blue shelless koopas.  You may change the page, however.", new Tile[] {
							new Tile("Walking 1", 0x019B8C, stdprop + 1, true),
							new Tile("Walking 2", 0x019B8D, stdprop + 1, true),
							new Tile("Walking 3", 0x019B8E, stdprop + 1, true),
							new Tile("Unused?", 0x019B8F, stdprop + 1, true),
							new Tile("Kicking", 0x019B90, stdprop + 1, true),
							new Tile("Sliding 6", 0x019B91, stdprop + 1, true),
							new Tile("Sliding 7", 0x019B92, stdprop + 1, true),
							new Tile("Sliding 8", 0x0189F5, stdprop + 1, true),
							new Tile("Flattened", 0x01E729, stdprop + 0, 0x01E753)});


			Tilemap Spr02 = new Tilemap("Blue koopa, no shell", "", new Tile[] {
							new Tile("Walking 1", 0x019B93, stdprop + 2, true),
							new Tile("Walking 2", 0x019B94, stdprop + 2, true),
							new Tile("Walking 3", 0x019B95, stdprop + 2, true),
							new Tile("Unused?", 0x019B96, stdprop + 2, true),
							new Tile("Kicking", 0x019B97, stdprop + 2, true),
							new Tile("Sliding 6", 0x019B98, stdprop + 2, true),
							new Tile("Sliding 7", 0x019B99, stdprop + 2, true),
							new Tile("Sliding 8", 0x0189ED, stdprop + 2, true),
							new Tile("Flattened", 0x01E729, stdprop + 0, 0x01E753)});


			Tilemap Spr03 = new Tilemap("Yellow koopa, no shell", "Note: Tilemap is shared with all other non-blue shelless koopas.  You may change the page, however.", new Tile[] {
							new Tile("Walking 1", 0x019B8C, stdprop + 3, true),
							new Tile("Walking 2", 0x019B8D, stdprop + 3, true),
							new Tile("Walking 3", 0x019B8E, stdprop + 3, true),
							new Tile("Unused?", 0x019B8F, stdprop + 3, true),
							new Tile("Kicking", 0x019B90, stdprop + 3, true),
							new Tile("Sliding 6", 0x019B91, stdprop + 3, true),
							new Tile("Sliding 7", 0x019B92, stdprop + 3, true),
							new Tile("Sliding 8", 0x0189F5, stdprop + 3, true),
							new Tile("Flattened", 0x01E729, stdprop + 0, 0x01E753)});

			Tilemap Spr04 = new Tilemap("Green koopa", "Note: Tilemap is shared with all other koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 4, true),
							new Tile("Body 1",  0x019B84, stdprop + 4, true),
							new Tile("Head 2",  0x019B85, stdprop + 4, true),
							new Tile("Body 2",  0x019B86, stdprop + 4, true),
							new Tile("Head 3",  0x019B87, stdprop + 4, true),
							new Tile("Body 3",  0x019B88, stdprop + 4, true),

							new Tile("Shell 1",  0x019B89, stdprop + 4, true),
							new Tile("Shell 2",  0x019B8A, stdprop + 4, true),
							new Tile("Shell 3",  0x019B8B, stdprop + 4, true),
							new Tile("Open eye", 0x019881, -1, 0x01989F),
							new Tile("Closed eye", 0x019889, -1, 0x01989F)});

			Tilemap Spr05 = new Tilemap("Red koopa", "Note: Tilemap is shared with all other koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 5, true),
							new Tile("Body 1",  0x019B84, stdprop + 5, true),
							new Tile("Head 2",  0x019B85, stdprop + 5, true),
							new Tile("Body 2",  0x019B86, stdprop + 5, true),
							new Tile("Head 3",  0x019B87, stdprop + 5, true),
							new Tile("Body 3",  0x019B88, stdprop + 5, true),

							new Tile("Shell 1",  0x019B89, stdprop + 5, true),
							new Tile("Shell 2",  0x019B8A, stdprop + 5, true),
							new Tile("Shell 3",  0x019B8B, stdprop + 5, true),
							new Tile("Open eye", 0x019881, -1, 0x01989F),
							new Tile("Closed eye", 0x019889, -1, 0x01989F)});

			Tilemap Spr06 = new Tilemap("Blue koopa", "Note: Tilemap is shared with all other koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 6, true),
							new Tile("Body 1",  0x019B84, stdprop + 6, true),
							new Tile("Head 2",  0x019B85, stdprop + 6, true),
							new Tile("Body 2",  0x019B86, stdprop + 6, true),
							new Tile("Head 3",  0x019B87, stdprop + 6, true),
							new Tile("Body 3",  0x019B88, stdprop + 6, true),

							new Tile("Shell 1",  0x019B89, stdprop + 6, true),
							new Tile("Shell 2",  0x019B8A, stdprop + 6, true),
							new Tile("Shell 3",  0x019B8B, stdprop + 6, true),
							new Tile("Open eye", 0x019881, -1, 0x01989F),
							new Tile("Closed eye", 0x019889, -1, 0x01989F)});

			Tilemap Spr07 = new Tilemap("Yellow koopa", "Note: Tilemap is shared with all other koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 7, true),
							new Tile("Body 1",  0x019B84, stdprop + 7, true),
							new Tile("Head 2",  0x019B85, stdprop + 7, true),
							new Tile("Body 2",  0x019B86, stdprop + 7, true),
							new Tile("Head 3",  0x019B87, stdprop + 7, true),
							new Tile("Body 3",  0x019B88, stdprop + 7, true),

							new Tile("Shell 1",  0x019B89, stdprop + 7, true),
							new Tile("Shell 2",  0x019B8A, stdprop + 7, true),
							new Tile("Shell 3",  0x019B8B, stdprop + 7, true),
							new Tile("Open eye", 0x019881, -1, 0x01989F),
							new Tile("Closed eye", 0x019889, -1, 0x01989F)});

			Tilemap Spr08 = new Tilemap("Green flying parakoopa", "Note: Tilemap and wings are shared with all other (para)koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 8, true),
							new Tile("Body 1",  0x019B84, stdprop + 8, true),
							new Tile("Head 2",  0x019B85, stdprop + 8, true),
							new Tile("Body 2",  0x019B86, stdprop + 8, true),
							new Tile("Head 3",  0x019B87, stdprop + 8, true),
							new Tile("Body 3",  0x019B88, stdprop + 8, true),
							new Tile("Wings 1", 0x019E1C, 0x019E20, 0x019E24),
							new Tile("Wings 2", 0x019E1D, 0x019E21, 0x019E25),
							new Tile("Wings 3", 0x019E1E, 0x019E22, 0x019E26),
							new Tile("Wings 4", 0x019E1F, 0x019E23, 0x019E27)});

			Tilemap Spr09 = new Tilemap("Green bouncing parakoopa", "Note: Tilemap and wings are shared with all other (para)koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 9, true),
							new Tile("Body 1",  0x019B84, stdprop + 9, true),
							new Tile("Head 2",  0x019B85, stdprop + 9, true),
							new Tile("Body 2",  0x019B86, stdprop + 9, true),
							new Tile("Head 3",  0x019B87, stdprop + 9, true),
							new Tile("Body 3",  0x019B88, stdprop + 9, true),
							new Tile("Wings 1", 0x019E1C, 0x019E20, 0x019E24),
							new Tile("Wings 2", 0x019E1D, 0x019E21, 0x019E25),
							new Tile("Wings 3", 0x019E1E, 0x019E22, 0x019E26),
							new Tile("Wings 4", 0x019E1F, 0x019E23, 0x019E27)});

			Tilemap Spr0A = new Tilemap("Red vertical parakoopa", "Note: Note: Tilemap and wings are shared with all other (para)koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 0x0A, true),
							new Tile("Body 1",  0x019B84, stdprop + 0x0A, true),
							new Tile("Head 2",  0x019B85, stdprop + 0x0A, true),
							new Tile("Body 2",  0x019B86, stdprop + 0x0A, true),
							new Tile("Head 3",  0x019B87, stdprop + 0x0A, true),
							new Tile("Body 3",  0x019B88, stdprop + 0x0A, true),
							new Tile("Wings 1", 0x019E1C, 0x019E20, 0x019E24),
							new Tile("Wings 2", 0x019E1D, 0x019E21, 0x019E25),
							new Tile("Wings 3", 0x019E1E, 0x019E22, 0x019E26),
							new Tile("Wings 4", 0x019E1F, 0x019E23, 0x019E27)});

			Tilemap Spr0B = new Tilemap("Red horizontal parakoopa", "Note: Note: Tilemap and wings are shared with all other (para)koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 0x0B, true),
							new Tile("Body 1",  0x019B84, stdprop + 0x0B, true),
							new Tile("Head 2",  0x019B85, stdprop + 0x0B, true),
							new Tile("Body 2",  0x019B86, stdprop + 0x0B, true),
							new Tile("Head 3",  0x019B87, stdprop + 0x0B, true),
							new Tile("Body 3",  0x019B88, stdprop + 0x0B, true),
							new Tile("Wings 1", 0x019E1C, 0x019E20, 0x019E24),
							new Tile("Wings 2", 0x019E1D, 0x019E21, 0x019E25),
							new Tile("Wings 3", 0x019E1E, 0x019E22, 0x019E26),
							new Tile("Wings 4", 0x019E1F, 0x019E23, 0x019E27)});

			Tilemap Spr0C = new Tilemap("Yellow parakoopa", "Note: Tilemap and wings are shared with all other (para)koopas.", new Tile[] {
							new Tile("Head 1",  0x019B83, stdprop + 0x0C, true),
							new Tile("Body 1",  0x019B84, stdprop + 0x0C, true),
							new Tile("Head 2",  0x019B85, stdprop + 0x0C, true),
							new Tile("Body 2",  0x019B86, stdprop + 0x0C, true),
							new Tile("Head 3",  0x019B87, stdprop + 0x0C, true),
							new Tile("Body 3",  0x019B88, stdprop + 0x0C, true),
							new Tile("Wings 1", 0x019E1C, 0x019E20, 0x019E24),
							new Tile("Wings 2", 0x019E1D, 0x019E21, 0x019E25),
							new Tile("Wings 3", 0x019E1E, 0x019E22, 0x019E26),
							new Tile("Wings 4", 0x019E1F, 0x019E23, 0x019E27)});

			Tilemap Spr0D = new Tilemap("Bob-omb", "", new Tile[] {
							new Tile("Walking 1", 0x019BBA, stdprop + 0x0D, true),
							new Tile("Walking 2", 0x019BBB, stdprop + 0x0D, true),
							new Tile("Walking 3", 0x019BBC, stdprop + 0x0D, true),
							new Tile("Stunned"  , 0x01A1F0, stdprop + 0x0D, true)});

			Tilemap Spr0E = new Tilemap("Keyhole", "", new Tile[]  {
							new Tile("Key hole top", 0x01E251, 0x01E25B, 0x01E263),
							new Tile("Key hole bottom", 0x01E256, 0x01E25B, 0x01E263)});

			Tilemap Spr0F = new Tilemap("Goomba", "", new Tile[] {
							new Tile("Frame 1", 0x019BA8, stdprop + 0x0F, true),
							new Tile("Frame 2", 0x019BA9, stdprop + 0x0F, true),
							new Tile("Frame 3", 0x019BAA, stdprop + 0x0F, true),
							new Tile("Frame 4", 0x019BAB, stdprop + 0x0F, true)});

			Tilemap Spr10 = new Tilemap("Para-goomba (hopping)", "Body tilemap is shared with that of the normal goomba.", new Tile[] {
							new Tile("Frame 1", 0x019BA8, stdprop + 0x10, true),
							new Tile("Frame 2", 0x019BA9, stdprop + 0x10, true),
							new Tile("Frame 3", 0x019BAA, stdprop + 0x10, true),
							new Tile("Frame 4", 0x019BAB, stdprop + 0x10, true),
							new Tile("Wing 1", 0x018DE1, 0x018DE0, 0x018DE5),
							new Tile("Wing 2", 0x018DE2, 0x018DE0, 0x018DE6),
							new Tile("Wing 3", 0x018DE3, 0x018DE0, 0x018DE7),
							new Tile("Wing 4", 0x018DE4, 0x018DE0, 0x018DE8)});

			Tilemap Spr11 = new Tilemap("Buzzy beetle", "", new Tile[] {
							new Tile("Walking 1", 0x019BDD, stdprop + 0x11, true),
							new Tile("Walking 2", 0x019BDE, stdprop + 0x11, true),
							new Tile("Walking 3", 0x019BDF, stdprop + 0x11, true),

							new Tile("Shell 1", 0x019BE3, stdprop + 0x11, true),
							new Tile("Shell 2", 0x019BE4, stdprop + 0x11, true),
							new Tile("Shell 3", 0x019BE5, stdprop + 0x11, true)});

			Tilemap Spr12 = new Tilemap("Null", "Invalid sprite", new Tile[] { });

			Tilemap Spr13 = new Tilemap("Spiny", "", new Tile[] {
							new Tile("Walking 1", 0x019BCE, stdprop + 0x13, true),
							new Tile("Walking 2", 0x019BCF, stdprop + 0x13, true),
							new Tile("Walking 3", 0x019BD0, stdprop + 0x13, true)});

			Tilemap Spr14 = new Tilemap("Spiny egg", "", new Tile[] {
							new Tile("Egg 1, 1", 0x019BD1, stdprop + 0x14, false),
							new Tile("Egg 1, 2", 0x019BD2, stdprop + 0x14, false),
							new Tile("Egg 1, 3", 0x019BD3, stdprop + 0x14, false),
							new Tile("Egg 1, 4", 0x019BD4, stdprop + 0x14, false),
							new Tile("Egg 2, 1", 0x019BD5, stdprop + 0x14, false),
							new Tile("Egg 2, 2", 0x019BD6, stdprop + 0x14, false),
							new Tile("Egg 2, 3", 0x019BD7, stdprop + 0x14, false),
							new Tile("Egg 2, 4", 0x019BD8, stdprop + 0x14, false)});

			Tilemap Spr15 = new Tilemap("Cheep cheep, horizontal", "Note: The flopping frames are forced onto page 1.  This can be changed with a hex edit, but its effects will not be represented here.  All cheep cheep tiles are shared.", new Tile[] {
							new Tile("Swimming 1", 0x019C0D, stdprop + 0x15, true),
							new Tile("Swimming 2", 0x019C0E, stdprop + 0x15, true),
							new Tile("Flopping 2", 0x019C0F, false, true),
							new Tile("Flopping 2", 0x019C10, false, true)});



			Tilemap Spr16 = new Tilemap("Cheep cheep, vertical", "Note: The flopping frames are forced onto page 1.  This can be changed with a hex edit, but its effects will not be represented here.  All cheep cheep tiles are shared.", new Tile[] {
							new Tile("Swimming 1", 0x019C0D, stdprop + 0x16, true),
							new Tile("Swimming 2", 0x019C0E, stdprop + 0x16, true),
							new Tile("Flopping 2", 0x019C0F, false, true),
							new Tile("Flopping 2", 0x019C10, false, true)});

			Tilemap Spr17 = new Tilemap("Cheep cheep, flying", "Note: All cheep cheep tiles are shared.", new Tile[] {
							new Tile("Frame 1", 0x019C0D, stdprop + 0x17, true),
							new Tile("Frame 2", 0x019C0E, stdprop + 0x17, true)});

			Tilemap Spr18 = new Tilemap("Cheep cheep, jumping", "Note: All cheep cheep tiles are shared.", new Tile[] {
							new Tile("Frame 1", 0x019C0D, stdprop + 0x18, true),
							new Tile("Frame 2", 0x019C0E, stdprop + 0x18, true)});

			Tilemap Spr19 = new Tilemap("Null", "Invalid sprite", new Tile[] { });

			Tilemap Spr1A = new Tilemap("Piranha plant", "Note: Tilemaps are shared between all piranha plants.  Properties are shared between the \"classic\" plants.  Editing this may not work correctly with the piranha fix patch, though changing $018E8E and $018E94 to $07 may work instead.", new Tile[] {
							new Tile("Head 1", 0x019BBD, stdprop + 0x1A, true), 
							new Tile("Stem 1", 0x019BBE, 0x018E92, true), 
							new Tile("Head 2", 0x019BBF, stdprop + 0x1A, true), 
							new Tile("Stem 2", 0x019BC0, 0x018E92, true)});

			Tilemap Spr1B = new Tilemap("Football", "", new Tile[] {
							new Tile("Tile", 0x019BC9, stdprop + 0x1B, true)});

			Tilemap Spr1C = new Tilemap("Bullet bill", "Note: The left/right (etc.) tiles for each bullet are shared.  Their properties are not.", new Tile[] {
							new Tile("Right",      0x019BCA, 0x018FC7, true),
							new Tile("Left",       0x019BCA, 0x018FC8, true),
							new Tile("Up",         0x019BCB, 0x018FC9, true),
							new Tile("Down",       0x019BCB, 0x018FCA, true),
							new Tile("Down left",  0x019BCC, 0x018FCB, true),
							new Tile("Up left",    0x019BCC, 0x018FCC, true),
							new Tile("Up right",   0x019BCD, 0x018FCD, true),
							new Tile("Down right", 0x019BCD, 0x018FCE, true)});

			Tilemap Spr1D = new Tilemap("Hopping flame", "Note that changing the remnant flame's properties will change Mario's fireball's properties as well.", new Tile[] {
							new Tile("Frame 1", 0x019BEC, stdprop + 0x1D, true),
							new Tile("Frame 1", 0x019BED, stdprop + 0x1D, true),
							new Tile("Remnant flame 1", 0x02A217, 0x02A24C, false),
							new Tile("Remnant flame 2", 0x02A218, 0x02A24C, false)});

			Tilemap Spr1E = new Tilemap("Lakitu", "Note: The sizes for the fishing rod and the bait are shared.", new Tile[] { 
							new Tile("Normal (head)", 0x019BEE, stdprop + 0x1E, true),
							new Tile("Normal (body)", 0x019BEF, stdprop + 0x1E, true),
							new Tile("Dead (head)", 0x019BF0, stdprop + 0x1E, true),
							new Tile("Dead (body)", 0x019BF1, stdprop + 0x1E, true),
							new Tile("Throwing (head)", 0x019BF2, stdprop + 0x1E, true),
							new Tile("Throwing (body)", 0x019BF3, stdprop + 0x1E, true),
							new Tile("Fishing rod", 0x02E6A8, 0x02E6B2, 0x02E6BE),
							new Tile("Fishing line", 0x02E707, 0x02E70C, 0x02E71B),
							new Tile("Bait", 0x02E6AD, 0x02E6B7, 0x02E6BE)});

			Tilemap Spr1F = new Tilemap("Magikoopa", "", new Tile[] {
							new Tile("Frame 1", 0x019BF6, stdprop + 0x1F, true),
							new Tile("Frame 2", 0x019BF7, stdprop + 0x1F, true),
							new Tile("Frame 3", 0x019BF8, stdprop + 0x1F, true),
							new Tile("Frame 4", 0x019BF9, stdprop + 0x1F, true),
							new Tile("Frame 5", 0x019BFA, stdprop + 0x1F, true),
							new Tile("Frame 6", 0x019BFB, stdprop + 0x1F, true),
							new Tile("Frame 7", 0x019BFC, stdprop + 0x1F, true),
							new Tile("Frame 8", 0x019BFD, stdprop + 0x1F, true),
							new Tile("Frame 9", 0x019BFE, stdprop + 0x1F, true),
							new Tile("Frame 10", 0x019BFF, stdprop + 0x1F, true),
							new Tile("Frame 11", 0x019C00, stdprop + 0x1F, true),
							new Tile("Frame 12", 0x019C01, stdprop + 0x1F, true),
							new Tile("Wand", 0x01BF05, 0x01BF05, false)});

			Tilemap Spr20 = new Tilemap("Magikoopa's magic", "The tiles are shared between each shape, and the properties are shared between each frame of every shape.", new Tile[] {
							new Tile("Magic (circle), 1", 0x01BD83, 0x01BC34, 0x01BD92),
							new Tile("Magic (circle), 2", 0x01BD83, 0x01BC35, 0x01BD92),
							new Tile("Magic (circle), 3", 0x01BD83, 0x01BC36, 0x01BD92),
							new Tile("Magic (circle), 4", 0x01BD83, 0x01BC37, 0x01BD92),
							new Tile("Magic (square), 1", 0x01BD88, 0x01BC34, 0x01BD92),
							new Tile("Magic (square), 2", 0x01BD88, 0x01BC35, 0x01BD92),
							new Tile("Magic (square), 3", 0x01BD88, 0x01BC36, 0x01BD92),
							new Tile("Magic (square), 4", 0x01BD88, 0x01BC37, 0x01BD92),
							new Tile("Magic (triangle), 1", 0x01BD8D, 0x01BC34, 0x01BD92),
							new Tile("Magic (triangle), 2", 0x01BD8D, 0x01BC35, 0x01BD92),
							new Tile("Magic (triangle), 3", 0x01BD8D, 0x01BC36, 0x01BD92),
							new Tile("Magic (triangle), 4", 0x01BD8D, 0x01BC37, 0x01BD92)});

			Tilemap Spr21 = new Tilemap("Moving coin", "Note: This tilemap is shared with the directional coin.", new Tile[] {
							new Tile("Frame 1", 0x01C653, stdprop + 0x21, true),
							new Tile("Frame 2", 0x01C66D, stdprop + 0x21, false),
							new Tile("Frame 3", 0x01C66E, stdprop + 0x21, false),
							new Tile("Frame 4", 0x01C66F, stdprop + 0x21, false),
							new Tile("Coin from ? block 1", 0x029A4F, 0x029A54, 0x029A5F),
							new Tile("Coin from ? block 2", 0x029A6E, 0x029A54, 0x029A9F),
							new Tile("Coin from ? block 3", 0x029A6F, 0x029A54, 0x029A9F),
							new Tile("Coin from ? block 4", 0x029A70, 0x029A54, 0x029A9F)});

			Tilemap Spr22 = new Tilemap("Green vertical climbing net koopa", "Note: Tilemap is shared between all other climbing net koopas.", new Tile[] {
							new Tile("Frame 1", 0x019C03, stdprop + 0x22, true),
							new Tile("Frame 2", 0x019C04, stdprop + 0x22, true),
							new Tile("Frame 3", 0x019C05, stdprop + 0x22, true),
							new Tile("Frame 4", 0x019C06, stdprop + 0x22, true),
							new Tile("Frame 5", 0x019C07, stdprop + 0x22, true),
							new Tile("Frame 6", 0x019C08, stdprop + 0x22, true)});

			Tilemap Spr23 = new Tilemap("Red vertical climbing net koopa", "Note: Tilemap is shared between all other climbing net koopas.", new Tile[] {
							new Tile("Frame 1", 0x019C03, stdprop + 0x23, true),
							new Tile("Frame 2", 0x019C04, stdprop + 0x23, true),
							new Tile("Frame 3", 0x019C05, stdprop + 0x23, true),
							new Tile("Frame 4", 0x019C06, stdprop + 0x23, true),
							new Tile("Frame 5", 0x019C07, stdprop + 0x23, true),
							new Tile("Frame 6", 0x019C08, stdprop + 0x23, true)});

			Tilemap Spr24 = new Tilemap("Green horizontal climbing net koopa", "Note: Tilemap is shared between all other climbing net koopas.", new Tile[] {
							new Tile("Frame 1", 0x019C03, stdprop + 0x24, true),
							new Tile("Frame 2", 0x019C04, stdprop + 0x24, true),
							new Tile("Frame 3", 0x019C05, stdprop + 0x24, true),
							new Tile("Frame 4", 0x019C06, stdprop + 0x24, true),
							new Tile("Frame 5", 0x019C07, stdprop + 0x24, true),
							new Tile("Frame 6", 0x019C08, stdprop + 0x24, true)});

			Tilemap Spr25 = new Tilemap("Red horizontal climbing net koopa", "Note: Tilemap is shared between all other climbing net koopas.", new Tile[] {
							new Tile("Frame 1", 0x019C03, stdprop + 0x25, true),
							new Tile("Frame 2", 0x019C04, stdprop + 0x25, true),
							new Tile("Frame 3", 0x019C05, stdprop + 0x25, true),
							new Tile("Frame 4", 0x019C06, stdprop + 0x25, true),
							new Tile("Frame 5", 0x019C07, stdprop + 0x25, true),
							new Tile("Frame 6", 0x019C08, stdprop + 0x25, true)});

			Tilemap Spr26 = new Tilemap("Thwomp", "Note: The suspicious and angry face tiles share properties.", new Tile[] {
							new Tile("Top left", 0x01AF4A, 0x01AF4F, true),
							new Tile("Top right", 0x01AF4B, 0x01AF50, true),
							new Tile("Bottom left", 0x01AF4C, 0x01AF51, true),
							new Tile("Bottom right", 0x01AF4D, 0x01AF52, true),
							new Tile("Suspicious face", 0x01AF4E, 0x01AF53, true),
							new Tile("Angry face", 0x01AF8D, 0x01AF53, true)});

			Tilemap Spr27 = new Tilemap("Thwimp", "", new Tile[] {
							new Tile("Thwimp 1", 0x019C13, stdprop + 0x27, false),
							new Tile("Thwimp 2", 0x019C14, stdprop + 0x27, false),
							new Tile("Thwimp 3", 0x019C15, stdprop + 0x27, false),
							new Tile("Thwimp 4", 0x019C16, stdprop + 0x27, false)});

			Tilemap Spr28 = new Tilemap("Big boo", "Yeah, good luck with this...", new Tile[] {
							new Tile("Tile 1", 0x0382F8, stdprop + 0x28, true),
							new Tile("Tile 2", 0x0382F9, stdprop + 0x28, true),
							new Tile("Tile 3", 0x0382FA, stdprop + 0x28, true),
							new Tile("Tile 4", 0x0382FB, stdprop + 0x28, true),
							new Tile("Tile 5", 0x0382FC, stdprop + 0x28, true),
							new Tile("Tile 6", 0x0382FD, stdprop + 0x28, true),
							new Tile("Tile 7", 0x0382FE, stdprop + 0x28, true),
							new Tile("Tile 8", 0x0382FF, stdprop + 0x28, true),
							new Tile("Tile 9", 0x038300, stdprop + 0x28, true),
							new Tile("Tile 10", 0x038301, stdprop + 0x28, true),
							new Tile("Tile 11", 0x038302, stdprop + 0x28, true),
							new Tile("Tile 12", 0x038303, stdprop + 0x28, true),
							new Tile("Tile 13", 0x038304, stdprop + 0x28, true),
							new Tile("Tile 14", 0x038305, stdprop + 0x28, true),
							new Tile("Tile 15", 0x038306, stdprop + 0x28, true),
							new Tile("Tile 16", 0x038307, stdprop + 0x28, true),
							new Tile("Tile 17", 0x038308, stdprop + 0x28, true),
							new Tile("Tile 18", 0x038309, stdprop + 0x28, true),
							new Tile("Tile 19", 0x03830A, stdprop + 0x28, true),
							new Tile("Tile 20", 0x03830B, stdprop + 0x28, true),
							new Tile("Tile 21", 0x03830C, stdprop + 0x28, true),
							new Tile("Tile 22", 0x03830D, stdprop + 0x28, true),
							new Tile("Tile 23", 0x03830E, stdprop + 0x28, true),
							new Tile("Tile 24", 0x03830F, stdprop + 0x28, true),
							new Tile("Tile 25", 0x038310, stdprop + 0x28, true),
							new Tile("Tile 26", 0x038311, stdprop + 0x28, true),
							new Tile("Tile 27", 0x038312, stdprop + 0x28, true),
							new Tile("Tile 28", 0x038313, stdprop + 0x28, true),
							new Tile("Tile 29", 0x038314, stdprop + 0x28, true),
							new Tile("Tile 30", 0x038315, stdprop + 0x28, true),
							new Tile("Tile 31", 0x038316, stdprop + 0x28, true),
							new Tile("Tile 32", 0x038317, stdprop + 0x28, true),
							new Tile("Tile 33", 0x038318, stdprop + 0x28, true),
							new Tile("Tile 34", 0x038319, stdprop + 0x28, true),
							new Tile("Tile 35", 0x03831A, stdprop + 0x28, true),
							new Tile("Tile 36", 0x03831B, stdprop + 0x28, true),
							new Tile("Tile 37", 0x03831C, stdprop + 0x28, true),
							new Tile("Tile 38", 0x03831D, stdprop + 0x28, true),
							new Tile("Tile 39", 0x03831E, stdprop + 0x28, true),
							new Tile("Tile 40", 0x03831F, stdprop + 0x28, true),
							new Tile("Tile 41", 0x038320, stdprop + 0x28, true),
							new Tile("Tile 42", 0x038321, stdprop + 0x28, true),
							new Tile("Tile 43", 0x038322, stdprop + 0x28, true),
							new Tile("Tile 44", 0x038323, stdprop + 0x28, true),
							new Tile("Tile 45", 0x038324, stdprop + 0x28, true),
							new Tile("Tile 46", 0x038325, stdprop + 0x28, true),
							new Tile("Tile 47", 0x038326, stdprop + 0x28, true),
							new Tile("Tile 48", 0x038327, stdprop + 0x28, true),
							new Tile("Tile 49", 0x038328, stdprop + 0x28, true),
							new Tile("Tile 50", 0x038329, stdprop + 0x28, true),
							new Tile("Tile 51", 0x03832A, stdprop + 0x28, true),
							new Tile("Tile 52", 0x03832B, stdprop + 0x28, true),
							new Tile("Tile 53", 0x03832C, stdprop + 0x28, true),
							new Tile("Tile 54", 0x03832D, stdprop + 0x28, true),
							new Tile("Tile 55", 0x03832E, stdprop + 0x28, true),
							new Tile("Tile 56", 0x03832F, stdprop + 0x28, true),
							new Tile("Tile 57", 0x038330, stdprop + 0x28, true),
							new Tile("Tile 58", 0x038331, stdprop + 0x28, true),
							new Tile("Tile 59", 0x038332, stdprop + 0x28, true),
							new Tile("Tile 60", 0x038333, stdprop + 0x28, true),
							new Tile("Tile 61", 0x038334, stdprop + 0x28, true),
							new Tile("Tile 62", 0x038335, stdprop + 0x28, true),
							new Tile("Tile 63", 0x038336, stdprop + 0x28, true),
							new Tile("Tile 64", 0x038337, stdprop + 0x28, true),
							new Tile("Tile 65", 0x038338, stdprop + 0x28, true),
							new Tile("Tile 66", 0x038339, stdprop + 0x28, true),
							new Tile("Tile 67", 0x03833A, stdprop + 0x28, true),
							new Tile("Tile 68", 0x03833B, stdprop + 0x28, true),
							new Tile("Tile 69", 0x03833C, stdprop + 0x28, true),
							new Tile("Tile 70", 0x03833D, stdprop + 0x28, true),
							new Tile("Tile 71", 0x03833E, stdprop + 0x28, true),
							new Tile("Tile 72", 0x03833F, stdprop + 0x28, true),
							new Tile("Tile 73", 0x038340, stdprop + 0x28, true),
							new Tile("Tile 74", 0x038341, stdprop + 0x28, true),
							new Tile("Tile 75", 0x038342, stdprop + 0x28, true),
							new Tile("Tile 76", 0x038343, stdprop + 0x28, true),
							new Tile("Tile 77", 0x038344, stdprop + 0x28, true),
							new Tile("Tile 78", 0x038345, stdprop + 0x28, true),
							new Tile("Tile 79", 0x038346, stdprop + 0x28, true),
							new Tile("Tile 80", 0x038347, stdprop + 0x28, true)});

			Tilemap Spr29 = new Tilemap("Koopalings", "Unknown/not generally editable.", new Tile[] { });

			Tilemap Spr2A = new Tilemap("Upside-down piranha plant", "Note: Tilemaps are shared between all piranha plants.  Properties are shared between the \"classic\" plants.", new Tile[] {
							new Tile("Head 1", 0x019BBD, stdprop + 0x2A, true), 
							new Tile("Stem 1", 0x019BBE, 0x018E93, true), 
							new Tile("Head 2", 0x019BBF, stdprop + 0x2A, true), 
							new Tile("Stem 2", 0x019BC0, 0x018E93, true)});

			Tilemap Spr2B = new Tilemap("Sumo Bros. lightning", "Note: Flame properties are shared between all tiles.", new Tile[] {
							new Tile("Lightning 1", 0x019C79, stdprop + 0x2B, false),
							new Tile("Lightning 2", 0x019C7A, stdprop + 0x2B, false),
							new Tile("Lightning 3", 0x019C7B, stdprop + 0x2B, false),
							new Tile("Lightning 4", 0x019C7C, stdprop + 0x2B, false),
							new Tile("Flame 1", 0x02F904, 0x02F98F, true),
							new Tile("Flame 2", 0x02F905, 0x02F98F, true),
							new Tile("Flame 3", 0x02F906, 0x02F98F, true),
							new Tile("Flame 4", 0x02F907, 0x02F98F, true),
							new Tile("Flame 5", 0x02F908, 0x02F98F, true),
							new Tile("Flame 6", 0x02F909, 0x02F98F, true),
							new Tile("Unused?", 0x02F90A, 0x02F98F, true),
							new Tile("Flame 7", 0x02F90B, 0x02F98F, true)});

			Tilemap Spr2C = new Tilemap("Yoshi Egg", "", new Tile[] {
							new Tile("Normal", 0x01F794, stdprop + 0x2C, true),
							new Tile("Tile 1", 0x01F761, 0x01F75D, true),
							new Tile("Tile 2", 0x01F762, 0x01F75E, true),
							new Tile("Tile 3", 0x01F763, 0x01F75F, true),
							new Tile("Egg shard", 0x028EB2, 0x028EBC, false)});

			Tilemap Spr2D = new Tilemap("Baby Yoshi", "Unknown?", new Tile[] { });

			Tilemap Spr2E = new Tilemap("Spike top", "", new Tile[] {
							new Tile("Horizontal walking 1", 0x019BE6, stdprop + 0x2E, true),
							new Tile("Horizontal walking 2", 0x019BE7, stdprop + 0x2E, true),
							new Tile("Vertical walking 1", 0x019BE8, stdprop + 0x2E, true),
							new Tile("Vertical walking 2", 0x019BE9, stdprop + 0x2E, true),
							new Tile("Diagonal 1", 0x019BEA, stdprop + 0x2E, true),
							new Tile("Diagonal 2", 0x019BEB, stdprop + 0x2E, true)});

			Tilemap Spr2F = new Tilemap("Portable Springboard", "", new Tile[] {
							new Tile("Frame 1, 1", 0x019C1D, stdprop + 0x2F, false),
							new Tile("Frame 1, 2", 0x019C1E, stdprop + 0x2F, false),
							new Tile("Frame 1, 3", 0x019C1F, stdprop + 0x2F, false),
							new Tile("Frame 1, 4", 0x019C20, stdprop + 0x2F, false),
							new Tile("Frame 2, 1", 0x019C21, stdprop + 0x2F, false),
							new Tile("Frame 2, 2", 0x019C22, stdprop + 0x2F, false),
							new Tile("Frame 2, 3", 0x019C23, stdprop + 0x2F, false),
							new Tile("Frame 2, 4", 0x019C24, stdprop + 0x2F, false),
							new Tile("Frame 3, 1", 0x019C25, stdprop + 0x2F, false),
							new Tile("Frame 3, 2", 0x019C26, stdprop + 0x2F, false),
							new Tile("Frame 3, 3", 0x019C27, stdprop + 0x2F, false),
							new Tile("Frame 3, 4", 0x019C28, stdprop + 0x2F, false)});

			Tilemap Spr30 = new Tilemap("Dry bones (throws bones)", "Note: Tilemap is shared with the other dry bones sprite.  The crumbling sprite is shared with the bony beetle.  The thrown bones are forced onto the second page for some unknown reason.", new Tile[] {
							new Tile("Unused 1", 0x03C3CE, stdprop + 0x30, true),
							new Tile("Walking 1 (head)", 0x03C3CF, stdprop + 0x30, true),
							new Tile("Walking 1 (body)", 0x03C3D0, stdprop + 0x30, true),
							new Tile("Unused 2", 0x03C3D1, stdprop + 0x30, true),
							new Tile("Walking 2 (head)", 0x03C3D2, stdprop + 0x30, true),
							new Tile("Walking 2 (body)", 0x03C3D3, stdprop + 0x30, true),
							new Tile("Throwing (bone)", 0x03C3D4, stdprop + 0x30, true),
							new Tile("Throwing (head)", 0x03C3D5, stdprop + 0x30, true),
							new Tile("Throwing (body)", 0x03C3D6, stdprop + 0x30, true),
							
							new Tile("Crumbling 1", 0x01E454, stdprop + 0x30, true),
							new Tile("Crumbling 2", 0x01E45E, stdprop + 0x30, true),
							
							new Tile("Thrown bone 1", 0x02A2CC, 0x02A2DA, true),
							new Tile("Thrown bone 2", 0x02A2D0, 0x02A2DA, true)});

			Tilemap Spr31 = new Tilemap("Bony beetle", "The crumbling sprite is shared with the dry bones.", new Tile[] {
							new Tile("Walking 1", 0x019C2D, stdprop + 0x31, true),
							new Tile("Walking 2", 0x019C2E, stdprop + 0x31, true),
							new Tile("Shielding 1", 0x019C2F, stdprop + 0x31, true),
							new Tile("Shielding 2", 0x019C30, stdprop + 0x31, true),
							
							new Tile("Crumbling 1", 0x01E454, stdprop + 0x31, true),
							new Tile("Crumbling 2", 0x01E45E, stdprop + 0x31, true)});

			Tilemap Spr32 = new Tilemap("Dry bones (stays on ledges)", "Note: Tilemap is shared with the other dry bones sprite.  The crumbling sprite is shared with the bony beetle.  The thrown bones are forced onto the second page for some unknown reason.", new Tile[] {
							new Tile("Unused 1", 0x03C3CE, stdprop + 0x32, true),
							new Tile("Walking 1 (head)", 0x03C3CF, stdprop + 0x32, true),
							new Tile("Walking 1 (body)", 0x03C3D0, stdprop + 0x32, true),
							new Tile("Unused 2", 0x03C3D1, stdprop + 0x32, true),
							new Tile("Walking 2 (head)", 0x03C3D2, stdprop + 0x32, true),
							new Tile("Walking 2 (body)", 0x03C3D3, stdprop + 0x32, true),
							new Tile("Throwing (bone)", 0x03C3D4, stdprop + 0x32, true),
							new Tile("Throwing (head)", 0x03C3D5, stdprop + 0x32, true),
							new Tile("Throwing (body)", 0x03C3D6, stdprop + 0x32, true),
							
							new Tile("Crumbling 1", 0x01E454, stdprop + 0x32, true),
							new Tile("Crumbling 2", 0x01E45E, stdprop + 0x32, true),
							
							new Tile("Thrown bone 1", 0x02A2CC, 0x02A2DA, true),
							new Tile("Thrown bone 2", 0x02A2D0, 0x02A2DA, true)});

			Tilemap Spr33 = new Tilemap("Podoboo", "Beware changing this tilemap; it doesn't work like you may think it does...", new Tile[] {
							new Tile("Frame 1", 0x019C35, stdprop + 0x33, false),
							new Tile("Frame 2", 0x019C36, stdprop + 0x33, false),
							new Tile("Frame 3", 0x019C37, stdprop + 0x33, false),
							new Tile("Frame 4", 0x019C38, stdprop + 0x33, false),
							new Tile("Frame 5", 0x019C39, stdprop + 0x33, false),
							new Tile("Frame 6", 0x019C3A, stdprop + 0x33, false),
							new Tile("Frame 7", 0x019C3B, stdprop + 0x33, false),
							new Tile("Frame 8", 0x019C3C, stdprop + 0x33, false),
							new Tile("Frame 9", 0x019C3D, stdprop + 0x33, false),
							new Tile("Frame 10", 0x019C3E, stdprop + 0x33, false),
							new Tile("Frame 11", 0x019C3F, stdprop + 0x33, false),
							new Tile("Frame 12", 0x019C40, stdprop + 0x33, false),
							new Tile("Frame 13", 0x019C41, stdprop + 0x33, false),
							new Tile("Frame 14", 0x019C42, stdprop + 0x33, false),
							new Tile("Frame 15", 0x019C43, stdprop + 0x33, false),
							new Tile("Frame 16", 0x019C44, stdprop + 0x33, false)});

			Tilemap Spr34 = new Tilemap("Ludwig's fireball", "", new Tile[] {
							new Tile("Frame 1, 1", 0x01D446, stdprop + 0x34, true),
							new Tile("Frame 1, 2", 0x01D447, stdprop + 0x34, true),
							new Tile("Frame 2, 1", 0x01D448, stdprop + 0x34, true),
							new Tile("Frame 2, 2", 0x01D449, stdprop + 0x34, true)});

			Tilemap Spr35 = new Tilemap("Yoshi", "Only Yoshi's \"extra\" tiles are known.", new Tile[] {
							new Tile("Yoshi's throat", 0x01F08B, 0x01F097, false),
							new Tile("Yoshi's tongue, middle", 0x01F488, 0x01F494, false),
							new Tile("Yoshi's tongue, end", 0x01F48C, 0x01F494, false),
							new Tile("Yoshi's wings 1", 0x02BB17, 0x02BB1B, 0x02BB1F),
							new Tile("Yoshi's wings 2", 0x02BB18, 0x02BB1C, 0x02BB20),
							new Tile("Yoshi's wings 3", 0x02BB19, 0x02BB1D, 0x02BB21),
							new Tile("Yoshi's wings 4", 0x02BB1A, 0x02BB1E, 0x02BB22)});

			Tilemap Spr36 = new Tilemap("Null", "Invalid sprite", new Tile[] { });

			Tilemap Spr37 = new Tilemap("Boo", "", new Tile[] {
							new Tile("Boo 1, 1", 0x019C5C, stdprop + 0x37, true),
							new Tile("Boo 1, 2", 0x019C5D, stdprop + 0x37, true),
							new Tile("Boo 2, 1", 0x019C5E, stdprop + 0x37, true),
							new Tile("Boo 2, 2", 0x019C5F, stdprop + 0x37, true),
							new Tile("Boo 3, 1", 0x019C60, stdprop + 0x37, true),
							new Tile("Boo 3, 2", 0x019C61, stdprop + 0x37, true),
							new Tile("Unused?", 0x019C52, stdprop + 0x37, true),
							new Tile("Unknown 1", 0x019C63, stdprop + 0x37, true),
							new Tile("Unknown 2", 0x019C64, stdprop + 0x37, true)});

			Tilemap Spr38 = new Tilemap("Eerie", "Note: This tilemap is shared by both eeries.", new Tile[] {
							new Tile("Frame 1", 0x019C5A, stdprop + 0x38, true),
							new Tile("Frame 2", 0x019C5B, stdprop + 0x38, true)});

			Tilemap Spr39 = new Tilemap("Eerie, wave motion", "Note: This tilemap is shared by both eeries.", new Tile[] {
							new Tile("Frame 1", 0x019C5A, stdprop + 0x39, true),
							new Tile("Frame 2", 0x019C5B, stdprop + 0x39, true)});

			Tilemap Spr3A = new Tilemap("Urchin 1", "Note: These tilemaps and properties are shared between all urchins.  The two eye tiles' properties are shared.", new Tile[] {
							new Tile("Body 1", 0x02BF58, 0x02BF53, true),
							new Tile("Body 2", 0x02BF59, 0x02BF54, true),
							new Tile("Body 3", 0x02BF5A, 0x02BF55, true),
							new Tile("Body 4", 0x02BF5B, 0x02BF56, true),
							new Tile("Eyes 1", 0x02BFA3, 0x02BF57, true),
							new Tile("Eyes 2", 0x02BFA9, 0x02BF57, true)});

			Tilemap Spr3B = new Tilemap("Urchin 2", "Note: These tilemaps and properties are shared between all urchins.  The two eye tiles' properties are shared.", new Tile[] {
							new Tile("Body 1", 0x02BF58, 0x02BF53, true),
							new Tile("Body 2", 0x02BF59, 0x02BF54, true),
							new Tile("Body 3", 0x02BF5A, 0x02BF55, true),
							new Tile("Body 4", 0x02BF5B, 0x02BF56, true),
							new Tile("Eyes 1", 0x02BFA3, 0x02BF57, true),
							new Tile("Eyes 2", 0x02BFA9, 0x02BF57, true)});

			Tilemap Spr3C = new Tilemap("Urchin 3", "Note: These tilemaps and properties are shared between all urchins.  The two eye tiles' properties are shared.", new Tile[] {
							new Tile("Body 1", 0x02BF58, 0x02BF53, true),
							new Tile("Body 2", 0x02BF59, 0x02BF54, true),
							new Tile("Body 3", 0x02BF5A, 0x02BF55, true),
							new Tile("Body 4", 0x02BF5B, 0x02BF56, true),
							new Tile("Eyes 1", 0x02BFA3, 0x02BF57, true),
							new Tile("Eyes 2", 0x02BFA9, 0x02BF57, true)});

			Tilemap Spr3D = new Tilemap("Rip van fish", "Note: The properties of the \"z\" tiles are shared.", new Tile[] {
							new Tile("Swimming 1", 0x019C65, stdprop + 0x3D, true),
							new Tile("Swimming 2", 0x019C66, stdprop + 0x3D, true),
							new Tile("Slepping 1", 0x019C67, stdprop + 0x3D, true),
							new Tile("Slepping 2", 0x019C68, stdprop + 0x3D, true),
							new Tile("z", 0x028DDA, 0x028E44, false),
							new Tile("Z", 0x028DD9, 0x028E44, false),
							new Tile("Z!!", 0x028DD8, 0x028E44, false),
							new Tile("*pop*", 0x028DD7, 0x028E44, false)});

			Tilemap Spr3E = new Tilemap("P-switch", "Note: The tilemaps are shared between the two P-switch types.", new Tile[] {
							new Tile("Blue P-switch, normal"   , 0x01A221, 0x018466, true),
							new Tile("Blue P-switch, flattened", 0x01E723, 0x018466, false),
							new Tile("Silver P-switch, normal"   , 0x01A221, 0x018467, true),
							new Tile("Silver P-switch, flattened", 0x01E723, 0x018467, false)});

			Tilemap Spr3F = new Tilemap("Para-goomba (parachute)", "Note: The parachute tilemap is shared with the para-bomb.  The page for the parachute's tilemap seems to be forced into being the same as the main tilemap, which is not properly represented here.", new Tile[] {
							new Tile("Frame 1", 0x019B9A, stdprop + 0x3F, false),
							new Tile("Frame 2", 0x019B9B, stdprop + 0x3F, false),
							new Tile("Frame 3", 0x019B9C, stdprop + 0x3F, false),
							new Tile("Frame 4", 0x019B9D, stdprop + 0x3F, false),
							new Tile("Frame 5", 0x019B9E, stdprop + 0x3F, false),
							new Tile("Frame 6", 0x019B9F, stdprop + 0x3F, false),
							new Tile("Frame 7", 0x019BA0, stdprop + 0x3F, false),
							new Tile("Frame 8", 0x019BA1, stdprop + 0x3F, false),
							new Tile("Frame 9", 0x019BA2, stdprop + 0x3F, false),
							new Tile("Frame 10", 0x019BA3, stdprop + 0x3F, false),
							new Tile("Frame 11", 0x019BA4, stdprop + 0x3F, false),
							new Tile("Frame 12", 0x019BA5, stdprop + 0x3F, false),
							new Tile("Parachute 1", 0x019BA6, 0x01D5E1, true),
							new Tile("Parachute 2", 0x019BA7, 0x01D5E1, true)});

			Tilemap Spr40 = new Tilemap("Para-bomb", "Note: The parachute tilemap is shared with the para-goomba.  The page for the parachute's tilemap seems to be forced into being the same as the main tilemap, which is not properly represented here", new Tile[] {
							new Tile("Frame 1", 0x019BAC, stdprop + 0x40, false),
							new Tile("Frame 2", 0x019BAD, stdprop + 0x40, false),
							new Tile("Frame 3", 0x019BAE, stdprop + 0x40, false),
							new Tile("Frame 4", 0x019BAF, stdprop + 0x40, false),
							new Tile("Frame 5", 0x019BB0, stdprop + 0x40, false),
							new Tile("Frame 6", 0x019BB1, stdprop + 0x40, false),
							new Tile("Frame 7", 0x019BB2, stdprop + 0x40, false),
							new Tile("Frame 8", 0x019BB3, stdprop + 0x40, false),
							new Tile("Frame 9", 0x019BB4, stdprop + 0x40, false),
							new Tile("Frame 10", 0x019BB5, stdprop + 0x40, false),
							new Tile("Frame 11", 0x019BB6, stdprop + 0x40, false),
							new Tile("Frame 12", 0x019BB7, stdprop + 0x40, false),
							new Tile("Parachute 1", 0x019BA6, 0x01D5E1, true),
							new Tile("Parachute 2", 0x019BA7, 0x01D5E1, true)});

			Tilemap Spr41 = new Tilemap("Dolphin, horizontal 1", "Note: This tilemap is shared with the other horizontal dolphin.", new Tile[] {
							new Tile("Head 1", 0x02BC0E, stdprop + 0x41, true),
							new Tile("Head 2", 0x02BC0F, stdprop + 0x41, true),
							new Tile("Body 1", 0x02BC10, stdprop + 0x41, true),
							new Tile("Body 2", 0x02BC11, stdprop + 0x41, true),
							new Tile("Tail 1", 0x02BC12, stdprop + 0x41, true),
							new Tile("Tail 2", 0x02BC13, stdprop + 0x41, true)});

			Tilemap Spr42 = new Tilemap("Dolphin, horizontal 2", "Note: This tilemap is shared with the other horizontal dolphin.", new Tile[] {
							new Tile("Head 1", 0x02BC0E, stdprop + 0x42, true),
							new Tile("Head 2", 0x02BC0F, stdprop + 0x42, true),
							new Tile("Body 1", 0x02BC10, stdprop + 0x42, true),
							new Tile("Body 2", 0x02BC11, stdprop + 0x42, true),
							new Tile("Tail 1", 0x02BC12, stdprop + 0x42, true),
							new Tile("Tail 2", 0x02BC13, stdprop + 0x42, true)});

			Tilemap Spr43 = new Tilemap("Dolphin, vertical", "", new Tile[] {
							new Tile("Tile 1", 0x019C69, stdprop + 0x43, true),
							new Tile("Tile 2", 0x019C6A, stdprop + 0x43, true)});

			Tilemap Spr44 = new Tilemap("Torpedo ted", "Note: The dispenser arm tiles are forced onto the second page for some unknown reason.", new Tile[] {
							new Tile("Body", 0x02B92D, stdprop + 0x44, true),
							new Tile("Propeller 1", 0x02B937, stdprop + 0x44, true),
							new Tile("Propeller 2", 0x02B93F, stdprop + 0x44, true),
							new Tile("Propeller 3", 0x02B943, stdprop + 0x44, true),
							new Tile("Dispenser arm (hand closed)", 0x029E66, 0x029E74, 0x029E7D),
							new Tile("Dispenser arm (hand open)", 0x029E6A, 0x029E74, 0x029E7D)});

			Tilemap Spr45 = new Tilemap("Directional coins", "Note: This tilemap is shared with the standard moving coin sprite.", new Tile[] {
							new Tile("Frame 1", 0x01C653, stdprop + 0x45, true),
							new Tile("Frame 2", 0x01C66D, stdprop + 0x45, false),
							new Tile("Frame 3", 0x01C66E, stdprop + 0x45, false),
							new Tile("Frame 4", 0x01C66F, stdprop + 0x45, false)});

			Tilemap Spr46 = new Tilemap("Diggin' Chuck", "Note: This tilemap is shared with all chucks. Many tiles have a (1) and (2) version; they are left and right parts of a particular frame.\n\n...Also, no, I don't know why all these tiles are flipped vertically.", new Tile[] {
							new Tile("Clappin' Chuck's hand 1", 	0x02CA97, stdprop + 0x46, false),
							new Tile("Clappin' Chuck's hand 2", 	0x02CA98, stdprop + 0x46, true),
							new Tile("Chargin' Chuck's arm", 	0x02CB17, stdprop + 0x46, false),
							new Tile("Pitchin' Chuck's held baseball", 0x02CB7C, stdprop + 0x46, false),
							new Tile("Diggin' Chuck's shoulder", 	0x02CB98, stdprop + 0x46, false),
							new Tile("Diggin' Chuck's shovel 1", 	0x02CB99, stdprop + 0x46, false),
							new Tile("Diggin' Chuck's shovel 2", 	0x02CB9A, stdprop + 0x46, false),

							new Tile("Head, looking right", 	0x02C87E, stdprop + 0x46, true),
							new Tile("Head, looking aside right", 	0x02C87F, stdprop + 0x46, true),
							new Tile("Head, facing camera", 	0x02C880, stdprop + 0x46, true),
							new Tile("Head, looking aside left", 	0x02C881, stdprop + 0x46, true),
							new Tile("Head, looking left", 		0x02C882, stdprop + 0x46, true),
							new Tile("Head, looking up left", 	0x02C883, stdprop + 0x46, true),
							new Tile("Head, looking up right", 	0x02C884, stdprop + 0x46, true),
							
							new Tile("Pitchin' body (1)",		0x02C98B, stdprop + 0x46, false),
							new Tile("Pitchin' body (2)",		0x02C9A5, stdprop + 0x46, true),
							
							new Tile("Unknown 1 (1)",		0x02C98C, stdprop + 0x46, false),
							new Tile("Unknown 1 (2)",		0x02C9A6, stdprop + 0x46, false),
							
							new Tile("Unknown 2 (1)",		0x02C98D, stdprop + 0x46, false),
							new Tile("Unknown 2 (2)",		0x02C9A7, stdprop + 0x46, false),
							
							new Tile("Squatting 1 (1)",		0x02C98E, stdprop + 0x46, true),
							new Tile("Squatting 1 (2)",		0x02C9A8, stdprop + 0x46, true),
							
							new Tile("About to jump (1)",		0x02C98F, stdprop + 0x46, true),
							new Tile("About to jump (2)",		0x02C9A9, stdprop + 0x46, true),
							
							new Tile("About to run 2 (1)",		0x02C990, stdprop + 0x46, true),
							new Tile("About to run 1 (2)",		0x02C9AA, stdprop + 0x46, true),
							
							new Tile("Jumping (1)",			0x02C991, stdprop + 0x46, true),
							new Tile("Jumping (2)",			0x02C9AB, stdprop + 0x46, true),
							
							new Tile("Clapping body (1)",		0x02C992, stdprop + 0x46, true),
							new Tile("Clapping body (2)",		0x02C9AC, stdprop + 0x46, true),
							
							new Tile("Pitchin' chuck about to throw (1)",0x02C993, stdprop + 0x46, false),
							new Tile("Pitchin' chuck about to throw (2)",0x02C9AD, stdprop + 0x46, true),
							
							new Tile("About to jump (1)",		0x02C994, stdprop + 0x46, true),
							new Tile("About to jump (2)",		0x02C9AE, stdprop + 0x46, true),
							
							new Tile("Jumped on (1)",		0x02C995, stdprop + 0x46, true),
							new Tile("Jumped on (2)",		0x02C9AF, stdprop + 0x46, true),
							
							new Tile("Jumped on (2)",		0x02C996, stdprop + 0x46, true),
							new Tile("Jumped on (2)",		0x02C9B0, stdprop + 0x46, true),
							
							new Tile("Jumped on (3)",		0x02C997, stdprop + 0x46, true),
							new Tile("Jumped on (2)",		0x02C9B1, stdprop + 0x46, true),
							
							new Tile("Jumped on (4)",		0x02C998, stdprop + 0x46, true),
							new Tile("Jumped on (2)",		0x02C9B2, stdprop + 0x46, true),
							
							new Tile("Digging 1 (1)",		0x02C999, stdprop + 0x46, true),
							new Tile("Digging 1 (2)",		0x02C9B3, stdprop + 0x46, true),
							
							new Tile("Digging 2 (1)",		0x02C99A, stdprop + 0x46, true),
							new Tile("Digging 2 (2)",		0x02C9B4, stdprop + 0x46, true),
							
							new Tile("Digging 3 (1)",		0x02C99B, stdprop + 0x46, true),
							new Tile("Digging 3 (2)",		0x02C9B5, stdprop + 0x46, true),
							
							new Tile("Punting 1 (1)",		0x02C99C, stdprop + 0x46, true),
							new Tile("Punting 1 (2)",		0x02C9B6, stdprop + 0x46, true),
							
							new Tile("Charging 1 (1)",		0x02C99D, stdprop + 0x46, true),
							new Tile("Charging 1 (2)",		0x02C9B7, stdprop + 0x46, true),
							
							new Tile("Charging 2 (1)",		0x02C99E, stdprop + 0x46, true),
							new Tile("Charging 2 (2)",		0x02C9B8, stdprop + 0x46, true),
							
							new Tile("Pitching 1 (1)",		0x02C99F, stdprop + 0x46, false),
							new Tile("Pitching 1 (2)",		0x02C9B9, stdprop + 0x46, true),
							
							new Tile("Pitching 2 (1)",		0x02C9A0, stdprop + 0x46, false),
							new Tile("Pitching 2 (2)",		0x02C9BA, stdprop + 0x46, true),
							
							new Tile("Pitching 3 (1)",		0x02C9A1, stdprop + 0x46, false),
							new Tile("Pitching 3 (2)",		0x02C9BB, stdprop + 0x46, true),
							
							new Tile("Pitching 4 (1)",		0x02C9A2, stdprop + 0x46, false),
							new Tile("Pitching 4 (2)",		0x02C9BC, stdprop + 0x46, true),
							
							new Tile("Pitching 5 (1)",		0x02C9A3, stdprop + 0x46, false),
							new Tile("Pitching 5 (2)",		0x02C9BD, stdprop + 0x46, true),
							
							new Tile("Pitching 6 (1)",		0x02C9A4, stdprop + 0x46, false),
							new Tile("Pitching 6 (2)",		0x02C9BE, stdprop + 0x46, true),
							
							new Tile("Unused?",			0x02C9BF, stdprop + 0x46, true),
							new Tile("Unused?",			0x02C9C0, stdprop + 0x46, true)});


			Tilemap Spr47 = new Tilemap("Cheep cheep, swims and jumps", "Note: All cheep cheep tiles are shared.", new Tile[] {
							new Tile("Swimming 1", 0x019C0D, stdprop + 0x47, true),
							new Tile("Swimming 2", 0x019C0E, stdprop + 0x47, true)});

			Tilemap Spr48 = new Tilemap("Diggin' Chuck's rock", "", new Tile[] {
							new Tile("Frame 1", 0x019C6B, stdprop + 0x48, true),
							new Tile("Frame 2", 0x019C6C, stdprop + 0x48, true)});

			Tilemap Spr49 = new Tilemap("Pipe end", "", new Tile[] {
							new Tile("Left tile", 0x02E91A, stdprop + 0x49, true),
							new Tile("Right tile", 0x02E91F, stdprop + 0x49, true)});

			Tilemap Spr4A = new Tilemap("Goal point sphere", "Note: For whatever reason, this tile is the same as the ledge dwelling Mole's dirt tilemap.  Changing this sprite's tilemap will change that one, too.", new Tile[] {
							new Tile("Tile", 0x019C70, stdprop + 0x4A, true)});

			Tilemap Spr4B = new Tilemap("Pipe lakitu", "Note: Actually not the same tilemap as the normal lakitu.  SMW makes no sense at times.", new Tile[] {
							new Tile("Normal (head)", 0x02E9E6, 0x02EA1B, true),
							new Tile("Throwing (head)", 0x02E9E7, 0x02EA1B, true),
							new Tile("Dead (head)", 0x02E9E8, 0x02EA1B, true),
							new Tile("Normal (body)", 0x02E9E9, 0x02EA1B, true),
							new Tile("Throwing (body)", 0x02E9EA, 0x02EA1B, true),
							new Tile("Dead (body)", 0x02E9EB, 0x02EA1B, true)});

			Tilemap Spr4C = new Tilemap("Exploding block", "Note: This tilemap is shared with that of the throw block.", new Tile[] {
							new Tile("Tile", 0x019C02, stdprop + 0x4C, true)});

			Tilemap Spr4D = new Tilemap("Ground-dwelling monty mole", "Note: The mole's tilemap is shared between both monty moles.", new Tile[] {
							new Tile("Walking 1", 0x019C6D, stdprop + 0x4D, true),
							new Tile("Walking 2", 0x019C6E, stdprop + 0x4D, true),
							new Tile("Jumping", 0x019C6F, stdprop + 0x4D, true),
			
							new Tile("Dirt 1", 0x019C71, stdprop + 0x4D, false),
							new Tile("Dirt 2", 0x019C72, stdprop + 0x4D, false),
							new Tile("Dirt 3", 0x019C73, stdprop + 0x4D, false),
							new Tile("Dirt 4", 0x019C74, stdprop + 0x4D, false),
							new Tile("Dirt 5", 0x019C75, stdprop + 0x4D, false),
							new Tile("Dirt 6", 0x019C76, stdprop + 0x4D, false),
							new Tile("Dirt 7", 0x019C77, stdprop + 0x4D, false),
							new Tile("Dirt 8", 0x019C78, stdprop + 0x4D, false)});

			Tilemap Spr4E = new Tilemap("Ledge-dwelling monty mole", "Note: The mole's tile is shared between both monty moles.  For whatever reason, this tilemap is the same as the goal point sphere's tilemap.  Changing this sprite's tilemap will change that one, too.", new Tile[] {
							new Tile("Walking 1", 0x019C6D, stdprop + 0x4E, true),
							new Tile("Walking 2", 0x019C6E, stdprop + 0x4E, true),
							new Tile("Jumping", 0x019C6F, stdprop + 0x4E, true),
			
							new Tile("Dirt", 0x019C70, stdprop + 0x4E, true)});

			Tilemap Spr4F = new Tilemap("Jumpin' piranha plant", "Note: Tilemaps are shared between all piranha plants.", new Tile[] {
							new Tile("Head 1", 0x019BBD, stdprop + 0x4F, true), 
							new Tile("Head 2", 0x019BBF, stdprop + 0x4F, true), 
							new Tile("Propeller Leaves 1", 0x019BC1, stdprop + 0x4F, false), 
							new Tile("Propeller Leaves 2", 0x019BC2, stdprop + 0x4F, false), 
							new Tile("Propeller Leaves 3", 0x019BC3, stdprop + 0x4F, false), 
							new Tile("Propeller Leaves 4", 0x019BC4, stdprop + 0x4F, false), 
							new Tile("Propeller Leaves 5", 0x019BC5, stdprop + 0x4F, false), 
							new Tile("Propeller Leaves 6", 0x019BC6, stdprop + 0x4F, false), 
							new Tile("Propeller Leaves 7", 0x019BC7, stdprop + 0x4F, false), 
							new Tile("Propeller Leaves 8", 0x019BC8, stdprop + 0x4F, false)});

			Tilemap Spr50 = new Tilemap("Jumpin' fire-spitting piranha plant", "Note: Tilemaps are shared between all piranha plants.", new Tile[] {
							new Tile("Head 1", 0x019BBD, stdprop + 0x50, true), 
							new Tile("Head 2", 0x019BBF, stdprop + 0x50, true), 
							new Tile("Propeller Leaves 1", 0x019BC1, stdprop + 0x50, false), 
							new Tile("Propeller Leaves 2", 0x019BC2, stdprop + 0x50, false), 
							new Tile("Propeller Leaves 3", 0x019BC3, stdprop + 0x50, false), 
							new Tile("Propeller Leaves 4", 0x019BC4, stdprop + 0x50, false), 
							new Tile("Propeller Leaves 5", 0x019BC5, stdprop + 0x50, false), 
							new Tile("Propeller Leaves 6", 0x019BC6, stdprop + 0x50, false), 
							new Tile("Propeller Leaves 7", 0x019BC7, stdprop + 0x50, false), 
							new Tile("Propeller Leaves 8", 0x019BC8, stdprop + 0x50, false)});

			Tilemap Spr51 = new Tilemap("Ninji", "", new Tile[] {
							new Tile("Frame 1", 0x019C7D, stdprop + 0x51, true),
							new Tile("Frame 2", 0x019C7E, stdprop + 0x51, true)});

			Tilemap Spr52 = new Tilemap("Moving ledge", "", new Tile[] {
							new Tile("Tile 1", 0x02E66A, 0x02E66E, 0x02E662),
							new Tile("Tile 2", 0x02E66B, 0x02E66F, 0x02E662),
							new Tile("Tile 3", 0x02E66C, 0x02E670, 0x02E662),
							new Tile("Tile 4", 0x02E66D, 0x02E671, 0x02E662)});

			Tilemap Spr53 = new Tilemap("Throw block", "Note: This tilemap is shared with that of the throw block's.", new Tile[] {
							new Tile("Tile", 0x019C02, stdprop + 0x4C, true)});

			Tilemap Spr54 = new Tilemap("Climbing net door", "", new Tile[] {
							new Tile("Tile 1", 0x01BAB7, 0x01BBD2, true),
							new Tile("Tile 2", 0x01BAB8, 0x01BBD2, true),
							new Tile("Tile 3", 0x01BAB9, 0x01BBD2, true),
							new Tile("Tile 4", 0x01BABA, 0x01BBD2, true),
							new Tile("Tile 5", 0x01BABB, 0x01BBD2, true),
							new Tile("Tile 6", 0x01BABC, 0x01BBD2, true),
							new Tile("Tile 7", 0x01BABD, 0x01BBD2, true),
							new Tile("Tile 8", 0x01BABE, 0x01BBD2, true),
							new Tile("Tile 9", 0x01BABF, 0x01BBD2, true),
							new Tile("Tile 10", 0x01BAC0, 0x01BBD2, true),
							new Tile("Tile 11", 0x01BAC1, 0x01BBD2, true),
							new Tile("Tile 12", 0x01BAC2, 0x01BBD2, true),
							new Tile("Tile 13", 0x01BAC3, 0x01BBD2, true),
							new Tile("Tile 14", 0x01BAC4, 0x01BBD2, true),
							new Tile("Tile 15", 0x01BAC5, 0x01BBD2, true),
							new Tile("Tile 16", 0x01BAC6, 0x01BBD2, true),
							new Tile("Tile 17", 0x01BAC7, 0x01BBD2, true),
							new Tile("Tile 18", 0x01BAC8, 0x01BBD2, true),
							new Tile("Tile 19", 0x01BAC9, 0x01BBD2, true),
							new Tile("Tile 20", 0x01BACA, 0x01BBD2, true),
							new Tile("Tile 21", 0x01BACB, 0x01BBD2, true)});

			Tilemap Spr55 = new Tilemap("Checkerboard platform, horizontal", "Note: This tilemap is shared between all checkerboard platforms.", new Tile[] {
							new Tile("Left tile", 0x01B32E, stdprop + 0x55, true),
							new Tile("Middle tile", 0x01B333, stdprop + 0x55, true),
							new Tile("Right tile", 0x01B33E, stdprop + 0x55, true)});

			Tilemap Spr56 = new Tilemap("Flying rock platform, horizontal", "Note: This tilemap is shared between all flying rock platforms.", new Tile[] {
							new Tile("Top left", 0x01B38C, stdprop + 0x56, true),
							new Tile("Bottom left", 0x01B38D, stdprop + 0x56, true),
							new Tile("Middle top", 0x01B38E, stdprop + 0x56, true),
							new Tile("Middle bottom", 0x01B38F, stdprop + 0x56, true),
							new Tile("Middle top", 0x01B390, stdprop + 0x56, true),
							new Tile("Middle bottom", 0x01B391, stdprop + 0x56, true),
							new Tile("Middle top", 0x01B392, stdprop + 0x56, true),
							new Tile("Bottom right", 0x01B393, stdprop + 0x56, true),
							new Tile("Top right", 0x01B394, stdprop + 0x56, true)});

			Tilemap Spr57 = new Tilemap("Checkerboard platform, vertical", "Note: This tilemap is shared between all checkerboard platforms.", new Tile[] {
							new Tile("Left tile", 0x01B32E, stdprop + 0x57, true),
							new Tile("Middle tile", 0x01B333, stdprop + 0x57, true),
							new Tile("Right tile", 0x01B33E, stdprop + 0x57, true)});

			Tilemap Spr58 = new Tilemap("Flying rock platform, horizontal", "Note: This tilemap is shared between all flying rock platforms.", new Tile[] {
							new Tile("Top left", 0x01B38C, stdprop + 0x58, true),
							new Tile("Bottom left", 0x01B38D, stdprop + 0x58, true),
							new Tile("Middle top", 0x01B38E, stdprop + 0x58, true),
							new Tile("Middle bottom", 0x01B38F, stdprop + 0x58, true),
							new Tile("Middle top", 0x01B390, stdprop + 0x58, true),
							new Tile("Middle bottom", 0x01B391, stdprop + 0x58, true),
							new Tile("Middle top", 0x01B392, stdprop + 0x58, true),
							new Tile("Bottom right", 0x01B393, stdprop + 0x58, true),
							new Tile("Top right", 0x01B394, stdprop + 0x58, true)});

			Tilemap Spr59 = new Tilemap("Turn block bridge, horizontal and vertical", "Note: This tilemap is shared between both turn block bridges. In addition, there's something odd about this sprite's page...it might not be possible to use the second sprite page, even if you specify it.", new Tile[] {
							new Tile("Tile", 0x01B77E, stdprop + 0x59, true)});

			Tilemap Spr5A = new Tilemap("Turn block bridge, horizontal", "Note: This tilemap is shared between both turn block bridges. In addition, there's something odd about this sprite's page...it might not be possible to use the second sprite page, even if you specify it.", new Tile[] {
							new Tile("Tile", 0x01B77E, stdprop + 0x5A, true)});

			Tilemap Spr5B = new Tilemap("Buoyant wooden platform", "Note: This tilemap is shared between all wooden platforms.", new Tile[] {
							new Tile("Left tile", 0x01B345, stdprop + 0x5B, true),
							new Tile("Middle tile", 0x01B34A, stdprop + 0x5B, true),
							new Tile("Right tile", 0x01B355, stdprop + 0x5B, true)});

			Tilemap Spr5C = new Tilemap("Buoyant checkerboard platform", "Note: This tilemap is shared between all checkerboard platforms.", new Tile[] {
							new Tile("Left tile", 0x01B32E, stdprop + 0x5C, true),
							new Tile("Middle tile", 0x01B333, stdprop + 0x5C, true),
							new Tile("Right tile", 0x01B33E, stdprop + 0x5C, true)});

			Tilemap Spr5D = new Tilemap("Buoyant grassy orange platform", "Note: This tilemap is shared between both grassy orange platforms.", new Tile[] {
							new Tile("Top left", 0x01B383, stdprop + 0x5D, true),
							new Tile("Bottom left", 0x01B384, stdprop + 0x5D, true),
							new Tile("Middle top", 0x01B385, stdprop + 0x5D, true),
							new Tile("Middle bottom", 0x01B386, stdprop + 0x5D, true),
							new Tile("Middle top", 0x01B387, stdprop + 0x5D, true),
							new Tile("Middle bottom", 0x01B388, stdprop + 0x5D, true),
							new Tile("Middle top", 0x01B389, stdprop + 0x5D, true),
							new Tile("Bottom right", 0x01B38A, stdprop + 0x5D, true),
							new Tile("Top right", 0x01B38B, stdprop + 0x5D, true)});

			Tilemap Spr5E = new Tilemap("Flying grassy orange platform", "Note: This tilemap is shared between both grassy orange platforms.", new Tile[] {
							new Tile("Top left", 0x01B383, stdprop + 0x5E, true),
							new Tile("Bottom left", 0x01B384, stdprop + 0x5E, true),
							new Tile("Middle top", 0x01B385, stdprop + 0x5E, true),
							new Tile("Middle bottom", 0x01B386, stdprop + 0x5E, true),
							new Tile("Middle top", 0x01B387, stdprop + 0x5E, true),
							new Tile("Middle bottom", 0x01B388, stdprop + 0x5E, true),
							new Tile("Middle top", 0x01B389, stdprop + 0x5E, true),
							new Tile("Bottom right", 0x01B38A, stdprop + 0x5E, true),
							new Tile("Top right", 0x01B38B, stdprop + 0x5E, true)});

			Tilemap Spr5F = new Tilemap("Brown chained platform", "Note: the properties for each chain \"ball\" are unique.  All four platform tiles' properties are shared.", new Tile[] {
							new Tile("Chain \"ball\" 1", 0x01C7EA, 0x01C7EF, true),
							new Tile("Chain \"ball\" 2", 0x01C871, 0x01C876, true),
							new Tile("Chain \"ball\" 3", 0x01C8C7, 0x01C8CC, true),
							new Tile("Chain \"ball\" 4", 0x01C8D3, 0x01C8FB, true),
							new Tile("Platform 1", 0x01C9BB, 0x01C8FB, true),
							new Tile("Platform 2", 0x01C9BC, 0x01C8FB, true),
							new Tile("Platform 3", 0x01C9BD, 0x01C8FB, true),
							new Tile("Platform 4", 0x01C9BE, 0x01C8FB, true)});

			Tilemap Spr60 = new Tilemap("Flattened switch palace switch", "No, I don't know why they'd use 8 8x8 tiles when 2 16x16 tiles would suffice...", new Tile[] {
							new Tile("Tile 1", 0x02CD45, true, false),
							new Tile("Tile 2", 0x02CD46, true, false),
							new Tile("Tile 3", 0x02CD47, true, false),
							new Tile("Tile 4", 0x02CD48, true, false),
							new Tile("Tile 5", 0x02CD49, true, false),
							new Tile("Tile 6", 0x02CD4A, true, false),
							new Tile("Tile 7", 0x02CD4B, true, false),
							new Tile("Tile 8", 0x02CD4C, true, false)});

			Tilemap Spr61 = new Tilemap("Skull raft", "", new Tile[] {
							new Tile("Tile 1", 0x02EE04, stdprop + 0x61, true),
							new Tile("Tile 2", 0x02EE08, stdprop + 0x61, true)});

			Tilemap Spr62 = new Tilemap("Line-guided wooden platform", "Note: This tilemap is shared between all wooden platforms.", new Tile[] {
							new Tile("Left tile", 0x01B345, stdprop + 0x62, true),
							new Tile("Middle tile", 0x01B34A, stdprop + 0x62, true),
							new Tile("Right tile", 0x01B355, stdprop + 0x62, true)});

			Tilemap Spr63 = new Tilemap("Line-guided checkerboard/wooden platform", "Note: Because this sprite uses two shared tilemaps, use the other checkerboard/wooden platform sprites to edit this sprite's tilemap.  You may edit its properties, however.", new Tile[] {
							new Tile("Left tile", 0x01B32E, stdprop + 0x63, true),
							new Tile("Middle tile", 0x01B333, stdprop + 0x63, true),
							new Tile("Right tile", 0x01B33E, stdprop + 0x63, true)});

			Tilemap Spr64 = new Tilemap("Line-guided rope", "Note: The motor tiles share properties, and the rope tiles share properties.", new Tile[] {
							new Tile("Motor tile 1", 0x01DC47, 0x01DCA6, true),
							new Tile("Motor tile 2", 0x01DC48, 0x01DCA6, true),
							new Tile("Motor tile 3", 0x01DC49, 0x01DCA6, true),
							new Tile("Motor tile 4", 0x01DC4A, 0x01DCA6, true),
							
							new Tile("Unused?", 0x01DC4B, 0x01DCAC, true),
							new Tile("Rope tile 1", 0x01DC4C, 0x01DCAC, true),
							new Tile("Rope tile 2", 0x01DC4D, 0x01DCAC, true),
							new Tile("Rope tile 3", 0x01DC4E, 0x01DCAC, true),
							new Tile("Rope tile 4", 0x01DC4F, 0x01DCAC, true),
							new Tile("Rope tile 5", 0x01DC50, 0x01DCAC, true),
							new Tile("Rope tile 6", 0x01DC51, 0x01DCAC, true),
							new Tile("Rope tile 7", 0x01DC52, 0x01DCAC, true),
							new Tile("Rope tile 8", 0x01DC53, 0x01DCAC, true)});

			Tilemap Spr65 = new Tilemap("Line-guided chainsaw", "Note: This tilemap is shared between both chainsaws.  The motor tiles share properties.  The blade tiles' properties are not shared between both chainsaws.", new Tile[] {
							new Tile("Motor tile 1", 0x03C25B, 0x03C2C5, true),
							new Tile("Motor tile 2", 0x03C25C, 0x03C2C5, true),
							new Tile("Motor tile 3", 0x03C25D, 0x03C2C5, true),
							new Tile("Motor tile 4", 0x03C25E, 0x03C2C5, true),
							
							new Tile("Blade 1", 0x03C2BB, 0x03C261, true),
							new Tile("Blade 2", 0x03C2C0, 0x03C261, true)});

			Tilemap Spr66 = new Tilemap("Upside-down line-guided chainsaw", "Note: This tilemap is shared between both chainsaws.  The motor tiles share properties.  The blade tiles' properties are not shared between both chainsaws.", new Tile[] {
							new Tile("Motor tile 1", 0x03C25B, 0x03C2C5, true),
							new Tile("Motor tile 2", 0x03C25C, 0x03C2C5, true),
							new Tile("Motor tile 3", 0x03C25D, 0x03C2C5, true),
							new Tile("Motor tile 4", 0x03C25E, 0x03C2C5, true),
							
							new Tile("Blade 1", 0x03C2BB, 0x03C262, true),
							new Tile("Blade 2", 0x03C2C0, 0x03C262, true)});

			Tilemap Spr67 = new Tilemap("Line-guided grinder", "Note: In order to animate correctly, the tile must end in C (0C, 1C, 2C, 3C, etc). All four tiles use the same tile, but different properties.", new Tile[] {
							new Tile("Top left", 0x01DC28, 0x01DC43, true),
							new Tile("Top right", 0x01DC28, 0x01DC44, true),
							new Tile("Bottom left", 0x01DC28, 0x01DC45, true),
							new Tile("Bottom right", 0x01DC28, 0x01DC46, true)});

			Tilemap Spr68 = new Tilemap("Line-guided fuzzy", "Note: Both tiles use the same tile, but different properties.", new Tile[] {
							new Tile("Tile 1", 0x01DBF5, 0x01DC09, true),
							new Tile("Tile 2", 0x01DBF5, 0x01DC0A, true)});

			Tilemap Spr69 = new Tilemap("Null", "Invalid sprite", new Tile[] { });

			Tilemap Spr6A = new Tilemap("Coin game cloud", "", new Tile[] {
							new Tile("Cloud", 0x02EF2E, 0x02EF3A, true),
							new Tile("Face", 0x02EF56, 0x02EF5B, 0x02EF60)});

			Tilemap Spr6B = new Tilemap("Pea bouncer, left wall", "Note: This tilemap is shared with both pea bouncers.", new Tile[] {
							new Tile("Tile", 0x02CF2C, 0x02CF33, false)});

			Tilemap Spr6C = new Tilemap("Pea bouncer, right wall", "Note: This tilemap is shared with both pea bouncers.", new Tile[] {
							new Tile("Tile", 0x02CF2C, 0x02CF33, false)});

			Tilemap Spr6D = new Tilemap("Invisible solid block", "There are no tiles to edit!", new Tile[] { });

			Tilemap Spr6E = new Tilemap("Dino Rhino", "Note: The left/right facing frames use the same tiles, but different properties.", new Tile[] {
							new Tile("Walking 1, top left, facing left", 0x039E39, 0x039E2D, true),
							new Tile("Walking 1, top right, facing left", 0x039E3A, 0x039E2E, true),
							new Tile("Walking 1, bottom left, facing left", 0x039E3B, 0x039E2F, true),
							new Tile("Walking 1, bottom right, facing left", 0x039E3C, 0x039E30, true),
							new Tile("Walking 2, top left, facing left", 0x039E3D, 0x039E2D, true),
							new Tile("Walking 2, top right, facing left", 0x039E3E, 0x039E2E, true),
							new Tile("Walking 2, bottom left, facing left", 0x039E3F, 0x039E2F, true),
							new Tile("Walking 2, bottom right, facing left", 0x039E40, 0x039E30, true),
						
							new Tile("Fire 1, top left, facing left", 0x039E41, 0x039E2D, true),
							new Tile("Fire 1, top right, facing left", 0x039E42, 0x039E2E, true),
							new Tile("Fire 1, bottom left, facing left", 0x039E43, 0x039E2F, true),
							new Tile("Fire 1, bottom right, facing left", 0x039E44, 0x039E30, true),
							new Tile("Fire 2, top left, facing left", 0x039E45, 0x039E2D, true),
							new Tile("Fire 2, top right, facing left", 0x039E46, 0x039E2E, true),
							new Tile("Fire 2, bottom left, facing left", 0x039E47, 0x039E2F, true),
							new Tile("Fire 2, bottom right, facing left", 0x039E48, 0x039E30, true),

							new Tile("Walking 1, top left, facing left", 0x039E39, 0x039E31, true),
							new Tile("Walking 1, top right, facing left", 0x039E3A, 0x039E32, true),
							new Tile("Walking 1, bottom left, facing left", 0x039E3B, 0x039E33, true),
							new Tile("Walking 1, bottom right, facing left", 0x039E3C, 0x039E34, true),
							new Tile("Walking 2, top left, facing left", 0x039E3D, 0x039E31, true),
							new Tile("Walking 2, top right, facing left", 0x039E3E, 0x039E32, true),
							new Tile("Walking 2, bottom left, facing left", 0x039E3F, 0x039E33, true),
							new Tile("Walking 2, bottom right, facing left", 0x039E40, 0x039E34, true),
							
							new Tile("Fire 1, top left, facing left", 0x039E41, 0x039E31, true),
							new Tile("Fire 1, top right, facing left", 0x039E42, 0x039E32, true),
							new Tile("Fire 1, bottom left, facing left", 0x039E43, 0x039E33, true),
							new Tile("Fire 1, bottom right, facing left", 0x039E44, 0x039E34, true),
							new Tile("Fire 2, top left, facing left", 0x039E45, 0x039E31, true),
							new Tile("Fire 2, top right, facing left", 0x039E46, 0x039E32, true),
							new Tile("Fire 2, bottom left, facing left", 0x039E47, 0x039E33, true),
							new Tile("Fire 2, bottom right, facing left", 0x039E48, 0x039E34, true)});

			Tilemap Spr6F = new Tilemap("Dino Torch", "Note: The left/right facing frames use the same tiles, but different properties.", new Tile[] {
							new Tile("Walking 1", 0x039E21, stdprop + 0x6F, true),
							new Tile("Walking 2", 0x039E22, stdprop + 0x6F, true),
							new Tile("Fire 1", 0x039E23, stdprop + 0x6F, true),
							new Tile("Fire 1", 0x039E24, stdprop + 0x6F, true),
							new Tile("Smushed", 0x019B0B, stdprop + 0x6F, true),
							
							new Tile("Horizontal flame 1", 0x039E12, true, true),
							new Tile("Horizontal flame 2", 0x039E13, true, true),
							new Tile("Horizontal flame 3", 0x039E14, true, true),
							new Tile("Horizontal flame 4", 0x039E15, true, true),
							new Tile("Unused?", 0x039E16, true, true),
							new Tile("Vertical flame 6", 0x039E17, true, true),
							new Tile("Vertical flame 7", 0x039E18, true, true),
							new Tile("Vertical flame 8", 0x039E19, true, true),
							new Tile("Vertical flame 9", 0x039E1A, true, true),
							new Tile("Unused?", 0x039E1B, true, true)});

			Tilemap Spr70 = new Tilemap("Pokey", "", new Tile[] {
							new Tile("Head", 0x02B790, stdprop + 0x70, true),
							new Tile("Head (while being eaten)", 0x02B68D, stdprop + 0x70, true),
							new Tile("Body", 0x02B78C, stdprop + 0x70, true),
							new Tile("Body", 0x02B691, stdprop + 0x70, true)});

			Tilemap Spr71 = new Tilemap("Super koopa, green", "Note: This tilemap is shared between all super koopas. The palette is not editable. Due to an oversight by the game's programmers, the first two \"empty\" tiles are not actually empty; changing this can fix minor garbage when stomping Super Koopas.", new Tile[] {
							new Tile("Take-off 1, cape 1", 0x02EC72, 0x02EC96, 0x02ECBA),
							new Tile("Take-off 1, cape 2", 0x02EC73, 0x02EC97, 0x02ECBB),
							new Tile("Take-off 1, cape 3", 0x02EC74, 0x02EC98, 0x02ECBC),
							new Tile("Take-off 1, body", 0x02EC75, 0x02EC99, 0x02ECBD),

							new Tile("Take-off 2, cape 1", 0x02EC76, 0x02EC9A, 0x02ECBE),
							new Tile("Take-off 2, cape 2", 0x02EC77, 0x02EC9B, 0x02ECBF),
							new Tile("Take-off 2, cape 3", 0x02EC78, 0x02EC9C, 0x02ECC0),
							new Tile("Take-off 2, body", 0x02EC79, 0x02EC9D, 0x02ECC1),

							new Tile("Flying 1, cape 1", 0x02EC7A, 0x02EC9E, 0x02ECC2),
							new Tile("Flying 1, cape 2", 0x02EC7B, 0x02EC9F, 0x02ECC3),
							new Tile("Flying 1, foot", 0x02EC7C, 0x02ECA0, 0x02ECC4),
							new Tile("Flying 1, body", 0x02EC7D, 0x02ECA1, 0x02ECC5),

							new Tile("Flying 2, cape 1", 0x02EC7E, 0x02ECA2, 0x02ECC6),
							new Tile("Flying 2, cape 2", 0x02EC7F, 0x02ECA3, 0x02ECC7),
							new Tile("Flying 2, foot", 0x02EC80, 0x02ECA4, 0x02ECC8),
							new Tile("Flying 2, body", 0x02EC81, 0x02ECA5, 0x02ECC9),

							new Tile("Stomped 1, cape 1", 0x02EC82, 0x02ECA6, 0x02ECCA),
							new Tile("Stomped 1, cape 2", 0x02EC83, 0x02ECA7, 0x02ECCB),
							new Tile("Stomped 1, body", 0x02EC84, 0x02ECA8, 0x02ECCC),
							new Tile("Stomped 1, empty", 0x02EC85, 0x02ECA9, 0x02ECCD),

							new Tile("Stomped 2, cape 1", 0x02EC86, 0x02ECAA, 0x02ECCE),
							new Tile("Stomped 2, cape 2", 0x02EC87, 0x02ECAB, 0x02ECCF),
							new Tile("Stomped 2, body", 0x02EC88, 0x02ECAC, 0x02ECD0),
							new Tile("Stomped 2, empty", 0x02EC89, 0x02ECAD, 0x02ECD1),

							new Tile("Take-off 3, cape 1", 0x02EC8A, 0x02ECAE, 0x02ECD2),
							new Tile("Take-off 3, cape 2", 0x02EC8B, 0x02ECAF, 0x02ECD3),
							new Tile("Take-off 3, body", 0x02EC8C, 0x02ECB0, 0x02ECD4),
							new Tile("Take-off 3, empty", 0x02EC8D, 0x02ECB1, 0x02ECD5),

							new Tile("Take-off 4, cape 1", 0x02EC8E, 0x02ECB2, 0x02ECD6),
							new Tile("Take-off 4, cape 2", 0x02EC8F, 0x02ECB3, 0x02ECD7),
							new Tile("Take-off 4, body", 0x02EC90, 0x02ECB4, 0x02ECD8),
							new Tile("Take-off 4, empty", 0x02EC91, 0x02ECB5, 0x02ECD9),

							new Tile("Take-off 5, cape 1", 0x02EC92, 0x02ECB6, 0x02ECDA),
							new Tile("Take-off 5, cape 2", 0x02EC93, 0x02ECB7, 0x02ECDB),
							new Tile("Take-off 5, body", 0x02EC94, 0x02ECB8, 0x02ECDC),
							new Tile("Take-off 5, empty", 0x02EC95, 0x02ECB9, 0x02ECDD)});

			Tilemap Spr72 = new Tilemap("Super koopa, red", "Note: This tilemap is shared between all super koopas. The palette is not editable. Due to an oversight by the game's programmers, the first two \"empty\" tiles are not actually empty; changing this can fix minor garbage when stomping Super Koopas.", new Tile[] {
							new Tile("Take-off 1, cape 1", 0x02EC72, 0x02EC96, 0x02ECBA),
							new Tile("Take-off 1, cape 2", 0x02EC73, 0x02EC97, 0x02ECBB),
							new Tile("Take-off 1, cape 3", 0x02EC74, 0x02EC98, 0x02ECBC),
							new Tile("Take-off 1, body", 0x02EC75, 0x02EC99, 0x02ECBD),

							new Tile("Take-off 2, cape 1", 0x02EC76, 0x02EC9A, 0x02ECBE),
							new Tile("Take-off 2, cape 2", 0x02EC77, 0x02EC9B, 0x02ECBF),
							new Tile("Take-off 2, cape 3", 0x02EC78, 0x02EC9C, 0x02ECC0),
							new Tile("Take-off 2, body", 0x02EC79, 0x02EC9D, 0x02ECC1),

							new Tile("Flying 1, cape 1", 0x02EC7A, 0x02EC9E, 0x02ECC2),
							new Tile("Flying 1, cape 2", 0x02EC7B, 0x02EC9F, 0x02ECC3),
							new Tile("Flying 1, foot", 0x02EC7C, 0x02ECA0, 0x02ECC4),
							new Tile("Flying 1, body", 0x02EC7D, 0x02ECA1, 0x02ECC5),

							new Tile("Flying 2, cape 1", 0x02EC7E, 0x02ECA2, 0x02ECC6),
							new Tile("Flying 2, cape 2", 0x02EC7F, 0x02ECA3, 0x02ECC7),
							new Tile("Flying 2, foot", 0x02EC80, 0x02ECA4, 0x02ECC8),
							new Tile("Flying 2, body", 0x02EC81, 0x02ECA5, 0x02ECC9),

							new Tile("Stomped 1, cape 1", 0x02EC82, 0x02ECA6, 0x02ECCA),
							new Tile("Stomped 1, cape 2", 0x02EC83, 0x02ECA7, 0x02ECCB),
							new Tile("Stomped 1, body", 0x02EC84, 0x02ECA8, 0x02ECCC),
							new Tile("Stomped 1, empty", 0x02EC85, 0x02ECA9, 0x02ECCD),

							new Tile("Stomped 2, cape 1", 0x02EC86, 0x02ECAA, 0x02ECCE),
							new Tile("Stomped 2, cape 2", 0x02EC87, 0x02ECAB, 0x02ECCF),
							new Tile("Stomped 2, body", 0x02EC88, 0x02ECAC, 0x02ECD0),
							new Tile("Stomped 2, empty", 0x02EC89, 0x02ECAD, 0x02ECD1),

							new Tile("Take-off 3, cape 1", 0x02EC8A, 0x02ECAE, 0x02ECD2),
							new Tile("Take-off 3, cape 2", 0x02EC8B, 0x02ECAF, 0x02ECD3),
							new Tile("Take-off 3, body", 0x02EC8C, 0x02ECB0, 0x02ECD4),
							new Tile("Take-off 3, empty", 0x02EC8D, 0x02ECB1, 0x02ECD5),

							new Tile("Take-off 4, cape 1", 0x02EC8E, 0x02ECB2, 0x02ECD6),
							new Tile("Take-off 4, cape 2", 0x02EC8F, 0x02ECB3, 0x02ECD7),
							new Tile("Take-off 4, body", 0x02EC90, 0x02ECB4, 0x02ECD8),
							new Tile("Take-off 4, empty", 0x02EC91, 0x02ECB5, 0x02ECD9),

							new Tile("Take-off 5, cape 1", 0x02EC92, 0x02ECB6, 0x02ECDA),
							new Tile("Take-off 5, cape 2", 0x02EC93, 0x02ECB7, 0x02ECDB),
							new Tile("Take-off 5, body", 0x02EC94, 0x02ECB8, 0x02ECDC),
							new Tile("Take-off 5, empty", 0x02EC95, 0x02ECB9, 0x02ECDD)});

			Tilemap Spr73 = new Tilemap("Super koopa, blue", "Note: This tilemap is shared between all super koopas. The palette is not editable. Due to an oversight by the game's programmers, the first two \"empty\" tiles are not actually empty; changing this can fix minor garbage when stomping Super Koopas.", new Tile[] {
							new Tile("Take-off 1, cape 1", 0x02EC72, 0x02EC96, 0x02ECBA),
							new Tile("Take-off 1, cape 2", 0x02EC73, 0x02EC97, 0x02ECBB),
							new Tile("Take-off 1, cape 3", 0x02EC74, 0x02EC98, 0x02ECBC),
							new Tile("Take-off 1, body", 0x02EC75, 0x02EC99, 0x02ECBD),

							new Tile("Take-off 2, cape 1", 0x02EC76, 0x02EC9A, 0x02ECBE),
							new Tile("Take-off 2, cape 2", 0x02EC77, 0x02EC9B, 0x02ECBF),
							new Tile("Take-off 2, cape 3", 0x02EC78, 0x02EC9C, 0x02ECC0),
							new Tile("Take-off 2, body", 0x02EC79, 0x02EC9D, 0x02ECC1),

							new Tile("Flying 1, cape 1", 0x02EC7A, 0x02EC9E, 0x02ECC2),
							new Tile("Flying 1, cape 2", 0x02EC7B, 0x02EC9F, 0x02ECC3),
							new Tile("Flying 1, foot", 0x02EC7C, 0x02ECA0, 0x02ECC4),
							new Tile("Flying 1, body", 0x02EC7D, 0x02ECA1, 0x02ECC5),

							new Tile("Flying 2, cape 1", 0x02EC7E, 0x02ECA2, 0x02ECC6),
							new Tile("Flying 2, cape 2", 0x02EC7F, 0x02ECA3, 0x02ECC7),
							new Tile("Flying 2, foot", 0x02EC80, 0x02ECA4, 0x02ECC8),
							new Tile("Flying 2, body", 0x02EC81, 0x02ECA5, 0x02ECC9),

							new Tile("Stomped 1, cape 1", 0x02EC82, 0x02ECA6, 0x02ECCA),
							new Tile("Stomped 1, cape 2", 0x02EC83, 0x02ECA7, 0x02ECCB),
							new Tile("Stomped 1, body", 0x02EC84, 0x02ECA8, 0x02ECCC),
							new Tile("Stomped 1, empty", 0x02EC85, 0x02ECA9, 0x02ECCD),

							new Tile("Stomped 2, cape 1", 0x02EC86, 0x02ECAA, 0x02ECCE),
							new Tile("Stomped 2, cape 2", 0x02EC87, 0x02ECAB, 0x02ECCF),
							new Tile("Stomped 2, body", 0x02EC88, 0x02ECAC, 0x02ECD0),
							new Tile("Stomped 2, empty", 0x02EC89, 0x02ECAD, 0x02ECD1),

							new Tile("Take-off 3, cape 1", 0x02EC8A, 0x02ECAE, 0x02ECD2),
							new Tile("Take-off 3, cape 2", 0x02EC8B, 0x02ECAF, 0x02ECD3),
							new Tile("Take-off 3, body", 0x02EC8C, 0x02ECB0, 0x02ECD4),
							new Tile("Take-off 3, empty", 0x02EC8D, 0x02ECB1, 0x02ECD5),

							new Tile("Take-off 4, cape 1", 0x02EC8E, 0x02ECB2, 0x02ECD6),
							new Tile("Take-off 4, cape 2", 0x02EC8F, 0x02ECB3, 0x02ECD7),
							new Tile("Take-off 4, body", 0x02EC90, 0x02ECB4, 0x02ECD8),
							new Tile("Take-off 4, empty", 0x02EC91, 0x02ECB5, 0x02ECD9),

							new Tile("Take-off 5, cape 1", 0x02EC92, 0x02ECB6, 0x02ECDA),
							new Tile("Take-off 5, cape 2", 0x02EC93, 0x02ECB7, 0x02ECDB),
							new Tile("Take-off 5, body", 0x02EC94, 0x02ECB8, 0x02ECDC),
							new Tile("Take-off 5, empty", 0x02EC95, 0x02ECB9, 0x02ECDD)});

			Tilemap Spr74 = new Tilemap("Mushroom", "Note: The size is shared by all item box powerups.", new Tile[] {
							new Tile("Normal", 0x01C609, stdprop + 0x74, true),
							new Tile("In reserve box", 0x008DFA, 0x008E02, 0x0090CC)});

			Tilemap Spr75 = new Tilemap("Fire flower", "Note: The size is shared by all item box powerups.", new Tile[] {
							new Tile("Normal", 0x01C60A, stdprop + 0x75, true),
							new Tile("In reserve box", 0x008DFB, 0x008E03, 0x0090CC)});

			Tilemap Spr76 = new Tilemap("Star", "Note: The size is shared by all item box powerups.  The palette is not editable", new Tile[] {
							new Tile("Normal", 0x01C60B, stdprop + 0x76, true),
							new Tile("In reserve box", 0x008DFC, 0x008E04, 0x0090CC)});

			Tilemap Spr77 = new Tilemap("Feather", "Note: The size is shared by all item box powerups.", new Tile[] {
							new Tile("Normal", 0x01C60C, stdprop + 0x77, true),
							new Tile("In reserve box", 0x008DFD, 0x008E05, 0x0090CC)});

			Tilemap Spr78 = new Tilemap("1-UP mushroom", "Note: The size is shared by all item box powerups.", new Tile[] {
							new Tile("Tile", 0x01C60D, stdprop + 0x78, true)});

			Tilemap Spr79 = new Tilemap("Growing vine", "", new Tile[] {
							new Tile("Frame 1", 0x01C19E, stdprop + 0x79, true),
							new Tile("Frame 2", 0x01C1A2, stdprop + 0x79, true)});

			Tilemap Spr7A = new Tilemap("Firework", "", new Tile[] {
							new Tile("Frame 1", 0x03C9B9, 0x03CAC0, false),
							new Tile("Frame 2", 0x03C9BA, 0x03CAC0, false),
							new Tile("Frame 3", 0x03C9BB, 0x03CAC0, false),
							new Tile("Frame 4", 0x03C9BC, 0x03CAC0, false),
							new Tile("Frame 5", 0x03C9BD, 0x03CAC0, false),
							new Tile("Frame 6", 0x03C9BE, 0x03CAC0, false),
							new Tile("Frame 7", 0x03C9BF, 0x03CAC0, false),
							new Tile("Frame 8", 0x03C9C0, 0x03CAC0, false),
							new Tile("Frame 9", 0x03C9C1, 0x03CAC0, false),
							new Tile("Frame 10", 0x03C9C2, 0x03CAC0, false),
							new Tile("Frame 11", 0x03C9C3, 0x03CAC0, false),
							new Tile("Frame 12", 0x03C9C4, 0x03CAC0, false),
							new Tile("Frame 13", 0x03C9C5, 0x03CAC0, false),
							new Tile("Frame 14", 0x03C9C6, 0x03CAC0, false),
							new Tile("Frame 15", 0x03C9C7, 0x03CAC0, false),
							new Tile("Frame 16", 0x03C9C8, 0x03CAC0, false),
							new Tile("Frame 17", 0x03C9C9, 0x03CAC0, false),
							new Tile("Frame 18", 0x03C9CA, 0x03CAC0, false),
							new Tile("Frame 19", 0x03C9CB, 0x03CAC0, false),
							new Tile("Frame 20", 0x03C9CC, 0x03CAC0, false),
							new Tile("Frame 21", 0x03C9CD, 0x03CAC0, false),
							new Tile("Frame 22", 0x03C9CE, 0x03CAC0, false),
							new Tile("Frame 23", 0x03C9CF, 0x03CAC0, false),
							new Tile("Frame 24", 0x03C9D0, 0x03CAC0, false),
							new Tile("Frame 25", 0x03C9D1, 0x03CAC0, false),
							new Tile("Frame 26", 0x03C9D2, 0x03CAC0, false),
							new Tile("Frame 27", 0x03C9D3, 0x03CAC0, false),
							new Tile("Frame 28", 0x03C9D4, 0x03CAC0, false),
							new Tile("Frame 29", 0x03C9D5, 0x03CAC0, false),
							new Tile("Frame 30", 0x03C9D6, 0x03CAC0, false),
							new Tile("Frame 31", 0x03C9D7, 0x03CAC0, false),
							new Tile("Frame 32", 0x03C9D8, 0x03CAC0, false),
							new Tile("Frame 33", 0x03C9D9, 0x03CAC0, false),
							new Tile("Frame 34", 0x03C9DA, 0x03CAC0, false),
							new Tile("Frame 35", 0x03C9DB, 0x03CAC0, false),
							new Tile("Frame 36", 0x03C9DC, 0x03CAC0, false),
							new Tile("Frame 37", 0x03C9DD, 0x03CAC0, false),
							new Tile("Frame 38", 0x03C9DE, 0x03CAC0, false),
							new Tile("Frame 39", 0x03C9DF, 0x03CAC0, false),
							new Tile("Frame 40", 0x03C9E0, 0x03CAC0, false)});

			Tilemap Spr7B = new Tilemap("Goal tape", "", new Tile[] {
							new Tile("Tile", 0x01C158, 0x01C164, 0x01C16F)});

			Tilemap Spr7C = new Tilemap("Princess Peach", "Unknown", new Tile[] { });

			Tilemap Spr7D = new Tilemap("P-balloon", "", new Tile[] {
							new Tile("Tile", 0x01C612, stdprop + 0x7D, true)});

			Tilemap Spr7E = new Tilemap("Flying red coin", "", new Tile[] {
							new Tile("Tile", 0x01C613, stdprop + 0x7E, true)});

			Tilemap Spr7F = new Tilemap("Flying 1-UP", "", new Tile[] {
							new Tile("Tile", 0x01C614, stdprop + 0x7F, true)});

			Tilemap Spr80 = new Tilemap("Key", "", new Tile[] {
							new Tile("Tile", 0x01A1FA, stdprop + 0x80, true)});

			Tilemap Spr81 = new Tilemap("Changing powerup", "Note: This sprite has no tilemap, as it actually changes into the displayed item.  Change their tilemaps instead.", new Tile[] { });

			Tilemap Spr82 = new Tilemap("Bonus game", "", new Tile[] {
							new Tile("Background tile", 0x01DF8D, 0x01DFA4, true),
							new Tile("Tile 1", 0x01DEE3, 0x01DF07, false),
							new Tile("Tile 2", 0x01DEE4, 0x01DF07, false),
							new Tile("Tile 3", 0x01DEE5, 0x01DF07, false),
							new Tile("Tile 4", 0x01DEE6, 0x01DF07, false),
							new Tile("Tile 5", 0x01DEE7, 0x01DF08, false),
							new Tile("Tile 6", 0x01DEE8, 0x01DF08, false),
							new Tile("Tile 7", 0x01DEE9, 0x01DF08, false),
							new Tile("Tile 8", 0x01DEEA, 0x01DF08, false),
							new Tile("Tile 9", 0x01DEEB, 0x01DF09, false),
							new Tile("Tile 10", 0x01DEEC, 0x01DF09, false),
							new Tile("Tile 11", 0x01DEED, 0x01DF09, false),
							new Tile("Tile 12", 0x01DEEE, 0x01DF09, false),
							new Tile("Tile 13", 0x01DEEF, 0x01DF0A, false),
							new Tile("Tile 14", 0x01DEF0, 0x01DF0A, false),
							new Tile("Tile 15", 0x01DEF1, 0x01DF0A, false),
							new Tile("Tile 16", 0x01DEF2, 0x01DF0A, false),
							new Tile("Tile 17", 0x01DEF3, 0x01DF0B, false),
							new Tile("Tile 18", 0x01DEF4, 0x01DF0B, false),
							new Tile("Tile 19", 0x01DEF5, 0x01DF0B, false),
							new Tile("Tile 20", 0x01DEF6, 0x01DF0B, false),
							new Tile("Tile 21", 0x01DEF7, 0x01DF0C, false),
							new Tile("Tile 22", 0x01DEF8, 0x01DF0C, false),
							new Tile("Tile 23", 0x01DEF9, 0x01DF0C, false),
							new Tile("Tile 24", 0x01DEFA, 0x01DF0C, false),
							new Tile("Tile 25", 0x01DEFB, 0x01DF0D, false),
							new Tile("Tile 26", 0x01DEFC, 0x01DF0D, false),
							new Tile("Tile 27", 0x01DEFD, 0x01DF0D, false),
							new Tile("Tile 28", 0x01DEFE, 0x01DF0D, false),
							new Tile("Tile 29", 0x01DEFF, 0x01DF0E, false),
							new Tile("Tile 30", 0x01DE00, 0x01DF0E, false),
							new Tile("Tile 31", 0x01DF01, 0x01DF0E, false),
							new Tile("Tile 32", 0x01DF02, 0x01DF0E, false),
							new Tile("Tile 33", 0x01DF03, 0x01DF0F, false),
							new Tile("Tile 34", 0x01DF04, 0x01DF0F, false),
							new Tile("Tile 35", 0x01DF05, 0x01DF0F, false),
							new Tile("Tile 36", 0x01DF06, 0x01DF0F, false)});

			Tilemap Spr83 = new Tilemap("Flying ? Block, left", "Note: This tilemap is shared between both flying ? blocks.", new Tile[] {
							new Tile("? block", 0x01AE76, stdprop + 0x83, true),
							new Tile("Hit", 0x01AE7A, stdprop + 0x83, true)});

			Tilemap Spr84 = new Tilemap("Flying ? Block, back and forth", "Note: This tilemap is shared between both flying ? blocks.", new Tile[] {
							new Tile("? block", 0x01AE76, stdprop + 0x84, true),
							new Tile("Hit", 0x01AE7A, stdprop + 0x84, true)});

			Tilemap Spr85 = new Tilemap("Null", "Invalid sprite", new Tile[] { });

			Tilemap Spr86 = new Tilemap("Wiggler", "", new Tile[] {
							new Tile("Head 1", 0x02F16E, stdprop + 0x86, true),
							new Tile("Body 1", 0x02F10C, stdprop + 0x86, true),
							new Tile("Body 2", 0x02F10D, stdprop + 0x86, true),
							new Tile("Body 3", 0x02F10E, stdprop + 0x86, true),
							new Tile("Body 4", 0x02F10F, stdprop + 0x86, true),
							new Tile("Angry eyes", 0x02F1BE, stdprop + 0x86, false),
							new Tile("Wiggler's flower", 0x029D30, 0x029D35, 0x029D40)});

			Tilemap Spr87 = new Tilemap("Lakitu's cloud", "", new Tile[] {
							new Tile("Cloud 1", 0x01E985, stdprop + 0x87, true),
							new Tile("Cloud 2", 0x01E986, stdprop + 0x87, true),
							new Tile("Cloud 3", 0x01E987, stdprop + 0x87, true),
							new Tile("Cloud 4", 0x01E988, stdprop + 0x87, true),
							new Tile("Face", 0x01E976, 0x01E97B, false)});

			Tilemap Spr88 = new Tilemap("Winged cage", "Unknown", new Tile[] { });

			Tilemap Spr89 = new Tilemap("Layer 3 smash", "No sprite tilemap to edit!", new Tile[] { });

			Tilemap Spr8A = new Tilemap("Birds on Yoshi's house", "", new Tile[] {
							new Tile("Tile 1", 0x02F3DB, true, false), 
							new Tile("Tile 2", 0x02F3DC, true, false), 
							new Tile("Tile 3", 0x02F3DD, true, false), 
							new Tile("Tile 4", 0x02F3DE, true, false), 
							new Tile("Tile 5", 0x02F3DF, true, false)});

			Tilemap Spr8B = new Tilemap("Yoshi's house smoke", "", new Tile[] {
							new Tile("Tile", 0x02F4AF, 0x02F4B7, true)});

			Tilemap Spr8C = new Tilemap("Side exit enable", "No tilemap to edit!", new Tile[] { });

			Tilemap Spr8D = new Tilemap("Ghost house exit", "", new Tile[] {
							new Tile("Sign 1", 0x02F5BC, 0x02F5C6, true),
							new Tile("Sign 2", 0x02F5BD, 0x02F5C7, true),
							new Tile("Door 1", 0x02F5BE, 0x02F5C8, true),
							new Tile("Door 2", 0x02F5BF, 0x02F5C9, true),
							new Tile("Door 3", 0x02F5C0, 0x02F5CA, true),
							new Tile("Door 4", 0x02F5C1, 0x02F5CB, true),
							new Tile("Door 5", 0x02F5C2, 0x02F5CC, true),
							new Tile("Door 6", 0x02F5C3, 0x02F5CD, true),
							new Tile("Door 7", 0x02F5C4, 0x02F5CE, true),
							new Tile("Door 8", 0x02F5C5, 0x02F5CF, true)});

			Tilemap Spr8E = new Tilemap("Invisible \"warp hole\"", "Hopefully I don't have to explain why there's no tilemap to edit...", new Tile[] { });

			Tilemap Spr8F = new Tilemap("Mushroom scale platforms", "", new Tile[] {
							new Tile("Tile", 0x02E599, stdprop + 0x8F, true)});

			Tilemap Spr90 = new Tilemap("Large gas bubble", "Note: The size is shared for all tiles.", new Tile[] {
							new Tile("Tile 1", 0x02E372, 0x02E382, 0x02E411),
							new Tile("Tile 2", 0x02E373, 0x02E383, 0x02E411),
							new Tile("Tile 3", 0x02E374, 0x02E384, 0x02E411),
							new Tile("Tile 4", 0x02E375, 0x02E385, 0x02E411),
							new Tile("Tile 5", 0x02E376, 0x02E386, 0x02E411),
							new Tile("Tile 6", 0x02E377, 0x02E387, 0x02E411),
							new Tile("Tile 7", 0x02E378, 0x02E388, 0x02E411),
							new Tile("Tile 8", 0x02E379, 0x02E389, 0x02E411),
							new Tile("Tile 9", 0x02E37A, 0x02E38A, 0x02E411),
							new Tile("Tile 10", 0x02E37B, 0x02E38B, 0x02E411),
							new Tile("Tile 11", 0x02E37C, 0x02E38C, 0x02E411),
							new Tile("Tile 12", 0x02E37D, 0x02E38D, 0x02E411),
							new Tile("Tile 13", 0x02E37E, 0x02E38E, 0x02E411),
							new Tile("Tile 14", 0x02E37F, 0x02E38F, 0x02E411),
							new Tile("Tile 15", 0x02E380, 0x02E390, 0x02E411),
							new Tile("Tile 16", 0x02E381, 0x02E391, 0x02E411)});

			// All chucks share the same tilemaps
			Tilemap Spr91 = Spr46.Copy("Chargin' Chuck"); ;//new Tilemap("Chargin' Chuck", "Far too complicated...", new Tile[] { });
			Tilemap Spr92 = Spr46.Copy("Splittin' Chuck"); ;//new Tilemap("Splittin' Chuck", "Far too complicated...", new Tile[] { });
			Tilemap Spr93 = Spr46.Copy("Bouncin' Chuck"); ;//new Tilemap("Bouncin' Chuck", "Far too complicated...", new Tile[] { });
			Tilemap Spr94 = Spr46.Copy("Whistlin' Chuck"); ;//new Tilemap("Whistlin' Chuck", "Far too complicated...", new Tile[] { });
			Tilemap Spr95 = Spr46.Copy("Clappin' Chuck"); ;//new Tilemap("Clappin' Chuck", "Far too complicated...", new Tile[] { });
			Tilemap Spr96 = Spr46.Copy("Clone'd Chuck"); ;//new Tilemap("Clone'd Chuck", "Far too complicated...", new Tile[] { });
			Tilemap Spr97 = Spr46.Copy("Puntin' Chuck"); ;//new Tilemap("Puntin' Chuck", "Far too complicated...", new Tile[] { });
			Tilemap Spr98 = Spr46.Copy("Pitchin' Chuck"); ;//new Tilemap("Pitchin' Chuck", "Far too complicated...", new Tile[] { });
		
			Tilemap Spr99 = new Tilemap("Volcano lotus", "Note: The tiles for the red/yellow frames are the same.", new Tile[] {
							new Tile("Base", 0x02E012, 0x02E01F, true),
							new Tile("Bud 1 (red)", 0x02E008, 0x02E056, false),
							new Tile("Bud 1 (yellow)", 0x02E008, 0x02E05A, false),
							new Tile("Bud 2 (red)", 0x02E009, 0x02E056, false),
							new Tile("Bud 2 (yellow)", 0x02E009, 0x02E05A, false),
							new Tile("Bud 3 (red)", 0x02E00A, 0x02E056, false),
							new Tile("Bud 3 (yellow)", 0x02E00A, 0x02E05A, false),
							new Tile("Fireball 1", 0x029B94, 0x029B84, 0x029BA1),
							new Tile("Fireball 2", 0x029B98, 0x029B84, 0x029BA1)});

			Tilemap Spr9A = new Tilemap("Sumo bros.", "", new Tile[] {
							new Tile("Tile 1", 0x02DE0E, stdprop + 0x9A, 0x02DE26),
							new Tile("Tile 2", 0x02DE0F, stdprop + 0x9A, 0x02DE27),
							new Tile("Tile 3", 0x02DE10, stdprop + 0x9A, 0x02DE28),
							new Tile("Tile 4", 0x02DE11, stdprop + 0x9A, 0x02DE29),
							new Tile("Tile 5", 0x02DE12, stdprop + 0x9A, 0x02DE2A),
							new Tile("Tile 6", 0x02DE13, stdprop + 0x9A, 0x02DE2B),
							new Tile("Tile 7", 0x02DE14, stdprop + 0x9A, 0x02DE2C),
							new Tile("Tile 8", 0x02DE15, stdprop + 0x9A, 0x02DE2D),
							new Tile("Tile 9", 0x02DE16, stdprop + 0x9A, 0x02DE2E),
							new Tile("Tile 10", 0x02DE17, stdprop + 0x9A, 0x02DE2F),
							new Tile("Tile 11", 0x02DE18, stdprop + 0x9A, 0x02DE30),
							new Tile("Tile 12", 0x02DE19, stdprop + 0x9A, 0x02DE31),
							new Tile("Tile 13", 0x02DE1A, stdprop + 0x9A, 0x02DE32),
							new Tile("Tile 14", 0x02DE1B, stdprop + 0x9A, 0x02DE33),
							new Tile("Tile 15", 0x02DE1C, stdprop + 0x9A, 0x02DE34),
							new Tile("Tile 16", 0x02DE1D, stdprop + 0x9A, 0x02DE35),
							new Tile("Tile 17", 0x02DE1E, stdprop + 0x9A, 0x02DE36),
							new Tile("Tile 18", 0x02DE1F, stdprop + 0x9A, 0x02DE37),
							new Tile("Tile 19", 0x02DE20, stdprop + 0x9A, 0x02DE38),
							new Tile("Tile 20", 0x02DE21, stdprop + 0x9A, 0x02DE39),
							new Tile("Tile 21", 0x02DE22, stdprop + 0x9A, 0x02DE3A),
							new Tile("Tile 22", 0x02DE23, stdprop + 0x9A, 0x02DE3B),
							new Tile("Tile 23", 0x02DE24, stdprop + 0x9A, 0x02DE3C),
							new Tile("Tile 24", 0x02DE25, stdprop + 0x9A, 0x02DE3D)});

			Tilemap Spr9B = new Tilemap("Hammer bros.", "", new Tile[] {
							new Tile("Helmet 1, 1", 0x02DAF1, 0x02DB1F, 0x02DAF9),
							new Tile("Helmet 2, 1", 0x02DAF2, 0x02DB1F, 0x02DAFA),
							new Tile("Body 1, 1", 0x02DAF3, 0x02DB1F, 0x02DAFB),
							new Tile("Body 2, 1", 0x02DAF4, 0x02DB1F, 0x02DAFC),
							new Tile("Helmet 1, 2", 0x02DAF5, 0x02DB1F, 0x02DAF9),
							new Tile("Helmet 2, 2", 0x02DAF6, 0x02DB1F, 0x02DAFA),
							new Tile("Body 1, 2", 0x02DAF7, 0x02DB1F, 0x02DAFB),
							new Tile("Body 2, 2", 0x02DAF8, 0x02DB1F, 0x02DAFC),
							new Tile("Hammer 1", 0x02A2DF, 0x02A2E7, 0x02A33E),
							new Tile("Hammer 2", 0x02A2E0, 0x02A2E8, 0x02A33E),
							new Tile("Hammer 3", 0x02A2E1, 0x02A2E9, 0x02A33E),
							new Tile("Hammer 4", 0x02A2E2, 0x02A2EA, 0x02A33E),
							new Tile("Hammer 5", 0x02A2E3, 0x02A2EB, 0x02A33E),
							new Tile("Hammer 6", 0x02A2E4, 0x02A2EC, 0x02A33E),
							new Tile("Hammer 7", 0x02A2E5, 0x02A2ED, 0x02A33E),
							new Tile("Hammer 8", 0x02A2E6, 0x02A2EE, 0x02A33E)});

			Tilemap Spr9C = new Tilemap("Hammer bros. platform", "", new Tile[] {
							new Tile("Frame 1, block 1", 0x02DC1F, 0x02DC27, 0x02DC2F),
							new Tile("Frame 1, block 2", 0x02DC20, 0x02DC28, 0x02DC30),
							new Tile("Frame 1, wing 1", 0x02DC21, 0x02DC29, 0x02DC31),
							new Tile("Frame 1, wing 2", 0x02DC22, 0x02DC2A, 0x02DC32),
							new Tile("Frame 2, block 1", 0x02DC23, 0x02DC2B, 0x02DC33),
							new Tile("Frame 2, block 2", 0x02DC24, 0x02DC2C, 0x02DC34),
							new Tile("Frame 2, wing 1", 0x02DC25, 0x02DC2D, 0x02DC35),
							new Tile("Frame 2, wing 2", 0x02DC26, 0x02DC2E, 0x02DC36)});

			Tilemap Spr9D = new Tilemap("Bubble", "", new Tile[] {
							new Tile("Bubble 1", 0x02D9C3, 0x02D9C8, 0x02D9CD),
							new Tile("Bubble 2", 0x02D9C4, 0x02D9C9, 0x02D9CE),
							new Tile("Bubble 3", 0x02D9C5, 0x02D9CA, 0x02D9CF),
							new Tile("Bubble 4", 0x02D9C6, 0x02D9CB, 0x02D9D0),
							new Tile("Bubble 5", 0x02D9C7, 0x02D9CC, 0x02D9D1),
							new Tile("Goomba 1", 0x02D8A1, 0x02D8A9, true),
							new Tile("Goomba 2", 0x02D8A5, 0x02D8A9, true),
							new Tile("Bob-omb 1", 0x02D8A2, 0x02D8AA, true),
							new Tile("Bob-omb 2", 0x02D8A6, 0x02D8AA, true),
							new Tile("Cheep-cheep 1", 0x02D8A3, 0x02D8AB, true),
							new Tile("Cheep-cheep 2", 0x02D8A7, 0x02D8AB, true),
							new Tile("Mushroom 1", 0x02D8A4, 0x02D8AC, true),
							new Tile("Mushroom 2", 0x02D8A8, 0x02D8AC, true)});

			Tilemap Spr9E = new Tilemap("Ball 'n chain", "Note: The actual mace is not editable without crashing the game because of a rather silly (read: \"what on Earth were the programmers thinking\") design choice.", new Tile[] {
							new Tile("Chain", 0x02D7A4, 0x02D7BF, true)});

			Tilemap Spr9F = new Tilemap("Banzai bill", "", new Tile[] {
							new Tile("Tile 1", 0x02D5C4, 0x02D5D4, true),
							new Tile("Tile 2", 0x02D5C5, 0x02D5D5, true),
							new Tile("Tile 3", 0x02D5C6, 0x02D5D6, true),
							new Tile("Tile 4", 0x02D5C7, 0x02D5D7, true),
							new Tile("Tile 5", 0x02D5C8, 0x02D5D8, true),
							new Tile("Tile 6", 0x02D5C9, 0x02D5D9, true),
							new Tile("Tile 7", 0x02D5CA, 0x02D5DA, true),
							new Tile("Tile 8", 0x02D5CB, 0x02D5DB, true),
							new Tile("Tile 9", 0x02D5CC, 0x02D5DC, true),
							new Tile("Tile 10", 0x02D5CD, 0x02D5DD, true),
							new Tile("Tile 11", 0x02D5CE, 0x02D5DE, true),
							new Tile("Tile 12", 0x02D5CF, 0x02D5DF, true),
							new Tile("Tile 13", 0x02D5D0, 0x02D5E0, true),
							new Tile("Tile 14", 0x02D5D1, 0x02D5E1, true),
							new Tile("Tile 15", 0x02D5D2, 0x02D5E2, true),
							new Tile("Tile 16", 0x02D5D3, 0x02D5E3, true)});

			Tilemap SprA0 = new Tilemap("Bowser scene activator", "No sprite tilemap to edit!", new Tile[] { });

			Tilemap SprA1 = new Tilemap("Bowser's bowling ball", "", new Tile[] {
							new Tile("Tile 1", 0x03B1ED, 0x03B1F9, 0x03B205),
							new Tile("Tile 2", 0x03B1EE, 0x03B1FA, 0x03B206),
							new Tile("Tile 3", 0x03B1EF, 0x03B1FB, 0x03B207),
							new Tile("Tile 4", 0x03B1F0, 0x03B1FC, 0x03B208),
							new Tile("Tile 5", 0x03B1F1, 0x03B1FD, 0x03B209),
							new Tile("Tile 6", 0x03B1F2, 0x03B1FE, 0x03B20A),
							new Tile("Tile 7", 0x03B1F3, 0x03B1FF, 0x03B20B),
							new Tile("Tile 8", 0x03B1F4, 0x03B200, 0x03B20C),
							new Tile("Tile 9", 0x03B1F5, 0x03B201, 0x03B20D),
							new Tile("Tile 10", 0x03B1F6, 0x03B202, 0x03B20E),
							new Tile("Tile 11", 0x03B1F7, 0x03B203, 0x03B20F),
							new Tile("Tile 12", 0x03B1F8, 0x03B204, 0x03B210)});

			Tilemap SprA2 = new Tilemap("Mechakoopa", "Note: The tiles are the same for the left and right keys, but they have different properties.", new Tile[] {
							new Tile("Tile 1", 0x03B32F, stdprop + 0xA2, 0x03B34F),
							new Tile("Tile 2", 0x03B330, stdprop + 0xA2, 0x03B350),
							new Tile("Tile 3", 0x03B331, stdprop + 0xA2, 0x03B351),
							new Tile("Tile 4", 0x03B332, stdprop + 0xA2, 0x03B352),
							new Tile("Tile 5", 0x03B333, stdprop + 0xA2, 0x03B34F),
							new Tile("Tile 6", 0x03B334, stdprop + 0xA2, 0x03B350),
							new Tile("Tile 7", 0x03B335, stdprop + 0xA2, 0x03B351),
							new Tile("Tile 8", 0x03B336, stdprop + 0xA2, 0x03B352),
							new Tile("Tile 9", 0x03B337, stdprop + 0xA2, 0x03B34F),
							new Tile("Tile 10", 0x03B338, stdprop + 0xA2, 0x03B350),
							new Tile("Tile 11", 0x03B339, stdprop + 0xA2, 0x03B351),
							new Tile("Tile 12", 0x03B33A, stdprop + 0xA2, 0x03B352),
							new Tile("Tile 13", 0x03B33B, stdprop + 0xA2, 0x03B34F),
							new Tile("Tile 14", 0x03B33C, stdprop + 0xA2, 0x03B350),
							new Tile("Tile 15", 0x03B33D, stdprop + 0xA2, 0x03B351),
							new Tile("Tile 16", 0x03B33E, stdprop + 0xA2, 0x03B352),
							new Tile("Key 1, left", 0x03B3F3, 0x03B3F1, 0x03B434),
							new Tile("Key 2, left", 0x03B3F4, 0x03B3F1, 0x03B434),
							new Tile("Key 3, left", 0x03B3F5, 0x03B3F1, 0x03B434),
							new Tile("Key 4, left", 0x03B3F6, 0x03B3F1, 0x03B434),
							new Tile("Key 1, right", 0x03B3F3, 0x03B3F2, 0x03B434),
							new Tile("Key 2, right", 0x03B3F4, 0x03B3F2, 0x03B434),
							new Tile("Key 3, right", 0x03B3F5, 0x03B3F2, 0x03B434),
							new Tile("Key 4, right", 0x03B3F6, 0x03B3F2, 0x03B434)});

			Tilemap SprA3 = new Tilemap("Gray platform on chain", "The actual platform tiles are shared with those of the brown platform? If not, then they're unknown. The properties are shared with those of the ball 'n chain.", new Tile[] {
							new Tile("Chain", 0x02D7AA, 0x02D7BF, true)});

			Tilemap SprA4 = new Tilemap("Floating spike ball", "", new Tile[] {
							new Tile("Top left", 0x01B686, 0x01B662, true),
							new Tile("Top right", 0x01B686, 0x01B663, true),
							new Tile("Bottom left", 0x01B686, 0x01B664, true),
							new Tile("Bottom right", 0x01B686, 0x01B665, true)});

			Tilemap SprA5 = new Tilemap("Wall fuzzy/sparky", "Note: The tiles are shared between each individual frame.", new Tile[] {
							new Tile("Fuzzy 1", 0x02BE6B, 0x02BE4C, true),
							new Tile("Fuzzy 2", 0x02BE6B, 0x02BE4B, true),
							new Tile("Sparky 1", 0x02BE7A, stdprop + 0xA5, true),
							new Tile("Sparky 2", 0x02BE7A, stdprop + 0xA5, true)});

			Tilemap SprA6 = new Tilemap("Hothead", "Note: The eye tiles share sizes and properties.", new Tile[] {
							new Tile("Tile 1", 0x02BE95, 0x02BE9D, true),
							new Tile("Tile 2", 0x02BE96, 0x02BE9E, true),
							new Tile("Tile 3", 0x02BE97, 0x02BE9F, true),
							new Tile("Tile 4", 0x02BE98, 0x02BEA0, true),
							new Tile("Tile 5", 0x02BE99, 0x02BEA1, true),
							new Tile("Tile 6", 0x02BE9A, 0x02BEA2, true),
							new Tile("Tile 7", 0x02BE9B, 0x02BEA3, true),
							new Tile("Tile 8", 0x02BE9C, 0x02BEA4, true),
							new Tile("Open eyes", 0x02BF0B, 0x02BF3A, 0x02BF43),
							new Tile("Closed eyes", 0x02BF12, 0x02BF3A, 0x02BF43)});

			Tilemap SprA7 = new Tilemap("Iggy's ball", "", new Tile[] {
							new Tile("Frame 1", 0x01FA4E, 0x01FA52, true),
							new Tile("Frame 2", 0x01FA4F, 0x01FA53, true),
							new Tile("Frame 3", 0x01FA50, 0x01FA54, true),
							new Tile("Frame 4", 0x01FA51, 0x01FA55, true)});

			Tilemap SprA8 = new Tilemap("Blargg", "Note: The tiles, but not the properties, are shared between the left and right facing tilemaps.", new Tile[] {
							new Tile("Eyes, looking", 0x03A075, stdprop + 0xA8, true),
							new Tile("Top left, left", 0x03A091, 0x03A09B, 0x03A0E9), 
							new Tile("Top right, left", 0x03A092, 0x03A09B, 0x03A0E9), 
							new Tile("Bottom left 1, left", 0x03A093, 0x03A09B, 0x03A0E9), 
							new Tile("Bottom right, left", 0x03A094, 0x03A09B, 0x03A0E9), 
							new Tile("Back, left", 0x03A095, 0x03A09B, 0x03A0E9), 
							new Tile("Top left, left", 0x03A096, 0x03A09B, 0x03A0E9), 
							new Tile("Top right, left", 0x03A097, 0x03A09B, 0x03A0E9), 
							new Tile("Bottom left 2, left", 0x03A098, 0x03A09B, 0x03A0E9), 
							new Tile("Bottom right, left", 0x03A099, 0x03A09B, 0x03A0E9), 
							new Tile("Back, left", 0x03A09A, 0x03A09B, 0x03A0E9),
							
							new Tile("Top left, right", 0x03A091, 0x03A09C, 0x03A0E9), 
							new Tile("Top right, right", 0x03A092, 0x03A09C, 0x03A0E9), 
							new Tile("Bottom left 1, right", 0x03A093, 0x03A09C, 0x03A0E9), 
							new Tile("Bottom right 1, right", 0x03A094, 0x03A09C, 0x03A0E9), 
							new Tile("Back, right", 0x03A095, 0x03A09C, 0x03A0E9), 
							new Tile("Top left, right", 0x03A096, 0x03A09C, 0x03A0E9), 
							new Tile("Top right, right", 0x03A097, 0x03A09C, 0x03A0E9), 
							new Tile("Bottom left 2, right", 0x03A098, 0x03A09C, 0x03A0E9), 
							new Tile("Bottom right 2, right", 0x03A099, 0x03A09C, 0x03A0E9), 
							new Tile("Back, right", 0x03A09A, 0x03A09C, 0x03A0E9)});

			Tilemap SprA9 = new Tilemap("Reznor", "", new Tile[] {
							new Tile("Normal 1", 0x039B5D, 0x039B69, 0x039BD1),
							new Tile("Normal 2", 0x039B5E, 0x039B6A, 0x039BD1),
							new Tile("Normal 3", 0x039B5F, 0x039B6B, 0x039BD1),
							new Tile("Normal 4", 0x039B60, 0x039B6C, 0x039BD1),
							new Tile("Shooting fire 1", 0x039B61, 0x039B6D, 0x039BD1),
							new Tile("Shooting fire 2", 0x039B62, 0x039B6E, 0x039BD1),
							new Tile("Shooting fire 3", 0x039B63, 0x039B6F, 0x039BD1),
							new Tile("Shooting fire 4", 0x039B64, 0x039B70, 0x039BD1),
							new Tile("Turning 1", 0x039B65, 0x039B71, 0x039BD1),
							new Tile("Turning 2", 0x039B66, 0x039B72, 0x039BD1),
							new Tile("Turning 3", 0x039B67, 0x039B73, 0x039BD1),
							new Tile("Turning 4", 0x039B68, 0x039B74, 0x039BD1),
							new Tile("Fireball 1", 0x02A163, 0x02A167, 0x02A19E),
							new Tile("Fireball 2", 0x02A164, 0x02A168, 0x02A19E),
							new Tile("Fireball 3", 0x02A165, 0x02A169, 0x02A19E),
							new Tile("Fireball 4", 0x02A166, 0x02A16A, 0x02A19E)});

			Tilemap SprAA = new Tilemap("Fishbone", "", new Tile[] {
							new Tile("Body 1", 0x039799, stdprop + 0xAA, true),
							new Tile("Body 2", 0x03979D, stdprop + 0xAA, true),
							new Tile("Tail 1", 0x039788, stdprop + 0xAA, true),
							new Tile("Tail 2", 0x039789, stdprop + 0xAA, true),
							new Tile("Tail 3", 0x03978A, stdprop + 0xAA, true),
							new Tile("Tail 4", 0x03978B, stdprop + 0xAA, true)});

			Tilemap SprAB = new Tilemap("Rex", "Note: The left and right tilemaps share tiles, but have different properties.", new Tile[] {
							new Tile("Head 1, right", 0x039670, 0x03967C, 0x0396E0),
							new Tile("Body 1, right", 0x039671, 0x03967C, 0x0396E0),
							new Tile("Head 2, right", 0x039672, 0x03967C, 0x0396E0),
							new Tile("Body 2, right", 0x039673, 0x03967C, 0x0396E0),
							new Tile("Head half squished, right", 0x039674, 0x03967C, 0x0396E0),
							new Tile("Body half squished, right", 0x039675, 0x03967C, 0x0396E0),
							new Tile("Walking half squished 1, right", 0x039676, 0x03967C, 0x0396E0),
							new Tile("Walking half squished 2, right", 0x039677, 0x03967C, 0x0396E0),
							new Tile("Walking half squished 3, right", 0x039678, 0x03967C, 0x0396E0),
							new Tile("Walking half squished 4, right", 0x039679, 0x03967C, 0x0396E0),
							new Tile("Squished left, right", 0x03967A, 0x03967C, 0x0396DC),
							new Tile("Squished right, right", 0x03967B, 0x03967C, 0x0396DC),
							
							new Tile("Head 1, left", 0x039670, 0x03967D, 0x0396E0),
							new Tile("Body 1, left", 0x039671, 0x03967D, 0x0396E0),
							new Tile("Head 2, left", 0x039672, 0x03967D, 0x0396E0),
							new Tile("Body 2, left", 0x039673, 0x03967D, 0x0396E0),
							new Tile("Head half squished, left", 0x039674, 0x03967D, 0x0396E0),
							new Tile("Body half squished, left", 0x039675, 0x03967D, 0x0396E0),
							new Tile("Walking half squished 1, left", 0x039676, 0x03967D, 0x0396E0),
							new Tile("Walking half squished 2, left", 0x039677, 0x03967D, 0x0396E0),
							new Tile("Walking half squished 3, left", 0x039678, 0x03967D, 0x0396E0),
							new Tile("Walking half squished 4, left", 0x039679, 0x03967D, 0x0396E0),
							new Tile("Squished left, left", 0x03967A, 0x03967D, 0x0396DC),
							new Tile("Squished right, left", 0x03967B, 0x03967D, 0x0396DC)});

			Tilemap SprAC = new Tilemap("Upside-down wooden spike", "", new Tile[] {
							new Tile("Pole 1", 0x0394BB, 0x0394C5, 0x03950B),
							new Tile("Pole 2", 0x0394BC, 0x0394C6, 0x03950B),
							new Tile("Pole 3", 0x0394BD, 0x0394C7, 0x03950B),
							new Tile("Pole 4", 0x0394BE, 0x0394C8, 0x03950B),
							new Tile("Spike", 0x0394BF, 0x0394C9, 0x03950B)});

			Tilemap SprAD = new Tilemap("Wooden spike", "", new Tile[] {
							new Tile("Pole 1", 0x0394C0, 0x0394CA, 0x03950B),
							new Tile("Pole 2", 0x0394C1, 0x0394CB, 0x03950B),
							new Tile("Pole 3", 0x0394C2, 0x0394CC, 0x03950B),
							new Tile("Pole 4", 0x0394C3, 0x0394CD, 0x03950B),
							new Tile("Spike", 0x0394C4, 0x0394CE, 0x03950B)});

			Tilemap SprAE = new Tilemap("Fishin' Boo", "Note: All flame tiles' properties are shared.", new Tile[] {
							new Tile("Cloud 1", 0x039160, 0x03916A, 0x03920C),
							new Tile("Cloud 2", 0x039161, 0x03916B, 0x03920C),
							new Tile("Head 1", 0x039162, 0x03916C, 0x03920C),
							new Tile("Fishing rod", 0x039163, 0x03916D, 0x03920C),
							new Tile("Cloud 3", 0x039164, 0x03916E, 0x03920C),
							new Tile("Cloud 4", 0x039165, 0x03916F, 0x03920C),
							new Tile("Fishing line 1", 0x039166, 0x039170, 0x03920C),
							new Tile("Fishing line 2", 0x039167, 0x039171, 0x03920C),
							new Tile("Fishing line 3", 0x039168, 0x039172, 0x03920C),
							new Tile("Flame (unused?)", 0x039169, 0x039173, 0x03920C),
							new Tile("Flame 1", 0x039174, 0x039173, 0x03920C),
							new Tile("Flame 2", 0x039175, 0x039173, 0x03920C),
							new Tile("Flame 3", 0x039176, 0x039173, 0x03920C),
							new Tile("Flame 4", 0x039177, 0x039173, 0x03920C)});

			Tilemap SprAF = new Tilemap("Boo block", "", new Tile[] {
							new Tile("Normal", 0x01FA37, stdprop + 0xAF, true),
							new Tile("Solidifying", 0x01FA38, stdprop + 0xAF, true),
							new Tile("Block", 0x01FA39, stdprop + 0xAF, true)});

			Tilemap SprB0 = new Tilemap("Boo stream", "", new Tile[] {
							new Tile("Tile 1", 0x038F6D, stdprop + 0xB0, true),
							new Tile("Tile 2", 0x038F6E, stdprop + 0xB0, true),
							new Tile("Tile 3", 0x038F6F, stdprop + 0xB0, true),
							new Tile("Tile 4", 0x038F70, stdprop + 0xB0, true),
							new Tile("Tile 5", 0x038F71, stdprop + 0xB0, true),
							new Tile("Tile 6", 0x038F72, stdprop + 0xB0, true),
							new Tile("Tile 7", 0x038F73, stdprop + 0xB0, true),
							new Tile("Tile 8", 0x038F74, stdprop + 0xB0, true)});

			Tilemap SprB1 = new Tilemap("Creating/eating block", "", new Tile[] {
							new Tile("Tile", 0x039293, stdprop + 0xB1, 0x0392A0)});

			Tilemap SprB2 = new Tilemap("Falling spike", "", new Tile[] {
							new Tile("Tile", 0x03921C, stdprop + 0xB2, true)});

			Tilemap SprB3 = new Tilemap("Bowser statue fireball", "", new Tile[] {
							new Tile("Frame 1, tile 1", 0x038F0B, 0x038F13, 0x038F65),
							new Tile("Frame 1, tile 2", 0x038F0C, 0x038F14, 0x038F65),
							new Tile("Frame 2, tile 1", 0x038F0D, 0x038F15, 0x038F65),
							new Tile("Frame 2, tile 2", 0x038F0E, 0x038F16, 0x038F65),
							new Tile("Frame 3, tile 1", 0x038F0F, 0x038F17, 0x038F65),
							new Tile("Frame 3, tile 2", 0x038F10, 0x038F18, 0x038F65),
							new Tile("Frame 4, tile 1", 0x038F11, 0x038F19, 0x038F65),
							new Tile("Frame 4, tile 2", 0x038F12, 0x038F1A, 0x038F65)});

			Tilemap SprB4 = new Tilemap("Grinder", "Note: In order to animate correctly, the tile must end in C (0C, 1C, 2C, 3C, etc). All four tiles use the same tile, but different properties.", new Tile[] {
							new Tile("Top left", 0x01DBBF, 0x01DB9E, true),
							new Tile("Top right", 0x01DBBF, 0x01DB9F, true),
							new Tile("Bottom left", 0x01DBBF, 0x01DBA0, true),
							new Tile("Bottom right", 0x01DBBF, 0x01DBA1, true)});

			Tilemap SprB5 = new Tilemap("Bowser fireball", "", new Tile[] {
							new Tile("Frame 1", 0x01E190, 0x01E194, true),
							new Tile("Frame 2", 0x01E191, 0x01E195, true),
							new Tile("Frame 3", 0x01E192, 0x01E196, true),
							new Tile("Frame 4", 0x01E193, 0x01E197, true)});

			Tilemap SprB6 = new Tilemap("Reflecting podoboo", "", new Tile[] {
							new Tile("Tile", 0x039011, stdprop + 0xB6, true)});

			Tilemap SprB7 = new Tilemap("Carrot top lift, upper right", "Note: This tilemap is shared between both carrot top lifts.", new Tile[] {
							new Tile("Top right", 0x038D18, 0x038D1E, true),
							new Tile("Bottom right", 0x038D19, 0x038D1F, true),
							new Tile("Bottom left", 0x038D1A, 0x038D20, true)});

			Tilemap SprB8 = new Tilemap("Carrot top lift, upper left", "Note: This tilemap is shared between both carrot top lifts.", new Tile[] {
							new Tile("Top right", 0x038D1B, 0x038D21, true),
							new Tile("Bottom right", 0x038D1C, 0x038D22, true),
							new Tile("Bottom left", 0x038D1D, 0x038D23, true)});

			Tilemap SprB9 = new Tilemap("Info box", "", new Tile[] {
							new Tile("Tile", 0x038DB0, stdprop + 0xB9, true)});

			Tilemap SprBA = new Tilemap("Timed lift", "", new Tile[] {
							new Tile("Platform left", 0x038E05, 0x038E08, 0x038E0B),
							new Tile("Platform right", 0x038E06, 0x038E09, 0x038E0C),
							new Tile("1", 0x038E0E, 0x038E0A, 0x038E0D),
							new Tile("2", 0x038E0F, 0x038E0A, 0x038E0D),
							new Tile("3", 0x038E10, 0x038E0A, 0x038E0D),
							new Tile("4", 0x038E11, 0x038E0A, 0x038E0D)});

			Tilemap SprBB = new Tilemap("Moving castle block", "", new Tile[] {
							new Tile("Top left", 0x038EB0, 0x038ED3, 0x038EE2),
							new Tile("Top right", 0x038EB1, 0x038ED3, 0x038EE2),
							new Tile("Bottom left", 0x038EB2, 0x038ED3, 0x038EE2),
							new Tile("Bottom right", 0x038EB3, 0x038ED3, 0x038EE2)});

			Tilemap SprBC = new Tilemap("Bowser statue", "", new Tile[] {
							new Tile("Foot", 0x038B2E, stdprop + 0xBC, 0x038B34),
							new Tile("Head, standing", 0x038B2F, stdprop + 0xBC, 0x038B35),
							new Tile("Body, standing", 0x038B30, stdprop + 0xBC, 0x038B36),
							new Tile("Foot", 0x038B31, stdprop + 0xBC, 0x038B34),
							new Tile("Head, jumping", 0x038B32, stdprop + 0xBC, 0x038B35),
							new Tile("Body, jumping", 0x038B33, stdprop + 0xBC, 0x038B36)});

			Tilemap SprBD = new Tilemap("Sliding blue koopa", "", new Tile[] {
							new Tile("Sliding", 0x038984, stdprop + 0xBD, true),
							new Tile("Standing", 0x038988, stdprop + 0xBD, true)});

			Tilemap SprBE = new Tilemap("Swooper", "", new Tile[] {
							new Tile("Sleeping", 0x0388A0, stdprop + 0xBE, true),
							new Tile("Flying 1", 0x0388A1, stdprop + 0xBE, true),
							new Tile("Flying 2", 0x0388A2, stdprop + 0xBE, true)});

			Tilemap SprBF = new Tilemap("Mega mole", "", new Tile[] {
							new Tile("Frame 1, top left", 0x038837, 0x038882, 0x038898),
							new Tile("Frame 1, top right", 0x038838, 0x038882, 0x038898),
							new Tile("Frame 1, bottom left", 0x038839, 0x038882, 0x038898),
							new Tile("Frame 1, bottom right", 0x03883A, 0x038882, 0x038898),
							new Tile("Frame 2, top left", 0x03883B, 0x038882, 0x038898),
							new Tile("Frame 2, top right", 0x03883C, 0x038882, 0x038898),
							new Tile("Frame 2, bottom left", 0x03883D, 0x038882, 0x038898),
							new Tile("Frame 2, bottom right", 0x03883E, 0x038882, 0x038898)});

			Tilemap SprC0 = new Tilemap("Gray sinking platform", "", new Tile[] {
							new Tile("Left", 0x038734, 0x038737, 0x038766),
							new Tile("Middle", 0x038735, 0x038738, 0x038766),
							new Tile("Right", 0x038736, 0x038739, 0x038766)});

			Tilemap SprC1 = new Tilemap("Flying turn block platform", "", new Tile[] {
							new Tile("Block 1, frame 1", 0x03868A, 0x038694, 0x03869E),
							new Tile("Block 2, frame 1", 0x03868B, 0x038695, 0x03869F),
							new Tile("Block 3, frame 1", 0x03868C, 0x038696, 0x0386A0),
							new Tile("Wing 1, frame 1", 0x03868D, 0x038697, 0x0386A1),
							new Tile("Wing 2, frame 1", 0x03868E, 0x038698, 0x0386A2),
							new Tile("Block 1, frame 2", 0x03868F, 0x038699, 0x0386A3),
							new Tile("Block 2, frame 2", 0x038690, 0x03869A, 0x0386A4),
							new Tile("Block 3, frame 2", 0x038691, 0x03869B, 0x0386A5),
							new Tile("Wing 1, frame 2", 0x038692, 0x03869C, 0x0386A6),
							new Tile("Wing 2, frame 2", 0x038693, 0x03869D, 0x0386A7)});

			Tilemap SprC2 = new Tilemap("Blurp", "", new Tile[] {
							new Tile("Frame 1", 0x0384DD, stdprop + 0xC2, true),
							new Tile("Frame 2", 0x0384E1, stdprop + 0xC2, true)});

			Tilemap SprC3 = new Tilemap("Porcu-puffer", "", new Tile[] {
							new Tile("Top left, frame 1", 0x038593, 0x03859B, 0x0385EC),
							new Tile("Top right, frame 1", 0x038594, 0x03859C, 0x0385EC),
							new Tile("Top left, frame 1", 0x038595, 0x03859D, 0x0385EC),
							new Tile("Top right, frame 1", 0x038596, 0x03859E, 0x0385EC),
							new Tile("Bottom left, frame 2", 0x038597, 0x03859F, 0x0385EC),
							new Tile("Bottom right, frame 2", 0x038598, 0x0385A0, 0x0385EC),
							new Tile("Bottom left, frame 2", 0x038599, 0x0385A1, 0x0385EC),
							new Tile("Bottom right, frame 2", 0x03859A, 0x0385A2, 0x0385EC)});

			Tilemap SprC4 = new Tilemap("Gray falling platform", "", new Tile[] {
							new Tile("Tile 1", 0x03848E, 0x0384AD, 0x0384BC),
							new Tile("Tile 2", 0x03848F, 0x0384AD, 0x0384BC),
							new Tile("Tile 3", 0x038490, 0x0384AD, 0x0384BC),
							new Tile("Tile 4", 0x038491, 0x0384AD, 0x0384BC)});

			Tilemap SprC5 = new Tilemap("Big boo boss", "Yeah, good luck with this...again...", new Tile[] {
							new Tile("Tile 1", 0x0382F8, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 2", 0x0382F9, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 3", 0x0382FA, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 4", 0x0382FB, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 5", 0x0382FC, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 6", 0x0382FD, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 7", 0x0382FE, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 8", 0x0382FF, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 9", 0x038300, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 10", 0x038301, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 11", 0x038302, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 12", 0x038303, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 13", 0x038304, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 14", 0x038305, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 15", 0x038306, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 16", 0x038307, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 17", 0x038308, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 18", 0x038309, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 19", 0x03830A, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 20", 0x03830B, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 21", 0x03830C, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 22", 0x03830D, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 23", 0x03830E, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 24", 0x03830F, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 25", 0x038310, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 26", 0x038311, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 27", 0x038312, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 28", 0x038313, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 29", 0x038314, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 30", 0x038315, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 31", 0x038316, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 32", 0x038317, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 33", 0x038318, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 34", 0x038319, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 35", 0x03831A, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 36", 0x03831B, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 37", 0x03831C, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 38", 0x03831D, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 39", 0x03831E, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 40", 0x03831F, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 41", 0x038320, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 42", 0x038321, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 43", 0x038322, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 44", 0x038323, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 45", 0x038324, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 46", 0x038325, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 47", 0x038326, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 48", 0x038327, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 49", 0x038328, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 50", 0x038329, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 51", 0x03832A, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 52", 0x03832B, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 53", 0x03832C, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 54", 0x03832D, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 55", 0x03832E, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 56", 0x03832F, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 57", 0x038330, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 58", 0x038331, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 59", 0x038332, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 60", 0x038333, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 61", 0x038334, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 62", 0x038335, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 63", 0x038336, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 64", 0x038337, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 65", 0x038338, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 66", 0x038339, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 67", 0x03833A, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 68", 0x03833B, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 69", 0x03833C, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 70", 0x03833D, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 71", 0x03833E, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 72", 0x03833F, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 73", 0x038340, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 74", 0x038341, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 75", 0x038342, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 76", 0x038343, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 77", 0x038344, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 78", 0x038345, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 79", 0x038346, stdprop + 0xC5, 0x03844E),
							new Tile("Tile 80", 0x038347, stdprop + 0xC5, 0x03844E)});

			Tilemap SprC6 = new Tilemap("Disco ball", "", new Tile[] {
							new Tile("Frame 1", 0x03C493, 0x03C49C, 0x03C4D2),
							new Tile("Frame 2", 0x03C494, 0x03C49D, 0x03C4D2),
							new Tile("Frame 3", 0x03C495, 0x03C49E, 0x03C4D2),
							new Tile("Frame 4", 0x03C496, 0x03C49F, 0x03C4D2),
							new Tile("Frame 5", 0x03C497, 0x03C4A0, 0x03C4D2),
							new Tile("Frame 6", 0x03C498, 0x03C4A1, 0x03C4D2),
							new Tile("Frame 7", 0x03C499, 0x03C4A2, 0x03C4D2),
							new Tile("Frame 8", 0x03C49A, 0x03C4A3, 0x03C4D2),
							new Tile("Frame 9", 0x03C49B, 0x03C4A4, 0x03C4D2)});

			Tilemap SprC7 = new Tilemap("Invisible mushroom", "Hopefully I don't have to explain why there's no tilemap to edit...", new Tile[] { });

			Tilemap SprC8 = new Tilemap("Light switch", "", new Tile[] {
							new Tile("Tile", 0x03C248, stdprop + 0xC8, true)});

			ComboBox.ObjectCollection o = spriteTilemapSelector.Items;
			o.Add(Spr00);
			o.Add(Spr01);
			o.Add(Spr02);
			o.Add(Spr03);
			o.Add(Spr04);
			o.Add(Spr05);
			o.Add(Spr06);
			o.Add(Spr07);
			o.Add(Spr08);
			o.Add(Spr09);
			o.Add(Spr0A);
			o.Add(Spr0B);
			o.Add(Spr0C);
			o.Add(Spr0D);
			o.Add(Spr0E);
			o.Add(Spr0F);
			o.Add(Spr10);
			o.Add(Spr11);
			o.Add(Spr12);
			o.Add(Spr13);
			o.Add(Spr14);
			o.Add(Spr15);
			o.Add(Spr16);
			o.Add(Spr17);
			o.Add(Spr18);
			o.Add(Spr19);
			o.Add(Spr1A);
			o.Add(Spr1B);
			o.Add(Spr1C);
			o.Add(Spr1D);
			o.Add(Spr1E);
			o.Add(Spr1F);
			o.Add(Spr20);
			o.Add(Spr21);
			o.Add(Spr22);
			o.Add(Spr23);
			o.Add(Spr24);
			o.Add(Spr25);
			o.Add(Spr26);
			o.Add(Spr27);
			o.Add(Spr28);
			o.Add(Spr29);
			o.Add(Spr2A);
			o.Add(Spr2B);
			o.Add(Spr2C);
			o.Add(Spr2D);
			o.Add(Spr2E);
			o.Add(Spr2F);
			o.Add(Spr30);
			o.Add(Spr31);
			o.Add(Spr32);
			o.Add(Spr33);
			o.Add(Spr34);
			o.Add(Spr35);
			o.Add(Spr36);
			o.Add(Spr37);
			o.Add(Spr38);
			o.Add(Spr39);
			o.Add(Spr3A);
			o.Add(Spr3B);
			o.Add(Spr3C);
			o.Add(Spr3D);
			o.Add(Spr3E);
			o.Add(Spr3F);
			o.Add(Spr40);
			o.Add(Spr41);
			o.Add(Spr42);
			o.Add(Spr43);
			o.Add(Spr44);
			o.Add(Spr45);
			o.Add(Spr46);
			o.Add(Spr47);
			o.Add(Spr48);
			o.Add(Spr49);
			o.Add(Spr4A);
			o.Add(Spr4B);
			o.Add(Spr4C);
			o.Add(Spr4D);
			o.Add(Spr4E);
			o.Add(Spr4F);
			o.Add(Spr50);
			o.Add(Spr51);
			o.Add(Spr52);
			o.Add(Spr53);
			o.Add(Spr54);
			o.Add(Spr55);
			o.Add(Spr56);
			o.Add(Spr57);
			o.Add(Spr58);
			o.Add(Spr59);
			o.Add(Spr5A);
			o.Add(Spr5B);
			o.Add(Spr5C);
			o.Add(Spr5D);
			o.Add(Spr5E);
			o.Add(Spr5F);
			o.Add(Spr60);
			o.Add(Spr61);
			o.Add(Spr62);
			o.Add(Spr63);
			o.Add(Spr64);
			o.Add(Spr65);
			o.Add(Spr66);
			o.Add(Spr67);
			o.Add(Spr68);
			o.Add(Spr69);
			o.Add(Spr6A);
			o.Add(Spr6B);
			o.Add(Spr6C);
			o.Add(Spr6D);
			o.Add(Spr6E);
			o.Add(Spr6F);
			o.Add(Spr70);
			o.Add(Spr71);
			o.Add(Spr72);
			o.Add(Spr73);
			o.Add(Spr74);
			o.Add(Spr75);
			o.Add(Spr76);
			o.Add(Spr77);
			o.Add(Spr78);
			o.Add(Spr79);
			o.Add(Spr7A);
			o.Add(Spr7B);
			o.Add(Spr7C);
			o.Add(Spr7D);
			o.Add(Spr7E);
			o.Add(Spr7F);
			o.Add(Spr80);
			o.Add(Spr81);
			o.Add(Spr82);
			o.Add(Spr83);
			o.Add(Spr84);
			o.Add(Spr85);
			o.Add(Spr86);
			o.Add(Spr87);
			o.Add(Spr88);
			o.Add(Spr89);
			o.Add(Spr8A);
			o.Add(Spr8B);
			o.Add(Spr8C);
			o.Add(Spr8D);
			o.Add(Spr8E);
			o.Add(Spr8F);
			o.Add(Spr90);
			o.Add(Spr91);
			o.Add(Spr92);
			o.Add(Spr93);
			o.Add(Spr94);
			o.Add(Spr95);
			o.Add(Spr96);
			o.Add(Spr97);
			o.Add(Spr98);
			o.Add(Spr99);
			o.Add(Spr9A);
			o.Add(Spr9B);
			o.Add(Spr9C);
			o.Add(Spr9D);
			o.Add(Spr9E);
			o.Add(Spr9F);
			o.Add(SprA0);
			o.Add(SprA1);
			o.Add(SprA2);
			o.Add(SprA3);
			o.Add(SprA4);
			o.Add(SprA5);
			o.Add(SprA6);
			o.Add(SprA7);
			o.Add(SprA8);
			o.Add(SprA9);
			o.Add(SprAA);
			o.Add(SprAB);
			o.Add(SprAC);
			o.Add(SprAD);
			o.Add(SprAE);
			o.Add(SprAF);
			o.Add(SprB0);
			o.Add(SprB1);
			o.Add(SprB2);
			o.Add(SprB3);
			o.Add(SprB4);
			o.Add(SprB5);
			o.Add(SprB6);
			o.Add(SprB7);
			o.Add(SprB8);
			o.Add(SprB9);
			o.Add(SprBA);
			o.Add(SprBB);
			o.Add(SprBC);
			o.Add(SprBD);
			o.Add(SprBE);
			o.Add(SprBF);
			o.Add(SprC0);
			o.Add(SprC1);
			o.Add(SprC2);
			o.Add(SprC3);
			o.Add(SprC4);
			o.Add(SprC5);
			o.Add(SprC6);
			o.Add(SprC7);
			o.Add(SprC8);


			//spriteTilemapSelector.SelectedIndex = 0;
		}

		private void InitClusterSprites()
		{
			ComboBox.ObjectCollection o = clusterSpriteTilemapSelector.Items;

			Tilemap Spr01 = new Tilemap("Bonus game 1-UPs", "", new Tile[] {
							new Tile("Tile", 0x02FE5E, 0x02FE63, 0x02FE6C)});

			Tilemap Spr02 = new Tilemap("Null", "No tilemap to edit!", new Tile[] { });

			Tilemap Spr03 = new Tilemap("Boo from boo ceiling", "Note: Tilemap is shared with the boos from the boo rings and boo cloud.", new Tile[] {
							new Tile("Tile 1", 0x02FBBF, 0x02FD82, 0x02FD8D),
							new Tile("Tile 2", 0x02FBC0, 0x02FD82, 0x02FD8D),
							new Tile("Tile 3", 0x02FBC1, 0x02FD82, 0x02FD8D),
							new Tile("Tile 4", 0x02FBC2, 0x02FD82, 0x02FD8D),
							new Tile("Tile 5", 0x02FBC3, 0x02FD82, 0x02FD8D),
							new Tile("Tile 6", 0x02FBC4, 0x02FD82, 0x02FD8D),
							new Tile("Tile 7", 0x02FBC5, 0x02FD82, 0x02FD8D),
							new Tile("Tile 8", 0x02FBC6, 0x02FD82, 0x02FD8D)});

			Tilemap Spr04 = new Tilemap("Boo from boo ring", "Note: Tilemap is shared with the boos from the boo ceiling and boo cloud.", new Tile[] {
							new Tile("Tile 1", 0x02FBBF, 0x02FD82, 0x02FD8D),
							new Tile("Tile 2", 0x02FBC0, 0x02FD82, 0x02FD8D),
							new Tile("Tile 3", 0x02FBC1, 0x02FD82, 0x02FD8D),
							new Tile("Tile 4", 0x02FBC2, 0x02FD82, 0x02FD8D),
							new Tile("Tile 5", 0x02FBC3, 0x02FD82, 0x02FD8D),
							new Tile("Tile 6", 0x02FBC4, 0x02FD82, 0x02FD8D),
							new Tile("Tile 7", 0x02FBC5, 0x02FD82, 0x02FD8D),
							new Tile("Tile 8", 0x02FBC6, 0x02FD82, 0x02FD8D)});

			Tilemap Spr05 = new Tilemap("Castle flames", "", new Tile[] {
							new Tile("Frame 1", 0x02FA0E, 0x02FA12, 0x02FA5A),
							new Tile("Frame 2", 0x02FA0F, 0x02FA13, 0x02FA5A),
							new Tile("Frame 3", 0x02FA10, 0x02FA14, 0x02FA5A),
							new Tile("Frame 4", 0x02FA11, 0x02FA15, 0x02FA5A)});

			Tilemap Spr06 = new Tilemap("Sumo bros. lightning", "", new Tile[] {
							new Tile("Flame 1", 0x02F904, 0x02F98F, true),
							new Tile("Flame 2", 0x02F905, 0x02F98F, true),
							new Tile("Flame 3", 0x02F906, 0x02F98F, true),
							new Tile("Flame 4", 0x02F907, 0x02F98F, true),
							new Tile("Flame 5", 0x02F908, 0x02F98F, true),
							new Tile("Flame 6", 0x02F909, 0x02F98F, true),
							new Tile("Unused?", 0x02F90A, 0x02F98F, true),
							new Tile("Flame 7", 0x02F90B, 0x02F98F, true)});

			Tilemap Spr07 = new Tilemap("Boo from boo cloud", "Note: Tilemap is shared with the boos from the boo rings and boo ceiling.", new Tile[] {
							new Tile("Tile 1", 0x02FBBF, 0x02FD82, 0x02FD8D),
							new Tile("Tile 2", 0x02FBC0, 0x02FD82, 0x02FD8D),
							new Tile("Tile 3", 0x02FBC1, 0x02FD82, 0x02FD8D),
							new Tile("Tile 4", 0x02FBC2, 0x02FD82, 0x02FD8D),
							new Tile("Tile 5", 0x02FBC3, 0x02FD82, 0x02FD8D),
							new Tile("Tile 6", 0x02FBC4, 0x02FD82, 0x02FD8D),
							new Tile("Tile 7", 0x02FBC5, 0x02FD82, 0x02FD8D),
							new Tile("Tile 8", 0x02FBC6, 0x02FD82, 0x02FD8D)});

			Tilemap Spr08 = new Tilemap("Death bat ceiling", "", new Tile[] {
							new Tile("Sleeping 1", 0x02FDB8, 0x02FDB2, 0x02FD8D),
							new Tile("Sleeping 2", 0x02FDB9, 0x02FDB2, 0x02FD8D),
							new Tile("Flying 1", 0x02FDBA, 0x02FDB2, 0x02FD8D),
							new Tile("Flying 2", 0x02FDBB, 0x02FDB2, 0x02FD8D)});

			o.Add(Spr01);
			o.Add(Spr02);
			o.Add(Spr03);
			o.Add(Spr04);
			o.Add(Spr05);
			o.Add(Spr06);
			o.Add(Spr07);
			o.Add(Spr08);
		}

		private void InitBounceSprites()
		{
			ComboBox.ObjectCollection o = bounceSpriteTilemapSelector.Items;

			Tilemap Spr01 = new Tilemap("Turn block with item", "Note: All bounce sprites' sizes are shared.", new Tile[] {
							new Tile("Tile", 0x0291F1, 0x028789, 0x02925D)});

			Tilemap Spr02 = new Tilemap("Note block", "Note: All bounce sprites' sizes are shared.", new Tile[] {
							new Tile("Tile", 0x0291F2, 0x02878A, 0x02925D)});

			Tilemap Spr03 = new Tilemap("? block", "Note: All bounce sprites' sizes are shared.", new Tile[] {
							new Tile("Tile", 0x0291F3, 0x02878B, 0x02925D)});

			Tilemap Spr04 = new Tilemap("Side turn block", "Note: All bounce sprites' sizes are shared.", new Tile[] {
							new Tile("Tile", 0x0291F4, 0x02878C, 0x02925D)});

			Tilemap Spr05 = new Tilemap("Glass block", "Note: All bounce sprites' sizes are shared.", new Tile[] {
							new Tile("Tile", 0x0291F5, 0x02878D, 0x02925D)});

			Tilemap Spr06 = new Tilemap("ON/OFF block", "Note: All bounce sprites' sizes are shared.", new Tile[] {
							new Tile("Tile", 0x0291F6, 0x02878E, 0x02925D)});

			Tilemap Spr07 = new Tilemap("Turn block", "Note: All bounce sprites' sizes are shared.", new Tile[] {
							new Tile("Tile", 0x0291F7, 0x02878F, 0x02925D)});

			o.Add(Spr01);
			o.Add(Spr02);
			o.Add(Spr03);
			o.Add(Spr04);
			o.Add(Spr05);
			o.Add(Spr06);
			o.Add(Spr07);
		}

		private void InitExtendedSprites()
		{
			ComboBox.ObjectCollection o = extendedSpriteTilemapSelector.Items;

			Tilemap Spr01 = new Tilemap("Dust cloud", "", new Tile[] {
							new Tile("Frame 1", 0x02A347, 0x02A34B, 0x02A3A6),
							new Tile("Frame 2", 0x02A348, 0x02A34C, 0x02A3A6),
							new Tile("Frame 3", 0x02A349, 0x02A34D, 0x02A3A6),
							new Tile("Frame 4", 0x02A34A, 0x02A34E, 0x02A3A6)});

			Tilemap Spr02 = new Tilemap("Reznor fireball", "", new Tile[] {
							new Tile("Frame 1", 0x02A163, 0x02A167, 0x02A19E),
							new Tile("Frame 2", 0x02A164, 0x02A168, 0x02A19E),
							new Tile("Frame 3", 0x02A165, 0x02A169, 0x02A19E),
							new Tile("Frame 4", 0x02A166, 0x02A16A, 0x02A19E)});

			Tilemap Spr03 = new Tilemap("Hopping flame remnant", "", new Tile[] {
							new Tile("Frame 1", 0x02A217, 0x02A24C, false),
							new Tile("Frame 2", 0x02A218, 0x02A24C, false)});

			Tilemap Spr04 = new Tilemap("Hammer", "", new Tile[] {
							new Tile("Frame 1", 0x02A2DF, 0x02A2E7, 0x02A33E),
							new Tile("Frame 2", 0x02A2E0, 0x02A2E8, 0x02A33E),
							new Tile("Frame 3", 0x02A2E1, 0x02A2E9, 0x02A33E),
							new Tile("Frame 4", 0x02A2E2, 0x02A2EA, 0x02A33E),
							new Tile("Frame 5", 0x02A2E3, 0x02A2EB, 0x02A33E),
							new Tile("Frame 6", 0x02A2E4, 0x02A2EC, 0x02A33E),
							new Tile("Frame 7", 0x02A2E5, 0x02A2ED, 0x02A33E),
							new Tile("Frame 8", 0x02A2E6, 0x02A2EE, 0x02A33E)});

			Tilemap Spr05 = new Tilemap("Mario fireball", "Note: This tilemap is shared with Mario's fireball.", new Tile[] {
							new Tile("Frame 1", 0x02A15B, 0x02A15F, 0x02A0A1),
							new Tile("Frame 2", 0x02A15C, 0x02A160, 0x02A0A1),
							new Tile("Frame 3", 0x02A15D, 0x02A161, 0x02A0A1),
							new Tile("Frame 4", 0x02A15E, 0x02A162, 0x02A0A1)});

			Tilemap Spr06 = new Tilemap("Dry bones thrown bone", "Note: This tilemap's tiles' sizes are shared with those of the hammer.", new Tile[] {
							new Tile("Frame 1", 0x02A2CC, 0x02A2DA, 0x02A33E),
							new Tile("Frame 2", 0x02A2D0, 0x02A2DA, 0x02A33E)});

			Tilemap Spr07 = new Tilemap("Lava splash", "", new Tile[] {
							new Tile("Frame 1", 0x028F2B, 0x028F76, 0x028F82),
							new Tile("Frame 2", 0x028F2C, 0x028F76, 0x028F82),
							new Tile("Frame 3", 0x028F2D, 0x028F76, 0x028F82),
							new Tile("Frame 4", 0x028F2E, 0x028F76, 0x028F82)});

			Tilemap Spr08 = new Tilemap("Torpedo Ted dispenser arm", "Note: These are forced onto the second page for some unknown reason.", new Tile[] {
							new Tile("Hand closed", 0x029E66, 0x02A2DA, 0x029E7D),
							new Tile("Hand open", 0x029E6A, 0x029E74, 0x029E7D)});

			Tilemap Spr09 = new Tilemap("Unused", "", new Tile[] {
							new Tile("Frame 1", 0x029D92, true, false),
							new Tile("Frame 2", 0x029D93, true, false),
							new Tile("Frame 3", 0x029D94, true, false),
							new Tile("Frame 4", 0x029D95, true, false),
							new Tile("Frame 5", 0x029D96, true, false),
							new Tile("Frame 6", 0x029D97, true, false),
							new Tile("Frame 7", 0x029D98, true, false),
							new Tile("Frame 8", 0x029D99, true, false),
							new Tile("Frame 9", 0x029D9A, true, false),
							new Tile("Frame 10", 0x029D9B, true, false),
							new Tile("Frame 11", 0x029D9C, true, false),
							new Tile("Frame 12", 0x029D9D, true, false)});

			Tilemap Spr0A = new Tilemap("Coin game cloud coin", "", new Tile[] {
							new Tile("Tile", 0x029D4B, 0x029D50, 0x029D55)});

			Tilemap Spr0B = new Tilemap("Piranha fireball", "Note: This tilemap is shared with Mario's fireball.", new Tile[] {
							new Tile("Frame 1", 0x02A15B, 0x02A15F, 0x02A0A1),
							new Tile("Frame 2", 0x02A15C, 0x02A160, 0x02A0A1),
							new Tile("Frame 3", 0x02A15D, 0x02A161, 0x02A0A1),
							new Tile("Frame 4", 0x02A15E, 0x02A162, 0x02A0A1)});

			Tilemap Spr0C = new Tilemap("Volcano lotus fireball", "", new Tile[] {
							new Tile("Frame 1", 0x029B94, 0x029B84, 0x029BA1),
							new Tile("Frame 2", 0x029B98, 0x029B84, 0x029BA1)});

			Tilemap Spr0D = new Tilemap("Baseball", "", new Tile[] {
							new Tile("Tile", 0x02A2A4, 0x02A2B1, 0x02A2BA)});

			Tilemap Spr0E = new Tilemap("Wiggler's flower", "", new Tile[] {
							new Tile("Tile", 0x029D30, 0x029D35, 0x029D40)});

			Tilemap Spr0F = new Tilemap("Yoshi stomp dust", "", new Tile[] {
							new Tile("Frame 1", 0x029C33, 0x029C53, 0x029C62),
							new Tile("Frame 2", 0x029C34, 0x029C53, 0x029C62),
							new Tile("Frame 3", 0x029C35, 0x029C53, 0x029C62),
							new Tile("Frame 4", 0x029C36, 0x029C53, 0x029C62),
							new Tile("Frame 5", 0x029C37, 0x029C53, 0x029C62),
							new Tile("Frame 6", 0x029C38, 0x029C53, 0x029C62),
							new Tile("Frame 7", 0x029C39, 0x029C53, 0x029C62),
							new Tile("Frame 8", 0x029C3A, 0x029C53, 0x029C62),
							new Tile("Frame 9", 0x029C3B, 0x029C53, 0x029C62),
							new Tile("Frame 10", 0x029C3C, 0x029C53, 0x029C62),
							new Tile("Frame 11", 0x029C3D, 0x029C53, 0x029C62)});

			Tilemap Spr10 = new Tilemap("Spin jump star", "", new Tile[] {
							new Tile("Tile", 0x029C94, 0x029C8F, false)});

			Tilemap Spr11 = new Tilemap("Yoshi fireball", "", new Tile[] {
							new Tile("Frame 1", 0x029F7A, 0x029F8B, 0x029F94),
							new Tile("Frame 2", 0x029F7E, 0x029F8B, 0x029F94),});

			Tilemap Spr12 = new Tilemap("Water bubble", "", new Tile[] {
							new Tile("Tile", 0x029F5C, false, false)});

			o.Add(Spr01);
			o.Add(Spr02);
			o.Add(Spr03);
			o.Add(Spr04);
			o.Add(Spr05);
			o.Add(Spr06);
			o.Add(Spr07);
			o.Add(Spr08);
			o.Add(Spr09);
			o.Add(Spr10);
			o.Add(Spr11);
			o.Add(Spr12);
		}

		private void InitMinorExtendedSprites()
		{
			ComboBox.ObjectCollection o = minorExtendedSpriteTilemapSelector.Items;

			Tilemap Spr01 = new Tilemap("Broken brick piece", "", new Tile[] {
							new Tile("Frame 1", 0x028B84, 0x028B8C, 0x029028),
							new Tile("Frame 2", 0x028B85, 0x028B8D, 0x029028),
							new Tile("Frame 3", 0x028B86, 0x028B8E, 0x029028),
							new Tile("Frame 4", 0x028B87, 0x028B8F, 0x029028)});

			Tilemap Spr02 = new Tilemap("Tiny sparkle", "Note: The properties and sizes for this tilemap are shared with those of the invincibility sparkles.", new Tile[] {
							new Tile("Smallest", 0x028ECC, 0x028F1A, 0x028F26),
							new Tile("Small", 0x028ECD, 0x028F1A, 0x028F26),
							new Tile("Largest", 0x028ECE, 0x028F1A, 0x028F26)});

			Tilemap Spr03 = new Tilemap("Yoshi egg fragment", "", new Tile[] {
							new Tile("Tile", 0x028EB2, 0x028EBC, 0x028EC7)});

			Tilemap Spr04 = new Tilemap("Podoboo lava trail", "", new Tile[] {
							new Tile("Smallest", 0x028F2B, 0x028F76, 0x028F82),
							new Tile("Small", 0x028F2C, 0x028F76, 0x028F82),
							new Tile("Large", 0x028F2D, 0x028F76, 0x028F82),
							new Tile("Largest", 0x028F2E, 0x028F76, 0x028F82)});

			Tilemap Spr05 = new Tilemap("Invincibility sparkles", "Note: The properties and sizes for this tilemap are shared with those of the invincibility sparkles.", new Tile[] {
							new Tile("Smallest", 0x028ECF, 0x028F1A, 0x028F26),
							new Tile("Small", 0x028ED0, 0x028F1A, 0x028F26),
							new Tile("Largest", 0x028ED1, 0x028F1A, 0x028F26)});

			Tilemap Spr06 = new Tilemap("Rip van fish Z effect", "", new Tile[] {
							new Tile("z", 0x028DDA, 0x028E44, false),
							new Tile("Z", 0x028DD9, 0x028E44, false),
							new Tile("Z!!", 0x028DD8, 0x028E44, false),
							new Tile("*pop*", 0x028DD7, 0x028E44, false)});

			Tilemap Spr07 = new Tilemap("Water splash", "", new Tile[] {
							new Tile("Frame 1", 0x028D42, 0x028DC2, 0x028DCB),
							new Tile("Frame 2", 0x028D43, 0x028DC2, 0x028DCB),
							new Tile("Frame 3", 0x028D44, 0x028DC2, 0x028DCB),
							new Tile("Frame 4", 0x028D45, 0x028DC2, 0x028DCB),
							new Tile("Frame 5", 0x028D46, 0x028DC2, 0x028DCB),
							new Tile("Frame 6", 0x028D47, 0x028DC2, 0x028DCB),
							new Tile("Frame 7", 0x028D48, 0x028DC2, 0x028DCB),
							new Tile("Frame 8", 0x028D49, 0x028DC2, 0x028DCB),
							new Tile("Frame 9", 0x028D4A, 0x028DC2, 0x028DCB),
							new Tile("Frame 10", 0x028D4B, 0x028DC2, 0x028DCB),
							new Tile("Frame 11", 0x028D4C, 0x028DC2, 0x028DCB),
							new Tile("Frame 12", 0x028D4D, 0x028DC2, 0x028DCB),
							new Tile("Frame 13", 0x028D4E, 0x028DC2, 0x028DCB)});

			Tilemap Spr08 = new Tilemap("Rip van fish Z effect 2", "Seems to be just a duplicate?", new Tile[] {
							new Tile("z", 0x028DDA, 0x028E44, false),
							new Tile("Z", 0x028DD9, 0x028E44, false),
							new Tile("Z!!", 0x028DD8, 0x028E44, false),
							new Tile("*pop*", 0x028DD7, 0x028E44, false)});

			Tilemap Spr09 = new Tilemap("Rip van fish Z effect 3", "Seems to be just a duplicate?", new Tile[] {
							new Tile("z", 0x028DDA, 0x028E44, false),
							new Tile("Z", 0x028DD9, 0x028E44, false),
							new Tile("Z!!", 0x028DD8, 0x028E44, false),
							new Tile("*pop*", 0x028DD7, 0x028E44, false)});

			Tilemap Spr0A = new Tilemap("Boo stream follower", "", new Tile[] {
							new Tile("Tile 1", 0x028CB8, 0x028D34, 0x028D3D),
							new Tile("Tile 2", 0x028CB9, 0x028D34, 0x028D3D),
							new Tile("Tile 3", 0x028CBA, 0x028D34, 0x028D3D),
							new Tile("Tile 4", 0x028CBB, 0x028D34, 0x028D3D),
							new Tile("Tile 5", 0x028CBC, 0x028D34, 0x028D3D),
							new Tile("Tile 6", 0x028CBD, 0x028D34, 0x028D3D),
							new Tile("Tile 7", 0x028CBE, 0x028D34, 0x028D3D),
							new Tile("Tile 8", 0x028CBF, 0x028D34, 0x028D3D),
							new Tile("Tile 9", 0x028CC0, 0x028D34, 0x028D3D),
							new Tile("Tile 10", 0x028CC1, 0x028D34, 0x028D3D),
							new Tile("Tile 11", 0x028CC2, 0x028D34, 0x028D3D),
							new Tile("Tile 12", 0x028CC3, 0x028D34, 0x028D3D)});

			o.Add(Spr01);
			o.Add(Spr02);
			o.Add(Spr03);
			o.Add(Spr04);
			o.Add(Spr05);
			o.Add(Spr06);
			o.Add(Spr07);
			o.Add(Spr08);
			o.Add(Spr09);
			o.Add(Spr0A);
		}

		private void InitSmokeSprites()
		{
			ComboBox.ObjectCollection o = smokeSpriteTilemapSelector.Items;

			Tilemap Spr01 = new Tilemap("Puff of smoke", "", new Tile[] {
							new Tile("Frame 1", 0x0296D8, 0x029724, 0x029745),
							new Tile("Frame 2", 0x0296D9, 0x029724, 0x029745),
							new Tile("Frame 3", 0x0296DA, 0x029724, 0x029745),
							new Tile("Frame 4", 0x0296DB, 0x029724, 0x029745),
							new Tile("Frame 5", 0x0296DC, 0x029724, 0x029745),
							new Tile("Frame 6", 0x0296DD, 0x029724, 0x029745),
							new Tile("Frame 7", 0x0296DE, 0x029724, 0x029745)});

			Tilemap Spr02 = new Tilemap("Contact", "", new Tile[] {
							new Tile("Frame 1, tile 1+4", 0x029804, -1, 0x02982A),
							new Tile("Frame 1, tile 2+3", 0x02980C, -1, 0x02982A),
							new Tile("Frame 2, tile 1+4", 0x029816, -1, 0x02982A),
							new Tile("Frame 2, tile 2+3", 0x02981E, -1, 0x02982A)});

			Tilemap Spr03 = new Tilemap("Skid smoke", "", new Tile[] {
							new Tile("Frame 1", 0x029922, -1, 0x02999A),
							new Tile("Frame 2", 0x029923, -1, 0x02999A),
							new Tile("Frame 3", 0x029924, -1, 0x02999A),
							new Tile("Frame 4", 0x029925, -1, 0x02999A),
							new Tile("Frame 5", 0x029926, -1, 0x02999A)});

			Tilemap Spr04 = new Tilemap("Null", "No tilemap to edit!", new Tile[] { });

			Tilemap Spr05 = new Tilemap("Glitter", "No tilemap to edit?", new Tile[] { });

			o.Add(Spr01);
			o.Add(Spr02);
			o.Add(Spr03);
			o.Add(Spr04);
			o.Add(Spr05);
		}

		private void InitScoreSprites()
		{
			ComboBox.ObjectCollection o = scoreSpriteTilemapSelector.Items;

			Tilemap Spr01 = new Tilemap("10", "", new Tile[] {
							new Tile("Left", 0x02AD4D, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD63, 0x02AEE1, 0x02AEED)});

			Tilemap Spr02 = new Tilemap("20", "", new Tile[] {
							new Tile("Left", 0x02AD4E, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD64, 0x02AEE1, 0x02AEED)});

			Tilemap Spr03 = new Tilemap("40", "", new Tile[] {
							new Tile("Left", 0x02AD4F, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD65, 0x02AEE1, 0x02AEED)});

			Tilemap Spr04 = new Tilemap("80", "", new Tile[] {
							new Tile("Left", 0x02AD50, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD66, 0x02AEE1, 0x02AEED)});

			Tilemap Spr05 = new Tilemap("100", "", new Tile[] {
							new Tile("Left", 0x02AD51, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD67, 0x02AEE1, 0x02AEED)});

			Tilemap Spr06 = new Tilemap("200", "", new Tile[] {
							new Tile("Left", 0x02AD52, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD68, 0x02AEE1, 0x02AEED)});

			Tilemap Spr07 = new Tilemap("400", "", new Tile[] {
							new Tile("Left", 0x02AD53, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD69, 0x02AEE1, 0x02AEED)});

			Tilemap Spr08 = new Tilemap("800", "", new Tile[] {
							new Tile("Left", 0x02AD54, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD6A, 0x02AEE1, 0x02AEED)});

			Tilemap Spr09 = new Tilemap("1000", "", new Tile[] {
							new Tile("Left", 0x02AD55, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD6B, 0x02AEE1, 0x02AEED)});

			Tilemap Spr0A = new Tilemap("2000", "", new Tile[] {
							new Tile("Left", 0x02AD56, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD6C, 0x02AEE1, 0x02AEED)});

			Tilemap Spr0B = new Tilemap("4000", "", new Tile[] {
							new Tile("Left", 0x02AD57, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD6D, 0x02AEE1, 0x02AEED)});

			Tilemap Spr0C = new Tilemap("8000", "", new Tile[] {
							new Tile("Left", 0x02AD58, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD6E, 0x02AEE1, 0x02AEED)});

			Tilemap Spr0D = new Tilemap("1UP", "", new Tile[] {
							new Tile("Left", 0x02AD59, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD6F, 0x02AEE1, 0x02AEED)});

			Tilemap Spr0E = new Tilemap("2UP", "", new Tile[] {
							new Tile("Left", 0x02AD5A, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD70, 0x02AEE1, 0x02AEED)});

			Tilemap Spr0F = new Tilemap("3UP", "", new Tile[] {
							new Tile("Left", 0x02AD5B, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD71, 0x02AEE1, 0x02AEED)});

			Tilemap Spr10 = new Tilemap("5UP", "", new Tile[] {
							new Tile("Left", 0x02AD5C, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD72, 0x02AEE1, 0x02AEED)});

			Tilemap Spr11 = new Tilemap("Coin x 5", "", new Tile[] {
							new Tile("Left", 0x02AD5D, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD73, 0x02AEE1, 0x02AEED)});

			Tilemap Spr12 = new Tilemap("Coin x 10", "", new Tile[] {
							new Tile("Left", 0x02AD5E, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD74, 0x02AEE1, 0x02AEED)});

			Tilemap Spr13 = new Tilemap("Coin x 15", "", new Tile[] {
							new Tile("Left", 0x02AD5F, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD75, 0x02AEE1, 0x02AEED)});

			Tilemap Spr14 = new Tilemap("Coin x 20", "", new Tile[] {
							new Tile("Left", 0x02AD60, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD76, 0x02AEE1, 0x02AEED)});

			Tilemap Spr15 = new Tilemap("Coin x 25", "", new Tile[] {
							new Tile("Left", 0x02AD61, 0x02AEE1, 0x02AEED),
							new Tile("Right", 0x02AD77, 0x02AEE1, 0x02AEED)});

			o.Add(Spr01);
			o.Add(Spr02);
			o.Add(Spr03);
			o.Add(Spr04);
			o.Add(Spr05);
			o.Add(Spr06);
			o.Add(Spr07);
			o.Add(Spr08);
			o.Add(Spr09);
			o.Add(Spr0A);
			o.Add(Spr0B);
			o.Add(Spr0C);
			o.Add(Spr0D);
			o.Add(Spr0E);
			o.Add(Spr0F);
			o.Add(Spr10);
			o.Add(Spr11);
			o.Add(Spr12);
			o.Add(Spr13);
			o.Add(Spr14);
			o.Add(Spr15);
		}

		private void InitSpinningCoinSprites()
		{

		}

		private void InitTilemaps()
		{
			InitStandardSprites();
			InitClusterSprites();
			InitBounceSprites();
			InitExtendedSprites();
			InitMinorExtendedSprites();
			InitSmokeSprites();
			InitScoreSprites();
			InitSpinningCoinSprites();
		}

		private void tileSelector_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		private void ClearFormTileProperties()
		{
			tileTextBox.Text = "";
			xOffsetBox.Value = 0;
			yOffsetBox.Value = 0;

			sizeBox.Enabled = false;
			numericUpDown2.Enabled = false;
			xOffsetBox.Enabled = false;
			yOffsetBox.Enabled = false;


			tileAddressLabel.Text = "";

			propAddressLabel.Text = "";
			yxppccctLabel.Text = "";



			sizeAddressLabel.Text = "";

			currentTile = null;

			//setCurrentTilePos(-1, -1);

			//gfxBox.Refresh();

			//tileBox.Refresh();
			tileBox.Image = null;
			refreshGraphics = true;

			infoLabel.Text = "";
		}

		private void UpdateFormTileProperties()
		{
			tileTextBox.Text = currentTile.TileIndex.ToString("X3");
			sizeBox.SelectedIndex = Convert.ToInt32(currentTile.Size);
			xOffsetBox.Value = currentTile.XOffset;
			yOffsetBox.Value = currentTile.YOffset;
			numericUpDown2.Value = currentTile.Palette + 8;

			sizeBox.Enabled = currentTile.SizeEditable;
			checkBox3.Enabled = checkBox4.Enabled = numericUpDown2.Enabled = currentTile.PropertyEditable;
			xOffsetBox.Enabled = currentTile.XOffsetEditable;
			yOffsetBox.Enabled = currentTile.YOffsetEditable;

			if (currentTile.TileEditable)
				tileAddressLabel.Text = "Tile address: $" + (currentTile.TileAddress >> 16).ToString("X2") + ":" + (currentTile.TileAddress & 0xFFFF).ToString("X4");
			else
				tileAddressLabel.Text = "Tile address: Unknown";

			if (currentTile.PropertyEditable)
			{
				propAddressLabel.Text = "Property address: $" + (currentTile.PropertyAddress >> 16).ToString("X2") + ":" + (currentTile.PropertyAddress & 0xFFFF).ToString("X4");
				string s = "", s2 = "";
				byte b = currentTile.Property.ToByte();
				for (int i = 0; i < 8; i++, b >>= 1)
					s += (b & 1).ToString();

				for (int i = 7; i >= 0 ; i--)
					s2 += s[i];

				yxppccctLabel.Text = "YXPPCCCT: %" + s2;

				checkBox3.Checked = currentTile.Property.x;
				checkBox4.Checked = currentTile.Property.y;
			}
			else
			{
				propAddressLabel.Text = "Property address: Unknown";
				yxppccctLabel.Text = "YXPPCCCT: Unknown";
				checkBox3.Checked = false;
				checkBox4.Checked = false;
			}

			if (currentTile.SizeEditable)
				sizeAddressLabel.Text = "Size address: $" + (currentTile.SizeAddress >> 16).ToString("X2") + ":" + (currentTile.SizeAddress & 0xFFFF).ToString("X4");
			else
				sizeAddressLabel.Text = "Size address: Unknown/too generic";

			setCurrentTilePos(currentTile.TileIndex & 0xF, currentTile.TileIndex >> 4);

			if (checkBox1.Checked)
				numericUpDown1.Value = currentTile.Palette + 8;
			//else
				//gfxBox.Refresh();
			//tileBox.Refresh();
			refreshGraphics = true;
			infoLabel.Text = currentTilemap.information;
		}

		private void tileSelector_SelectedIndexChanged_1(object sender, EventArgs e)
		{
			currentTile = (Tile)tileSelector.SelectedItem;
			UpdateFormTileProperties();
		}

		private void openToolStripMenuItem_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < spriteGFXMap.GetLength(0); i++)
				for (int j = 0; j < spriteGFXMap.GetLength(1); j++)
					for (int k = 0; k < spriteGFXMap.GetLength(2); k++)
						spriteGFXMap[i, j, k] = -1;

			OpenFileDialog d = new OpenFileDialog();
			d.Filter = "SNES ROM files|*.smc;*.sfc";

			if (d.ShowDialog() != System.Windows.Forms.DialogResult.OK)
			{
				return;
			}
			path = d.FileName;

			basePath = d.FileName.Substring(0, d.FileName.LastIndexOf("\\")) + "\\Graphics\\";


			if (System.IO.Directory.Exists(basePath) == false)
			{
				MessageBox.Show("Error: You must extract the graphics from your ROM first.");
				return;
			}

			// Yes this only checks for one file.  I'm lazy, and for 99% of all cases it's good enough.
			if (System.IO.File.Exists(basePath + "GFX00.bin") == false)
			{
				MessageBox.Show("Error: The graphics extracted from your ROM must be in separated files (GFX00, GFX01, etc.)");
				return;
			}

			ignoreSelectorClicks = true;
			clickDisableTimer.Start();

			foreach (Control c in Controls)
				c.Enabled = true;

			tileTextBox.Enabled = false;

			System.IO.FileInfo f = new System.IO.FileInfo(d.FileName);
			long ROMLength = f.Length;
			if (ROMLength % 0x8000 != 0)
			{
				ROM = new byte[ROMLength - 0x200];
				Header = new byte[0x200];
				byte[] temp = System.IO.File.ReadAllBytes(d.FileName);
				for (int i = 0x200; i < ROMLength; i++)
				{
					ROM[i - 0x200] = temp[i];
				}

				for (int i = 0; i < 0x200; i++)
				{
					Header[i] = temp[i];
				}
			}
			else
				ROM = System.IO.File.ReadAllBytes(d.FileName);

			spriteTilemapSelector.Items.Clear();
			tileSelector.Items.Clear();


			Init();
			formReady = true;
			Refresh();


			readGFXMap();
			refreshGraphics = true;


		}

		private void viewEveryTile()
		{
			ComboBox[] boxes = { spriteTilemapSelector, clusterSpriteTilemapSelector, bounceSpriteTilemapSelector, extendedSpriteTilemapSelector, minorExtendedSpriteTilemapSelector, smokeSpriteTilemapSelector, scoreSpriteTilemapSelector };

			string s = "";
			int index = 0;
			bool[] used = { false, false, false, false };

			foreach (ComboBox b in boxes)
			{
				for (int i = 0; i < b.Items.Count; i++)
				{
					used[0] = used[1] = used[2] = used[3] = false;

					b.SelectedIndex = i;
					for (int j = 0; j < tileSelector.Items.Count; j++)
					{
						tileSelector.SelectedIndex = j;
						shouldRefreshTileBox = true;
						Refresh();
						System.Threading.Thread.Sleep(50);
						if (currentTile.TileIndex < 0x80)
							used[0] = true;
						else if (currentTile.TileIndex < 0x100)
							used[1] = true;
						else if (currentTile.TileIndex < 0x180)
							used[2] = true;
						else if (currentTile.TileIndex < 0x200)
							used[3] = true;
					}

					switch (index)
					{
						case 0: s += "standard" + i.ToString("X2") + ":	"; break;
						case 1: s += "cluster" + i.ToString("X2") + ":	"; break;
						case 2: s += "bounce" + i.ToString("X2") + ":	"; break;
						case 3: s += "extended" + i.ToString("X2") + ":	"; break;
						case 4: s += "minorext" + i.ToString("X2") + ":	"; break;
						case 5: s += "smoke" + i.ToString("X2") + ":	"; break;
						case 6: s += "score" + i.ToString("X2") + ":	"; break;
					}

					s += used[0] ? "00 " : "__ ";
					s += used[1] ? "00 " : "__ ";
					s += used[2] ? "00 " : "__ ";
					s += used[3] ? "00\n" : "__\n";
				}

				index++;
			}
		}


		private void generateASM()
		{
			ComboBox[] boxes = { spriteTilemapSelector, clusterSpriteTilemapSelector, bounceSpriteTilemapSelector, extendedSpriteTilemapSelector, minorExtendedSpriteTilemapSelector, smokeSpriteTilemapSelector, scoreSpriteTilemapSelector };

			string s = "";
			int index = 0;

			foreach (ComboBox b in boxes)
			{
				s += ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n;;; " + (string)b.Tag + "\n;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n\n";
				for (int i = 0; i < b.Items.Count; i++)
				{
					Tilemap tm = (Tilemap)b.Items[i];
					s += ";;; " + tm.name + "\n";
					for (int j = 0; j < tm.tiles.Count; j++)
					{
						Tile t = tm.tiles[j];
						string temp = "";
						if (t.TileEditable) temp += "org $" + t.TileAddress.ToString("X6") + " : " + "db $" + (t.TileIndex & 0xFF).ToString("X2"); else temp += "                       ";
						if (t.PropertyEditable) temp += " : org $" + t.PropertyAddress.ToString("X6") + " : " + "db $" + t.Property.ToByte().ToString("X2"); else temp += "                       ";
						if (t.SizeEditable) temp += " : org $" + t.SizeAddress.ToString("X6") + " : " + "db $" + (t.Size ? 2 : 0).ToString("X2"); else temp += "                       ";
						if (temp.StartsWith(" :")) temp = temp.Substring(2);
						s += temp;
						s += "                ; " + tm.tiles[j].Name + "\n";
					}
					s += "\n\n";
				}

				index++;
			}

			if (path.Contains("\\") == false)
				System.IO.File.WriteAllText("spriteremap.asm", s);
			else
				System.IO.File.WriteAllText(path.Substring(0, path.LastIndexOf("\\")) + "\\spriteremap.asm", s);
		}

		private void SetROMToTiles()
		{
			ComboBox[] boxes = { spriteTilemapSelector, clusterSpriteTilemapSelector, bounceSpriteTilemapSelector, extendedSpriteTilemapSelector, minorExtendedSpriteTilemapSelector, smokeSpriteTilemapSelector, scoreSpriteTilemapSelector };

			int index = 0;

			foreach (ComboBox b in boxes)
			{
				for (int i = 0; i < b.Items.Count; i++)
				{
					Tilemap tm = (Tilemap)b.Items[i];
					//tm.GetData(ROM);
					//b.SelectedIndex = i;
					for (int j = 0; j < tm.tiles.Count; j++)
					{
						Tile t = tm.tiles[j];
						t.ROM = ROM;
					}
					
				}

				index++;
			}
		}

		private void sizeBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (!formReady) return;
			currentTile.Size = sizeBox.SelectedIndex == 1;
			//gfxBox.Refresh();
			refreshGraphics = true;
		}

		private void numericUpDown2_ValueChanged(object sender, EventArgs e)
		{
			if (!formReady) return;
			currentTile.Palette = (byte)(numericUpDown2.Value - 8);

			if (checkBox1.Checked)
				numericUpDown1.Value = currentTile.Palette + 8;
			//else
				//gfxBox.Refresh();
			//tileBox.Refresh();
			refreshGraphics = true;
		}

		bool generateEvent = true;
		private void spriteTilemapSelector_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (generateEvent == false) return;

			ComboBox c = (ComboBox)sender;

			string s = c.SelectedIndex.ToString("X2") + ":";

			int selectorIndex = 0;

			generateEvent = false;
			if (spriteTilemapSelector != sender) { spriteTilemapSelector.SelectedItem = null; standardSpriteNumberLabel.Text = ""; } else { standardSpriteNumberLabel.Text = s; selectorIndex = 0; }
			if (clusterSpriteTilemapSelector != sender) { clusterSpriteTilemapSelector.SelectedItem = null; clusterSpriteNumberLabel.Text = ""; } else { clusterSpriteNumberLabel.Text = s; selectorIndex = 1; }
			if (bounceSpriteTilemapSelector != sender) { bounceSpriteTilemapSelector.SelectedItem = null; bounceSpriteNumberLabel.Text = ""; } else { bounceSpriteNumberLabel.Text = s; selectorIndex = 2; }
			if (extendedSpriteTilemapSelector != sender) { extendedSpriteTilemapSelector.SelectedItem = null; extendedSpriteNumberLabel.Text = ""; } else { extendedSpriteNumberLabel.Text = s; selectorIndex = 3; }
			if (minorExtendedSpriteTilemapSelector != sender) { minorExtendedSpriteTilemapSelector.SelectedItem = null; minorExtendedSpriteNumberLabel.Text = ""; } else { minorExtendedSpriteNumberLabel.Text = s; selectorIndex = 4; }
			if (smokeSpriteTilemapSelector != sender) { smokeSpriteTilemapSelector.SelectedItem = null; smokeSpriteNumberLabel.Text = ""; } else { smokeSpriteNumberLabel.Text = s; selectorIndex = 5; }
			if (scoreSpriteTilemapSelector != sender) { scoreSpriteTilemapSelector.SelectedItem = null; scoreSpriteNumberLabel.Text = ""; } else { scoreSpriteNumberLabel.Text = s; selectorIndex = 6; }

			generateEvent = true;

			if (checkBox2.Checked)
			{
				for (int i = 0; i < 4; i++)
				{
					if (spriteGFXMap[selectorIndex, c.SelectedIndex, i] != -1)
					{
						switch (i)
						{
							case 0: gfxSelector1.Value = spriteGFXMap[selectorIndex, c.SelectedIndex, 0]; break;
							case 1: gfxSelector2.Value = spriteGFXMap[selectorIndex, c.SelectedIndex, 1]; break;
							case 2: gfxSelector3.Value = spriteGFXMap[selectorIndex, c.SelectedIndex, 2]; break;
							case 3: gfxSelector4.Value = spriteGFXMap[selectorIndex, c.SelectedIndex, 3]; break;
						}
					}
				}
			}

			currentTilemap = (Tilemap)c.SelectedItem;
			tileSelector.Items.Clear();
			for (int i = 0; i < currentTilemap.tiles.Count; i++)
				tileSelector.Items.Add(currentTilemap.tiles[i]);
			//currentTilemap.GetData(ROM);
			if (tileSelector.Items.Count > 0)
				tileSelector.SelectedIndex = 0;
			else
				ClearFormTileProperties();

		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			generateASM();
			//generateSpriteList();

			ignoreSelectorClicks = true;
			clickDisableTimer.Start();



			System.Diagnostics.Process p = new System.Diagnostics.Process();
			try
			{

				p.StartInfo.FileName = "asar.exe";

				if (path.Contains("\\") == false)
					p.StartInfo.Arguments = "\"spriteremap.asm\" \"" + path + "\"";
				else
					p.StartInfo.Arguments = "\"" + path.Substring(0, path.LastIndexOf("\\")) + "\\spriteremap.asm\" \"" + path + "\"";

				p.Start();
				while (!p.HasExited) ;
			}
			catch
			{
				MessageBox.Show("Could not execute asar.exe.  Make sure that that program is in the same directory as this program.");
				Close();
			}

			/*byte[] write;
			if (Header.Length > 0)
			{
				write = new byte[Header.Length + ROM.Length];
				for (int i = 0; i < Header.Length; i++)
					write[i] = Header[i];

				for (int i = 0; i < ROM.Length; i++)
					write[i + Header.Length] = ROM[i];
			}
			else
			{
				write = new byte[ROM.Length];
				for (int i = 0; i < ROM.Length; i++)
					write[i] = ROM[i];
			}
			System.IO.File.WriteAllBytes(path, write);*/
		}

		private void readGFXMap()
		{
			string s;

			try
			{
				s = System.IO.File.ReadAllText("gfxmap.dat");
			}
			catch (Exception ex)
			{
				MessageBox.Show("gfxmap.dat could not be read.");
				return;
			}

			s = s.Replace("\r", "");
			if (s.EndsWith("\n") == false)
				s += "\n";


			int i = 0;

			try
			{



				while (i < s.Length)
				{
					if (s.IndexOf('\n', i) == i)
					{
						i++;
						continue;
					}

					string b = s.Substring(i, s.IndexOf('\n', i) - i);
					b = b.Substring(0, b.IndexOf('\t'));
					string type = b.Substring(0, b.Length - 3);
					int number = Convert.ToInt32(b.Substring(b.Length - 3, 2), 16);

					int[] gfx = new int[4];

					i = s.IndexOf('\t', i) + 1;

					for (int j = 0; j < 4; j++)
					{
						if (s.Substring(i, 3) == "___")
						{
							i += 3;
							gfx[j] = -1;
						}
						else
						{
							gfx[j] = Convert.ToInt32(s.Substring(i, 3), 16);
							i += 3;
						}
						if (j < 3)
						{
							if (s[i] != ' ')
								throw new Exception("");
						}

						i++;
					}

					int k;

					switch (type)
					{
						case "standard": k = 0; break;
						case "cluster": k = 1; break;
						case "bounce": k = 2; break;
						case "extended": k = 3; break;
						case "minorext": k = 4; break;
						case "score": k = 5; break;
						case "smoke": k = 6; break;
						default: throw new Exception("");
					}

					for (int j = 0; j < 4; j++)
					{
						spriteGFXMap[k,number,j] = gfx[j];
					}

				}



			}
			catch (Exception ex)
			{
				MessageBox.Show("There was an error reading gfxmap.dat.");
				return;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			viewEveryTile();
		}

		private void clickDisableTimer_Tick(object sender, EventArgs e)
		{
			clickDisableTimer.Enabled = false;
			ignoreSelectorClicks = false;
		}

		private void refreshTimer_Tick(object sender, EventArgs e)
		{
			if (refreshGraphics)
			{
				gfxBox.Refresh();
				RefreshTileBoxes();
				pictureBox2.Refresh();
				refreshGraphics = false;
			}
		}

		private void checkBox3_CheckedChanged(object sender, EventArgs e)
		{
			if (!formReady) return;
			currentTile.Property.x = checkBox3.Checked;
			refreshGraphics = true;
		}

		private void checkBox4_CheckedChanged(object sender, EventArgs e)
		{
			if (!formReady) return;
			currentTile.Property.y = checkBox4.Checked;
			refreshGraphics = true;
		}

		private void checkBox5_CheckedChanged(object sender, EventArgs e)
		{
			refreshGraphics = true;
		}

		private void toolStripMenuItem1_Click(object sender, EventArgs e)
		{
			OpenFileDialog d = new OpenFileDialog();
			d.Filter = "Palette files|*.pal;*.zs*|All files|*.*";
			if (d.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

			try
			{
				if (d.FileName.EndsWith(".pal"))
					Palette.OpenFromYYCHRPal(d.FileName, palettes);
				else
					Palette.OpenFromZSNESSaveState(d.FileName, palettes);
			}
			catch (Exception ex)
			{
				MessageBox.Show("This file could not be opened properly.");
			}
			ignoreSelectorClicks = true;
			clickDisableTimer.Start();

		}

		private void generateSpriteList()
		{

/*			string path2;
			if (path.Contains('.'))
				path2 = path.Substring(0, path.LastIndexOf('.')) + "ssc";
			else
				path2 = path + ".ssc";


			ComboBox[] boxes = { spriteTilemapSelector, clusterSpriteTilemapSelector, bounceSpriteTilemapSelector, extendedSpriteTilemapSelector, minorExtendedSpriteTilemapSelector, smokeSpriteTilemapSelector, scoreSpriteTilemapSelector };
			int[] baseNumbers = { 0, 0xE0, -1, -1, -1, -1, -1, -1 };

			string s = "";


			int index = 0;

			for (int i = 0; i < spriteTilemapSelector.Items.Count; i++)
			{
				Tilemap tm = (Tilemap)spriteTilemapSelector.Items[i];
				s += i.ToString("X2") + "\t";
				

			}

			foreach (ComboBox b in boxes)
			{
				if (baseNumbers[index] == -1) continue;
				//s += ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n;;; " + (string)b.Tag + "\n;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n\n";
				for (int i = 0; i < b.Items.Count; i++)
				{
					Tilemap tm = (Tilemap)b.Items[i];
					
					//s += ";;; " + tm.name + "\n";
					for (int j = 0; j < tm.tiles.Count; j++)
					{
						Tile t = tm.tiles[j];
						string temp = "";
						if (t.TileEditable) temp += "org $" + t.TileAddress.ToString("X6") + " : " + "db $" + (t.TileIndex & 0xFF).ToString("X2"); else temp += "                       ";
						if (t.PropertyEditable) temp += " : org $" + t.PropertyAddress.ToString("X6") + " : " + "db $" + t.Property.ToByte().ToString("X2"); else temp += "                       ";
						if (t.SizeEditable) temp += " : org $" + t.SizeAddress.ToString("X6") + " : " + "db $" + (t.Size ? 2 : 0).ToString("X2"); else temp += "                       ";
						if (temp.StartsWith(" :")) temp = temp.Substring(2);
						s += temp;
						s += "                ; " + tm.tiles[j].Name + "\n";
					}
					s += "\n\n";
				}

				index++;
			}
			System.IO.File.WriteAllText("temp.asm", s);
*/
		}
	}
}

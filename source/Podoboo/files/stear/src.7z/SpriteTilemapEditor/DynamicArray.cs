﻿using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

namespace SpriteTilemapEditor
{
	public class DynamicArray<T>: List<T>
	{
		public static implicit operator DynamicArray<T>(T[] b)
		{
			DynamicArray<T> n = new DynamicArray<T>();
			n.Capacity = b.Length;
			for (int i = 0; i < b.Length; i++)
				n.Add(b[i]);
			return n;
		}



	}

}

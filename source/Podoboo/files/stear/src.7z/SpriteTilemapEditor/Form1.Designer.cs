﻿namespace SpriteTilemapEditor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.gfxSelector1 = new System.Windows.Forms.NumericUpDown();
			this.gfxSelector2 = new System.Windows.Forms.NumericUpDown();
			this.gfxSelector3 = new System.Windows.Forms.NumericUpDown();
			this.gfxSelector4 = new System.Windows.Forms.NumericUpDown();
			this.tileBox = new System.Windows.Forms.PictureBox();
			this.gfxBox = new System.Windows.Forms.PictureBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.checkBox4 = new System.Windows.Forms.CheckBox();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.yxppccctLabel = new System.Windows.Forms.Label();
			this.sizeAddressLabel = new System.Windows.Forms.Label();
			this.propAddressLabel = new System.Windows.Forms.Label();
			this.tileAddressLabel = new System.Windows.Forms.Label();
			this.infoLabel = new System.Windows.Forms.Label();
			this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.sizeBox = new System.Windows.Forms.ComboBox();
			this.tileSelector = new System.Windows.Forms.ComboBox();
			this.tileTextBox = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.yOffsetBox = new System.Windows.Forms.NumericUpDown();
			this.xOffsetBox = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.spriteTilemapSelector = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.clusterSpriteTilemapSelector = new System.Windows.Forms.ComboBox();
			this.label8 = new System.Windows.Forms.Label();
			this.bounceSpriteTilemapSelector = new System.Windows.Forms.ComboBox();
			this.label9 = new System.Windows.Forms.Label();
			this.extendedSpriteTilemapSelector = new System.Windows.Forms.ComboBox();
			this.label10 = new System.Windows.Forms.Label();
			this.minorExtendedSpriteTilemapSelector = new System.Windows.Forms.ComboBox();
			this.label11 = new System.Windows.Forms.Label();
			this.smokeSpriteTilemapSelector = new System.Windows.Forms.ComboBox();
			this.label12 = new System.Windows.Forms.Label();
			this.scoreSpriteTilemapSelector = new System.Windows.Forms.ComboBox();
			this.standardSpriteNumberLabel = new System.Windows.Forms.Label();
			this.clusterSpriteNumberLabel = new System.Windows.Forms.Label();
			this.bounceSpriteNumberLabel = new System.Windows.Forms.Label();
			this.extendedSpriteNumberLabel = new System.Windows.Forms.Label();
			this.minorExtendedSpriteNumberLabel = new System.Windows.Forms.Label();
			this.smokeSpriteNumberLabel = new System.Windows.Forms.Label();
			this.scoreSpriteNumberLabel = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.clickDisableTimer = new System.Windows.Forms.Timer(this.components);
			this.refreshTimer = new System.Windows.Forms.Timer(this.components);
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.checkBox5 = new System.Windows.Forms.CheckBox();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxSelector1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxSelector2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxSelector3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxSelector4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.tileBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxBox)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.yOffsetBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.xOffsetBox)).BeginInit();
			this.menuStrip1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Location = new System.Drawing.Point(6, 555);
			this.numericUpDown1.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
			this.numericUpDown1.TabIndex = 2;
			this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
			// 
			// pictureBox2
			// 
			this.pictureBox2.Location = new System.Drawing.Point(6, 533);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(256, 16);
			this.pictureBox2.TabIndex = 3;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox2_Paint);
			// 
			// gfxSelector1
			// 
			this.gfxSelector1.Hexadecimal = true;
			this.gfxSelector1.Location = new System.Drawing.Point(269, 20);
			this.gfxSelector1.Maximum = new decimal(new int[] {
            38,
            0,
            0,
            0});
			this.gfxSelector1.Name = "gfxSelector1";
			this.gfxSelector1.Size = new System.Drawing.Size(54, 20);
			this.gfxSelector1.TabIndex = 7;
			this.gfxSelector1.Tag = "0";
			this.gfxSelector1.ValueChanged += new System.EventHandler(this.SwapGraphics);
			// 
			// gfxSelector2
			// 
			this.gfxSelector2.Hexadecimal = true;
			this.gfxSelector2.Location = new System.Drawing.Point(269, 147);
			this.gfxSelector2.Maximum = new decimal(new int[] {
            38,
            0,
            0,
            0});
			this.gfxSelector2.Name = "gfxSelector2";
			this.gfxSelector2.Size = new System.Drawing.Size(54, 20);
			this.gfxSelector2.TabIndex = 8;
			this.gfxSelector2.Tag = "1";
			this.gfxSelector2.ValueChanged += new System.EventHandler(this.SwapGraphics);
			// 
			// gfxSelector3
			// 
			this.gfxSelector3.Hexadecimal = true;
			this.gfxSelector3.Location = new System.Drawing.Point(269, 274);
			this.gfxSelector3.Maximum = new decimal(new int[] {
            38,
            0,
            0,
            0});
			this.gfxSelector3.Name = "gfxSelector3";
			this.gfxSelector3.Size = new System.Drawing.Size(54, 20);
			this.gfxSelector3.TabIndex = 9;
			this.gfxSelector3.Tag = "2";
			this.gfxSelector3.ValueChanged += new System.EventHandler(this.SwapGraphics);
			// 
			// gfxSelector4
			// 
			this.gfxSelector4.Hexadecimal = true;
			this.gfxSelector4.Location = new System.Drawing.Point(269, 386);
			this.gfxSelector4.Maximum = new decimal(new int[] {
            38,
            0,
            0,
            0});
			this.gfxSelector4.Name = "gfxSelector4";
			this.gfxSelector4.Size = new System.Drawing.Size(54, 20);
			this.gfxSelector4.TabIndex = 10;
			this.gfxSelector4.Tag = "3";
			this.gfxSelector4.ValueChanged += new System.EventHandler(this.SwapGraphics);
			// 
			// tileBox
			// 
			this.tileBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tileBox.Location = new System.Drawing.Point(424, 402);
			this.tileBox.Name = "tileBox";
			this.tileBox.Size = new System.Drawing.Size(256, 256);
			this.tileBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.tileBox.TabIndex = 11;
			this.tileBox.TabStop = false;
			this.tileBox.Tag = "0";
			this.tileBox.Paint += new System.Windows.Forms.PaintEventHandler(this.RefreshTileBox);
			// 
			// gfxBox
			// 
			this.gfxBox.Location = new System.Drawing.Point(6, 19);
			this.gfxBox.Name = "gfxBox";
			this.gfxBox.Size = new System.Drawing.Size(256, 508);
			this.gfxBox.TabIndex = 12;
			this.gfxBox.TabStop = false;
			this.gfxBox.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
			this.gfxBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.gfxBox1_MouseMove);
			this.gfxBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gfxBox1_MouseMove);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.checkBox4);
			this.groupBox1.Controls.Add(this.checkBox3);
			this.groupBox1.Controls.Add(this.yxppccctLabel);
			this.groupBox1.Controls.Add(this.sizeAddressLabel);
			this.groupBox1.Controls.Add(this.propAddressLabel);
			this.groupBox1.Controls.Add(this.tileAddressLabel);
			this.groupBox1.Controls.Add(this.infoLabel);
			this.groupBox1.Controls.Add(this.numericUpDown2);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.sizeBox);
			this.groupBox1.Controls.Add(this.tileSelector);
			this.groupBox1.Controls.Add(this.tileTextBox);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(555, 30);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(200, 362);
			this.groupBox1.TabIndex = 14;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Properties";
			// 
			// checkBox4
			// 
			this.checkBox4.AutoSize = true;
			this.checkBox4.Location = new System.Drawing.Point(7, 160);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new System.Drawing.Size(52, 17);
			this.checkBox4.TabIndex = 27;
			this.checkBox4.Text = "Flip Y";
			this.checkBox4.UseVisualStyleBackColor = true;
			this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
			// 
			// checkBox3
			// 
			this.checkBox3.AutoSize = true;
			this.checkBox3.Location = new System.Drawing.Point(7, 145);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new System.Drawing.Size(52, 17);
			this.checkBox3.TabIndex = 26;
			this.checkBox3.Text = "Flip X";
			this.checkBox3.UseVisualStyleBackColor = true;
			this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
			// 
			// yxppccctLabel
			// 
			this.yxppccctLabel.AutoSize = true;
			this.yxppccctLabel.Location = new System.Drawing.Point(6, 233);
			this.yxppccctLabel.Name = "yxppccctLabel";
			this.yxppccctLabel.Size = new System.Drawing.Size(66, 13);
			this.yxppccctLabel.TabIndex = 22;
			this.yxppccctLabel.Text = "YXPPCCCT:";
			// 
			// sizeAddressLabel
			// 
			this.sizeAddressLabel.AutoSize = true;
			this.sizeAddressLabel.Location = new System.Drawing.Point(5, 214);
			this.sizeAddressLabel.Name = "sizeAddressLabel";
			this.sizeAddressLabel.Size = new System.Drawing.Size(70, 13);
			this.sizeAddressLabel.TabIndex = 25;
			this.sizeAddressLabel.Text = "Size address:";
			// 
			// propAddressLabel
			// 
			this.propAddressLabel.AutoSize = true;
			this.propAddressLabel.Location = new System.Drawing.Point(5, 197);
			this.propAddressLabel.Name = "propAddressLabel";
			this.propAddressLabel.Size = new System.Drawing.Size(89, 13);
			this.propAddressLabel.TabIndex = 25;
			this.propAddressLabel.Text = "Property address:";
			// 
			// tileAddressLabel
			// 
			this.tileAddressLabel.AutoSize = true;
			this.tileAddressLabel.Location = new System.Drawing.Point(5, 180);
			this.tileAddressLabel.Name = "tileAddressLabel";
			this.tileAddressLabel.Size = new System.Drawing.Size(67, 13);
			this.tileAddressLabel.TabIndex = 25;
			this.tileAddressLabel.Text = "Tile address:";
			// 
			// infoLabel
			// 
			this.infoLabel.Location = new System.Drawing.Point(6, 253);
			this.infoLabel.Name = "infoLabel";
			this.infoLabel.Size = new System.Drawing.Size(187, 106);
			this.infoLabel.TabIndex = 24;
			// 
			// numericUpDown2
			// 
			this.numericUpDown2.Location = new System.Drawing.Point(62, 119);
			this.numericUpDown2.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
			this.numericUpDown2.Minimum = new decimal(new int[] {
            8,
            0,
            0,
            0});
			this.numericUpDown2.Name = "numericUpDown2";
			this.numericUpDown2.Size = new System.Drawing.Size(64, 20);
			this.numericUpDown2.TabIndex = 23;
			this.numericUpDown2.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
			this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(7, 121);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(43, 13);
			this.label5.TabIndex = 22;
			this.label5.Text = "Palette:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(7, 94);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(30, 13);
			this.label2.TabIndex = 17;
			this.label2.Text = "Size:";
			// 
			// sizeBox
			// 
			this.sizeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.sizeBox.FormattingEnabled = true;
			this.sizeBox.Items.AddRange(new object[] {
            "8x8",
            "16x16"});
			this.sizeBox.Location = new System.Drawing.Point(62, 91);
			this.sizeBox.Name = "sizeBox";
			this.sizeBox.Size = new System.Drawing.Size(96, 21);
			this.sizeBox.TabIndex = 16;
			this.sizeBox.SelectedIndexChanged += new System.EventHandler(this.sizeBox_SelectedIndexChanged);
			// 
			// tileSelector
			// 
			this.tileSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.tileSelector.FormattingEnabled = true;
			this.tileSelector.Location = new System.Drawing.Point(18, 19);
			this.tileSelector.Name = "tileSelector";
			this.tileSelector.Size = new System.Drawing.Size(176, 21);
			this.tileSelector.TabIndex = 15;
			this.tileSelector.SelectedIndexChanged += new System.EventHandler(this.tileSelector_SelectedIndexChanged_1);
			// 
			// tileTextBox
			// 
			this.tileTextBox.Location = new System.Drawing.Point(62, 64);
			this.tileTextBox.MaxLength = 2;
			this.tileTextBox.Name = "tileTextBox";
			this.tileTextBox.ReadOnly = true;
			this.tileTextBox.Size = new System.Drawing.Size(64, 20);
			this.tileTextBox.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 67);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(30, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Tile: ";
			// 
			// yOffsetBox
			// 
			this.yOffsetBox.Hexadecimal = true;
			this.yOffsetBox.Location = new System.Drawing.Point(365, 546);
			this.yOffsetBox.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
			this.yOffsetBox.Name = "yOffsetBox";
			this.yOffsetBox.Size = new System.Drawing.Size(64, 20);
			this.yOffsetBox.TabIndex = 21;
			this.yOffsetBox.Visible = false;
			// 
			// xOffsetBox
			// 
			this.xOffsetBox.Hexadecimal = true;
			this.xOffsetBox.Location = new System.Drawing.Point(365, 520);
			this.xOffsetBox.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
			this.xOffsetBox.Name = "xOffsetBox";
			this.xOffsetBox.Size = new System.Drawing.Size(64, 20);
			this.xOffsetBox.TabIndex = 20;
			this.xOffsetBox.Visible = false;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(304, 540);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(48, 13);
			this.label4.TabIndex = 19;
			this.label4.Text = "Y Offset:";
			this.label4.Visible = false;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(304, 514);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 13);
			this.label3.TabIndex = 18;
			this.label3.Text = "X Offset:";
			this.label3.Visible = false;
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(765, 24);
			this.menuStrip1.TabIndex = 15;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripMenuItem1,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
			this.fileToolStripMenuItem.Text = "&File";
			// 
			// openToolStripMenuItem
			// 
			this.openToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem.Image")));
			this.openToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.openToolStripMenuItem.Name = "openToolStripMenuItem";
			this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
			this.openToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.openToolStripMenuItem.Text = "&Open ROM";
			this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(166, 22);
			this.toolStripMenuItem1.Text = "Open Palette";
			this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
			// 
			// saveToolStripMenuItem
			// 
			this.saveToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripMenuItem.Image")));
			this.saveToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
			this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
			this.saveToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.saveToolStripMenuItem.Text = "&Save ROM";
			this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(163, 6);
			// 
			// exitToolStripMenuItem
			// 
			this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
			this.exitToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.exitToolStripMenuItem.Text = "E&xit";
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Checked = true;
			this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox1.Location = new System.Drawing.Point(7, 581);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(119, 17);
			this.checkBox1.TabIndex = 16;
			this.checkBox1.Text = "Auto-update palette";
			this.checkBox1.UseVisualStyleBackColor = true;
			// 
			// spriteTilemapSelector
			// 
			this.spriteTilemapSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.spriteTilemapSelector.FormattingEnabled = true;
			this.spriteTilemapSelector.Location = new System.Drawing.Point(35, 35);
			this.spriteTilemapSelector.Name = "spriteTilemapSelector";
			this.spriteTilemapSelector.Size = new System.Drawing.Size(152, 21);
			this.spriteTilemapSelector.TabIndex = 22;
			this.spriteTilemapSelector.Tag = "Standard sprites";
			this.spriteTilemapSelector.SelectedIndexChanged += new System.EventHandler(this.spriteTilemapSelector_SelectedIndexChanged);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(35, 16);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(86, 13);
			this.label6.TabIndex = 23;
			this.label6.Text = "Standard sprites:";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(35, 63);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(75, 13);
			this.label7.TabIndex = 24;
			this.label7.Text = "Cluster sprites:";
			// 
			// clusterSpriteTilemapSelector
			// 
			this.clusterSpriteTilemapSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.clusterSpriteTilemapSelector.FormattingEnabled = true;
			this.clusterSpriteTilemapSelector.Location = new System.Drawing.Point(35, 80);
			this.clusterSpriteTilemapSelector.Name = "clusterSpriteTilemapSelector";
			this.clusterSpriteTilemapSelector.Size = new System.Drawing.Size(152, 21);
			this.clusterSpriteTilemapSelector.TabIndex = 25;
			this.clusterSpriteTilemapSelector.Tag = "Cluster sprites";
			this.clusterSpriteTilemapSelector.SelectedIndexChanged += new System.EventHandler(this.spriteTilemapSelector_SelectedIndexChanged);
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(35, 108);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(80, 13);
			this.label8.TabIndex = 26;
			this.label8.Text = "Bounce sprites:";
			// 
			// bounceSpriteTilemapSelector
			// 
			this.bounceSpriteTilemapSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.bounceSpriteTilemapSelector.FormattingEnabled = true;
			this.bounceSpriteTilemapSelector.Location = new System.Drawing.Point(35, 125);
			this.bounceSpriteTilemapSelector.Name = "bounceSpriteTilemapSelector";
			this.bounceSpriteTilemapSelector.Size = new System.Drawing.Size(152, 21);
			this.bounceSpriteTilemapSelector.TabIndex = 27;
			this.bounceSpriteTilemapSelector.Tag = "Bounce sprites";
			this.bounceSpriteTilemapSelector.SelectedIndexChanged += new System.EventHandler(this.spriteTilemapSelector_SelectedIndexChanged);
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(35, 153);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(88, 13);
			this.label9.TabIndex = 28;
			this.label9.Text = "Extended sprites:";
			// 
			// extendedSpriteTilemapSelector
			// 
			this.extendedSpriteTilemapSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.extendedSpriteTilemapSelector.FormattingEnabled = true;
			this.extendedSpriteTilemapSelector.Location = new System.Drawing.Point(35, 169);
			this.extendedSpriteTilemapSelector.Name = "extendedSpriteTilemapSelector";
			this.extendedSpriteTilemapSelector.Size = new System.Drawing.Size(152, 21);
			this.extendedSpriteTilemapSelector.TabIndex = 29;
			this.extendedSpriteTilemapSelector.Tag = "Extended sprites";
			this.extendedSpriteTilemapSelector.SelectedIndexChanged += new System.EventHandler(this.spriteTilemapSelector_SelectedIndexChanged);
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(35, 193);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(116, 13);
			this.label10.TabIndex = 30;
			this.label10.Text = "Minor extended sprites:";
			// 
			// minorExtendedSpriteTilemapSelector
			// 
			this.minorExtendedSpriteTilemapSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.minorExtendedSpriteTilemapSelector.FormattingEnabled = true;
			this.minorExtendedSpriteTilemapSelector.Location = new System.Drawing.Point(35, 210);
			this.minorExtendedSpriteTilemapSelector.Name = "minorExtendedSpriteTilemapSelector";
			this.minorExtendedSpriteTilemapSelector.Size = new System.Drawing.Size(152, 21);
			this.minorExtendedSpriteTilemapSelector.TabIndex = 31;
			this.minorExtendedSpriteTilemapSelector.Tag = "Minor extended sprites";
			this.minorExtendedSpriteTilemapSelector.SelectedIndexChanged += new System.EventHandler(this.spriteTilemapSelector_SelectedIndexChanged);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(35, 234);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(76, 13);
			this.label11.TabIndex = 32;
			this.label11.Text = "Smoke sprites:";
			// 
			// smokeSpriteTilemapSelector
			// 
			this.smokeSpriteTilemapSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.smokeSpriteTilemapSelector.FormattingEnabled = true;
			this.smokeSpriteTilemapSelector.Location = new System.Drawing.Point(35, 251);
			this.smokeSpriteTilemapSelector.Name = "smokeSpriteTilemapSelector";
			this.smokeSpriteTilemapSelector.Size = new System.Drawing.Size(152, 21);
			this.smokeSpriteTilemapSelector.TabIndex = 33;
			this.smokeSpriteTilemapSelector.Tag = "Smoke sprites";
			this.smokeSpriteTilemapSelector.SelectedIndexChanged += new System.EventHandler(this.spriteTilemapSelector_SelectedIndexChanged);
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(35, 274);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(71, 13);
			this.label12.TabIndex = 34;
			this.label12.Text = "Score sprites:";
			// 
			// scoreSpriteTilemapSelector
			// 
			this.scoreSpriteTilemapSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.scoreSpriteTilemapSelector.FormattingEnabled = true;
			this.scoreSpriteTilemapSelector.Location = new System.Drawing.Point(35, 290);
			this.scoreSpriteTilemapSelector.Name = "scoreSpriteTilemapSelector";
			this.scoreSpriteTilemapSelector.Size = new System.Drawing.Size(152, 21);
			this.scoreSpriteTilemapSelector.TabIndex = 35;
			this.scoreSpriteTilemapSelector.Tag = "Score sprits";
			this.scoreSpriteTilemapSelector.SelectedIndexChanged += new System.EventHandler(this.spriteTilemapSelector_SelectedIndexChanged);
			// 
			// standardSpriteNumberLabel
			// 
			this.standardSpriteNumberLabel.AutoSize = true;
			this.standardSpriteNumberLabel.Location = new System.Drawing.Point(7, 38);
			this.standardSpriteNumberLabel.Name = "standardSpriteNumberLabel";
			this.standardSpriteNumberLabel.Size = new System.Drawing.Size(22, 13);
			this.standardSpriteNumberLabel.TabIndex = 36;
			this.standardSpriteNumberLabel.Text = "00:";
			// 
			// clusterSpriteNumberLabel
			// 
			this.clusterSpriteNumberLabel.AutoSize = true;
			this.clusterSpriteNumberLabel.Location = new System.Drawing.Point(7, 83);
			this.clusterSpriteNumberLabel.Name = "clusterSpriteNumberLabel";
			this.clusterSpriteNumberLabel.Size = new System.Drawing.Size(22, 13);
			this.clusterSpriteNumberLabel.TabIndex = 37;
			this.clusterSpriteNumberLabel.Text = "00:";
			// 
			// bounceSpriteNumberLabel
			// 
			this.bounceSpriteNumberLabel.AutoSize = true;
			this.bounceSpriteNumberLabel.Location = new System.Drawing.Point(7, 128);
			this.bounceSpriteNumberLabel.Name = "bounceSpriteNumberLabel";
			this.bounceSpriteNumberLabel.Size = new System.Drawing.Size(22, 13);
			this.bounceSpriteNumberLabel.TabIndex = 38;
			this.bounceSpriteNumberLabel.Text = "00:";
			// 
			// extendedSpriteNumberLabel
			// 
			this.extendedSpriteNumberLabel.AutoSize = true;
			this.extendedSpriteNumberLabel.Location = new System.Drawing.Point(7, 172);
			this.extendedSpriteNumberLabel.Name = "extendedSpriteNumberLabel";
			this.extendedSpriteNumberLabel.Size = new System.Drawing.Size(22, 13);
			this.extendedSpriteNumberLabel.TabIndex = 39;
			this.extendedSpriteNumberLabel.Text = "00:";
			// 
			// minorExtendedSpriteNumberLabel
			// 
			this.minorExtendedSpriteNumberLabel.AutoSize = true;
			this.minorExtendedSpriteNumberLabel.Location = new System.Drawing.Point(7, 213);
			this.minorExtendedSpriteNumberLabel.Name = "minorExtendedSpriteNumberLabel";
			this.minorExtendedSpriteNumberLabel.Size = new System.Drawing.Size(22, 13);
			this.minorExtendedSpriteNumberLabel.TabIndex = 40;
			this.minorExtendedSpriteNumberLabel.Text = "00:";
			// 
			// smokeSpriteNumberLabel
			// 
			this.smokeSpriteNumberLabel.AutoSize = true;
			this.smokeSpriteNumberLabel.Location = new System.Drawing.Point(7, 254);
			this.smokeSpriteNumberLabel.Name = "smokeSpriteNumberLabel";
			this.smokeSpriteNumberLabel.Size = new System.Drawing.Size(22, 13);
			this.smokeSpriteNumberLabel.TabIndex = 41;
			this.smokeSpriteNumberLabel.Text = "00:";
			// 
			// scoreSpriteNumberLabel
			// 
			this.scoreSpriteNumberLabel.AutoSize = true;
			this.scoreSpriteNumberLabel.Location = new System.Drawing.Point(7, 293);
			this.scoreSpriteNumberLabel.Name = "scoreSpriteNumberLabel";
			this.scoreSpriteNumberLabel.Size = new System.Drawing.Size(22, 13);
			this.scoreSpriteNumberLabel.TabIndex = 42;
			this.scoreSpriteNumberLabel.Text = "00:";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(349, 398);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(10, 10);
			this.button1.TabIndex = 43;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// clickDisableTimer
			// 
			this.clickDisableTimer.Interval = 500;
			this.clickDisableTimer.Tick += new System.EventHandler(this.clickDisableTimer_Tick);
			// 
			// refreshTimer
			// 
			this.refreshTimer.Enabled = true;
			this.refreshTimer.Interval = 10;
			this.refreshTimer.Tick += new System.EventHandler(this.refreshTimer_Tick);
			// 
			// checkBox2
			// 
			this.checkBox2.AutoSize = true;
			this.checkBox2.Checked = true;
			this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox2.Location = new System.Drawing.Point(7, 604);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(127, 17);
			this.checkBox2.TabIndex = 44;
			this.checkBox2.Text = "Auto-update graphics";
			this.checkBox2.UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Controls.Add(this.spriteTilemapSelector);
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this.scoreSpriteNumberLabel);
			this.groupBox2.Controls.Add(this.clusterSpriteTilemapSelector);
			this.groupBox2.Controls.Add(this.smokeSpriteNumberLabel);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Controls.Add(this.minorExtendedSpriteNumberLabel);
			this.groupBox2.Controls.Add(this.bounceSpriteTilemapSelector);
			this.groupBox2.Controls.Add(this.extendedSpriteNumberLabel);
			this.groupBox2.Controls.Add(this.label9);
			this.groupBox2.Controls.Add(this.bounceSpriteNumberLabel);
			this.groupBox2.Controls.Add(this.extendedSpriteTilemapSelector);
			this.groupBox2.Controls.Add(this.clusterSpriteNumberLabel);
			this.groupBox2.Controls.Add(this.label10);
			this.groupBox2.Controls.Add(this.standardSpriteNumberLabel);
			this.groupBox2.Controls.Add(this.minorExtendedSpriteTilemapSelector);
			this.groupBox2.Controls.Add(this.scoreSpriteTilemapSelector);
			this.groupBox2.Controls.Add(this.label11);
			this.groupBox2.Controls.Add(this.label12);
			this.groupBox2.Controls.Add(this.smokeSpriteTilemapSelector);
			this.groupBox2.Location = new System.Drawing.Point(349, 29);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(200, 363);
			this.groupBox2.TabIndex = 45;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Sprite selection";
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.gfxBox);
			this.groupBox3.Controls.Add(this.pictureBox2);
			this.groupBox3.Controls.Add(this.gfxSelector1);
			this.groupBox3.Controls.Add(this.numericUpDown1);
			this.groupBox3.Controls.Add(this.gfxSelector2);
			this.groupBox3.Controls.Add(this.checkBox2);
			this.groupBox3.Controls.Add(this.label3);
			this.groupBox3.Controls.Add(this.gfxSelector3);
			this.groupBox3.Controls.Add(this.checkBox1);
			this.groupBox3.Controls.Add(this.label4);
			this.groupBox3.Controls.Add(this.gfxSelector4);
			this.groupBox3.Location = new System.Drawing.Point(12, 29);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(331, 635);
			this.groupBox3.TabIndex = 46;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Graphics";
			// 
			// checkBox5
			// 
			this.checkBox5.AutoSize = true;
			this.checkBox5.Checked = true;
			this.checkBox5.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox5.Location = new System.Drawing.Point(485, 664);
			this.checkBox5.Name = "checkBox5";
			this.checkBox5.Size = new System.Drawing.Size(130, 17);
			this.checkBox5.TabIndex = 47;
			this.checkBox5.Text = "Ignore graphics Y flips";
			this.checkBox5.UseVisualStyleBackColor = true;
			this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(765, 688);
			this.Controls.Add(this.checkBox5);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.yOffsetBox);
			this.Controls.Add(this.tileBox);
			this.Controls.Add(this.xOffsetBox);
			this.Controls.Add(this.menuStrip1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MainMenuStrip = this.menuStrip1;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "STEAR";
			this.Shown += new System.EventHandler(this.Form1_Shown);
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxSelector1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxSelector2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxSelector3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxSelector4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.tileBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gfxBox)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.yOffsetBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.xOffsetBox)).EndInit();
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

	private System.Windows.Forms.NumericUpDown numericUpDown1;
	private System.Windows.Forms.PictureBox pictureBox2;
	private System.Windows.Forms.NumericUpDown gfxSelector1;
	private System.Windows.Forms.NumericUpDown gfxSelector2;
	private System.Windows.Forms.NumericUpDown gfxSelector3;
	private System.Windows.Forms.NumericUpDown gfxSelector4;
	private System.Windows.Forms.PictureBox tileBox;
	private System.Windows.Forms.PictureBox gfxBox;
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.TextBox tileTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.ComboBox tileSelector;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.ComboBox sizeBox;
	private System.Windows.Forms.NumericUpDown yOffsetBox;
	private System.Windows.Forms.NumericUpDown xOffsetBox;
	private System.Windows.Forms.Label label4;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.MenuStrip menuStrip1;
	private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
	private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
	private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
	private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
	private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
	private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
	private System.Windows.Forms.NumericUpDown numericUpDown2;
	private System.Windows.Forms.Label label5;
	private System.Windows.Forms.Label infoLabel;
	private System.Windows.Forms.CheckBox checkBox1;
	private System.Windows.Forms.Label sizeAddressLabel;
	private System.Windows.Forms.Label propAddressLabel;
	private System.Windows.Forms.Label tileAddressLabel;
	private System.Windows.Forms.Label yxppccctLabel;
	private System.Windows.Forms.ComboBox spriteTilemapSelector;
	private System.Windows.Forms.Label label6;
	private System.Windows.Forms.Label label7;
	private System.Windows.Forms.ComboBox clusterSpriteTilemapSelector;
	private System.Windows.Forms.Label label8;
	private System.Windows.Forms.ComboBox bounceSpriteTilemapSelector;
	private System.Windows.Forms.Label label9;
	private System.Windows.Forms.ComboBox extendedSpriteTilemapSelector;
	private System.Windows.Forms.Label label10;
	private System.Windows.Forms.ComboBox minorExtendedSpriteTilemapSelector;
	private System.Windows.Forms.Label label11;
	private System.Windows.Forms.ComboBox smokeSpriteTilemapSelector;
	private System.Windows.Forms.Label label12;
	private System.Windows.Forms.ComboBox scoreSpriteTilemapSelector;
	private System.Windows.Forms.Label standardSpriteNumberLabel;
	private System.Windows.Forms.Label clusterSpriteNumberLabel;
	private System.Windows.Forms.Label bounceSpriteNumberLabel;
	private System.Windows.Forms.Label extendedSpriteNumberLabel;
	private System.Windows.Forms.Label minorExtendedSpriteNumberLabel;
	private System.Windows.Forms.Label smokeSpriteNumberLabel;
	private System.Windows.Forms.Label scoreSpriteNumberLabel;
	private System.Windows.Forms.Button button1;
	private System.Windows.Forms.Timer clickDisableTimer;
	private System.Windows.Forms.Timer refreshTimer;
	private System.Windows.Forms.CheckBox checkBox2;
	private System.Windows.Forms.GroupBox groupBox2;
	private System.Windows.Forms.GroupBox groupBox3;
	private System.Windows.Forms.CheckBox checkBox4;
	private System.Windows.Forms.CheckBox checkBox3;
	private System.Windows.Forms.CheckBox checkBox5;
    }
}


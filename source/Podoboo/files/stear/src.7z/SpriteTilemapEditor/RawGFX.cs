﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SpriteTilemapEditor
{
	class RawGFX
	{
		private DynamicArray<byte> rawData = new DynamicArray<byte>();
		private DynamicArray<Bitmap> tiles = new DynamicArray<Bitmap>();
		private Bitmap mainBitmap = null;

		private Palette palette;
		private int width = 0x10;
		private int bpp;
		private bool needsRefresh = true;

		public Bitmap GetTile(int tile)
		{
			if (needsRefresh)
				Refresh();
			return tiles[tile];
		}

		public Bitmap MainBitmap
		{
			get 
			{
				if (needsRefresh)
					Refresh();
				return mainBitmap; 
			}
		}

		public void SetData(DynamicArray<byte> data)
		{
			rawData = data;
			needsRefresh = true;
		}

		private int[] ExpandByte(byte b, int shift)
		{
			int[] r = new int[8];
			
			for (int i = 0x80, j = 0; i > 0; i >>= 1, j++)
			{
				r[j] = ((b & i) == 0 ? 0 : 1) << shift;
			}
			return r;
		}

		private void Refresh()
		{
			//DynamicArray<ushort> colors;
			if (palette == null) return;
			int tileCount = 0;

			if (bpp == 2) tileCount = rawData.Count / 16;
			else if (bpp == 4) tileCount = rawData.Count / 32;
			else if (bpp == 8) tileCount = rawData.Count / 64;
			else return;

			tiles.Clear();

			int[,] colors = new int[tileCount,64];

			int currentTile = -1;
			
			for (int i = 0; i < rawData.Count; i++)
			{

				if (bpp == 2) if (i % 16 == 0) currentTile++;
				if (bpp == 4) if (i % 32 == 0) currentTile++;
				if (bpp == 8) if (i % 64 == 0) currentTile++;

				int shift = i & 1;
				if (bpp == 4)
					shift += (i & 0x10) >> 3;
				if (bpp == 8)
					shift += (i & 0x30) >> 3;

				int row = (i & 0xF) >> 1;

				int[] bitplane = ExpandByte(rawData[i], shift);

				for (int j = 0; j < 8; j++)
				{
					colors[currentTile, j + row * 8] |= bitplane[j];
				}
			}

			tiles.Clear();

			for (int i = 0; i < tileCount; i++)
			{
				tiles.Add(new Bitmap(8, 8));
				for (int j = 0; j < 64; j++)
				{
					tiles[i].SetPixel(j & 7, j >> 3, palette[colors[i, j]]);
				}
			}

			RefreshMainBitmap();
			needsRefresh = false;
		}

		private void RefreshMainBitmap()
		{
			int x = 0, y = 0;
			mainBitmap = new Bitmap(width * 8, (int)Math.Ceiling(tiles.Count / 16.0) * 8);

			for (int i = 0; i < tiles.Count; i++)
			{
				for (int j = 0; j < 64; j++)
				{
					mainBitmap.SetPixel(x*8 + (j & 7), y*8 + (j >> 3), tiles[i].GetPixel(j & 7, j >> 3));
				}

				x++;

				if (x == width)
				{
					x = 0;
					y++;
				}
			}
		}


		public int BPP
		{
			get { return bpp; }
			set 
			{
				if (value == 2 || value == 4 || value == 8)
				{
					bpp = value; //Refresh();
					needsRefresh = true;
				}
				else
					throw new InvalidOperationException("A graphics file's bpp may only be 2, 4, or 8.");
			}
		}

		public Palette Palette
		{
			get { return palette; }
			set { palette = value; needsRefresh = true; /*Refresh();*/ }
		}

		public int Width
		{
			get { return width; }
			set { width = value; needsRefresh = true; }
		}

	}
}

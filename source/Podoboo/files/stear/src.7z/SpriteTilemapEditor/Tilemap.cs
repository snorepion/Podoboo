﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpriteTilemapEditor
{
	class Property
	{
		public bool y;
		public bool x;
		public byte priority;
		public byte palette;
		public bool page;

		public void FromByte(byte b)
		{
			y = ((b & 0x80) == 0x80);
			x = ((b & 0x40) == 0x40);

			priority = (byte)((b & 0x30) >> 4);
			palette = (byte)((b & 0xE) >> 1);

			page = ((b & 1) == 1);
		}

		public byte ToByte()
		{
			return (byte)((Convert.ToByte(y) << 7) |
			       (Convert.ToByte(x) << 6) |
			       (Convert.ToByte(priority) << 4) |
			       (Convert.ToByte(palette) << 1) |
			       (Convert.ToByte(page)));
		}
	}

	class Address
	{
		public static int SNESToPC(int addr)
		{
			if (addr < 0 || addr > 0xFFFFFF)
				throw new ArgumentException("Specified SNES address was not mapped to ROM (24-bit).");
			else if ((addr & 0xFE0000) == 0x7E0000)
				throw new ArgumentException("Specified SNES address was not mapped to ROM (WRAM).");
			else if ((addr & 0x408000) == 0x000000)
				throw new ArgumentException("Specified SNES address was not mapped to ROM (hardware register).");

			addr = ((addr & 0x7F0000) >> 1 | (addr & 0x7FFF));

			return addr; 
		}

		public static int PCToSNES(int addr)
		{
			if (addr < 0 || addr >= 0x400000)
				return -1;

			addr = ((addr << 1) & 0x7F0000) | (addr & 0x7FFF) | 0x8000;

			if ((addr & 0xF00000) == 0x700000)
				addr |= 0x800000;

			return addr; 
		}	
	}

	public class Part<T> where T : new()
	{
		public int Address;
		public bool Editable;
		public T Value = new T();
		public Part() { }
		public Part(int address, bool editable, T value)
		{
			Address = address;
			Editable = editable;
			Value = value;
		}
	}

	class Tile
	{
		private string name;
		private Part<byte> tile = new Part<byte>();
		private Part<Property> prop = new Part<Property>();
		private Part<byte> xOffset = new Part<byte>();
		private Part<byte> yOffset = new Part<byte>();
		private Part<bool> sizeAddr = new Part<bool>();

		public int TileAddress { get { return tile.Address; } }
		public int PropertyAddress { get { return prop.Address; } }
		public int SizeAddress { get { return sizeAddr.Address; } }

		public byte[] ROM = null;

		public string Name
		{
			get { return name;}
			set { name = value; }
		}
		public ushort TileIndex
		{
			get 
			{
				GetData();
				return (ushort)(tile.Value + (prop.Value.page == false ? 0 : 0x100));
			}
			set 
			{ 
				tile.Value = (byte)(value & 0xFF);
				SetData();
				if (PropertyEditable)
					Page = (value >= 0x100);
				else
				{
					if (Page != (value >= 0x100))
						System.Windows.Forms.MessageBox.Show("Warning: This tile must remain on its current page.  It will be automatically moved the next time this tile is loaded.");
				}
				SetData();
			}
		}
		public Property Property
		{
			get { GetData();  return prop.Value; }
			set { prop.Value = value; SetData(); }
		}
		public byte XOffset
		{
			get { GetData(); return xOffset.Value; }
			set { xOffset.Value = value; SetData(); }
		}
		public byte YOffset
		{
			get { GetData(); return yOffset.Value; }
			set { yOffset.Value = value; SetData(); }
		}
		public bool Size
		{
			get { GetData(); return sizeAddr.Value; }
			set { sizeAddr.Value = value; SetData(); }
		}
		public byte Palette
		{
			get { GetData(); return prop.Value.palette; }
			set { prop.Value.palette = value; SetData(); }
		}
		public bool Page
		{
			get { GetData(); return prop.Value.page; }
			set { prop.Value.page = value; SetData(); }
		}

		public bool PropertyEditable
		{
			get { return prop.Editable; }
		}
		public bool TileEditable
		{
			get { return tile.Editable; }
		}
		public bool XOffsetEditable
		{
			get { return xOffset.Editable; }
		}
		public bool YOffsetEditable
		{
			get { return yOffset.Editable; }
		}
		public bool SizeEditable
		{
			get { return sizeAddr.Editable; }
		}

		public Tile()
		{
			tile.Address = -1;
			tile.Editable = false;

			prop.Address = -1;
			prop.Editable = false;

			xOffset.Address = -1;
			xOffset.Value = 0;
			xOffset.Editable = false;

			yOffset.Address = -1;
			yOffset.Value = 0;
			yOffset.Editable = false;

			sizeAddr.Address = -1;
			sizeAddr.Value = false;
			sizeAddr.Editable = false;

			prop.Address = -1;
			prop.Value.page = false;
			prop.Editable = false;
		}

		public Tile(string Name, int TileAddr, int PropAddr, int SizeAddr, int xAddr, int yAddr) : this()
		{
			name = Name;

			if (TileAddr != -1)
			{
				tile.Address = TileAddr;
				tile.Editable = true;
			}

			if (PropAddr != -1)
			{
				prop.Address = PropAddr;
				prop.Editable = true;
			}

			xOffset.Address = xAddr;
			xOffset.Editable = true;

			yOffset.Address = yAddr;
			yOffset.Editable = true;

			if (SizeAddr != -1)
			{
				sizeAddr.Address = SizeAddr;
				sizeAddr.Editable = true;
			}
		}

		public Tile(string Name, int TileAddr, int PropAddr, int SizeAddr) : this()
		{
			name = Name;

			if (TileAddr != -1)
			{
				tile.Address = TileAddr;
				tile.Editable = true;
			}

			if (PropAddr != -1)
			{
				prop.Address = PropAddr;
				prop.Editable = true;
			}

			xOffset.Address = -1;
			xOffset.Value = 0;
			xOffset.Editable = false;

			yOffset.Address = -1;
			yOffset.Value = 0;
			yOffset.Editable = false;

			if (SizeAddr != -1)
			{
				sizeAddr.Address = SizeAddr;
				sizeAddr.Editable = true;
			}

		}

		public Tile(string Name, int TileAddr, int PropAddr, bool big) : this()
		{
			name = Name;

			if (TileAddr != -1)
			{
				tile.Address = TileAddr;
				tile.Editable = true;
			}

			if (PropAddr != -1)
			{
				prop.Address = PropAddr;
				prop.Editable = true;
			}

			xOffset.Address = -1;
			xOffset.Value = 0;
			xOffset.Editable = false;

			yOffset.Address = -1;
			yOffset.Value = 0;
			yOffset.Editable = false;

			sizeAddr.Address = -1;
			sizeAddr.Value = big;
			sizeAddr.Editable = false;
		}

		public Tile(string Name, int TileAddr, bool page1, bool big) : this()
		{
			name = Name;

			if (TileAddr != -1)
			{
				tile.Address = TileAddr;
				tile.Editable = true;
			}

			prop.Address = -1;
			prop.Editable = false;

			xOffset.Address = -1;
			xOffset.Value = 0;
			xOffset.Editable = false;

			yOffset.Address = -1;
			yOffset.Value = 0;
			yOffset.Editable = false;

			sizeAddr.Address = -1;
			sizeAddr.Value = big;
			sizeAddr.Editable = false;

			prop.Address = -1;
			prop.Value.page = page1;
			prop.Editable = false;
		}

		private void GetData()
		{
			if (tile.Address != -1)
				tile.Value = ROM[Address.SNESToPC(tile.Address)];

			if (prop.Address != -1)
				prop.Value.FromByte(ROM[Address.SNESToPC(prop.Address)]);

			if (xOffset.Address != -1)
				xOffset.Value = ROM[Address.SNESToPC(xOffset.Address)];

			if (yOffset.Address != -1)
				yOffset.Value = ROM[Address.SNESToPC(yOffset.Address)];

			if (sizeAddr.Address != -1)
			{
				if (ROM[Address.SNESToPC(sizeAddr.Address)] != 0 && ROM[Address.SNESToPC(sizeAddr.Address)] != 2)
					throw new Exception("WARNING: Size byte was not 0 or 2.  Looks like I dun goofed.  Don't edit the size, and report this error.");
				sizeAddr.Value = (ROM[Address.SNESToPC(sizeAddr.Address)] == 2);
			}
		}

		private void SetData()
		{
			if (tile.Address != -1)
				ROM[Address.SNESToPC(tile.Address)] = tile.Value;

			if (prop.Address != -1)
				ROM[Address.SNESToPC(prop.Address)] = prop.Value.ToByte();

			if (xOffset.Address != -1)
				ROM[Address.SNESToPC(xOffset.Address)] = xOffset.Value;

			if (yOffset.Address != -1)
				ROM[Address.SNESToPC(yOffset.Address)] = yOffset.Value;

			if (sizeAddr.Address != -1)
				ROM[Address.SNESToPC(sizeAddr.Address)] = (byte)(sizeAddr.Value == false ? 0 : 2);
		}

		public override string ToString()
		{
			return name;
		}
	}

	class Tilemap
	{
		public string name;
		public string information;
		public DynamicArray<Tile> tiles;

		public Tilemap(string Name, string Information, DynamicArray<Tile> Tiles)
		{
			name = Name;
			tiles = Tiles;
			information = Information;
		}

		public Tilemap(string Name, string Information, Tile[] Tiles)
		{
			name = Name;
			tiles = Tiles;
			information = Information;
		}

		/*public void GetData(byte[] ROM)
		{
			foreach (Tile t in tiles)
			{
				t.GetData(ROM);
			}
		}

		public void SetData(byte[] ROM)
		{
			foreach (Tile t in tiles)
			{
				t.SetData(ROM);
			}
		}*/

		public override string ToString()
		{
			return name;
		}

		public Tilemap Copy()
		{
			DynamicArray<Tile> newTiles = new DynamicArray<Tile>();
			for (int i = 0; i < tiles.Count; i++) newTiles.Add(tiles[i]);
			Tilemap t = new Tilemap(name, information, newTiles);
			return t;
		}

		public Tilemap Copy(string newName)
		{
			DynamicArray<Tile> newTiles = new DynamicArray<Tile>();
			for (int i = 0; i < tiles.Count; i++) newTiles.Add(tiles[i]);
			Tilemap t = new Tilemap(newName, information, newTiles);
			return t;
		}
	}

}

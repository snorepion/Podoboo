Wall Kick
=========

This patch enables Mario to kick off of walls by sliding along them and pressing the B button. You can force the wall kick to only be used when the player has a powerup.
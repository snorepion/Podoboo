﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InteractionEditor {
    class Point {
        public Int16 XOFF, YOFF;

        public Point(Int16 XOFF, Int16 YOFF) {
            this.XOFF = XOFF;
            this.YOFF = YOFF;
        }

        public string getX() {
            return "$" + XOFF.ToString("x4");
        }

        public string getY() {
            return "$" + YOFF.ToString("x4");
        }

        public Point Copy() {
            return new Point(this.XOFF, this.YOFF);
        }
    }
}

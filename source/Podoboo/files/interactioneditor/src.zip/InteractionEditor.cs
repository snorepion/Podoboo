﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace InteractionEditor {
    public partial class InteractionEditor : Form {
        static int xorigin = (212 / 2 - 16) / 2;
        static int yorigin = (181 / 2 - 16 * 3) / 2;
        string dir = Directory.GetCurrentDirectory();
        string template;
        HitboxType current = HitboxType.CENTER;

        HitboxInfo[] info = new HitboxInfo[13];
        Image[] refr = new Image[13];
        
        public InteractionEditor() {
            InitializeComponent();
            template = dir + "/template.asm";
            loadHitboxInfo(dir + "/hitboxinfo.iedt", false);
            Bitmap img = new Bitmap(16 * 2, (16 * 3) * 2);
            Graphics g = Graphics.FromImage(img);
            g.DrawRectangle(new Pen(Color.Red), 0, 0, 16*2-1, 32*2-1);
            g.DrawLine(new Pen(Color.Orange), 0, 32, 32, 32);
            g.DrawRectangle(new Pen(Color.Green), 0, 32 * 2, 16 * 2 - 1, 16 * 2 - 1);
            for (int i = 0; i < 13; i++)
                refr[i] = img;
            lb_hitboxtype.SelectedIndex = 0;
        }

        private void loadHitboxInfo(string path, bool ask) {

            FileStream file;
            try {
                file = File.OpenRead(path);
                file.Seek(0, SeekOrigin.Begin);
            } catch {
                warn("Cannot read '" + path + "'. Using default '0' for all values");
                resetInfo();
                return;
            }

            int d1 = file.ReadByte();
            int d2 = file.ReadByte();
            int d3 = file.ReadByte();
            int d4 = file.ReadByte();
            if (file.Length != 0xF4 || d1 != 0x00 || d2 != 0xFC || d3 != 0x1C || d4 != 0xA8) {
                warn(path + " is not a valid info file, Using default '0' for all values");
                resetInfo();
                return;
            }

            ImportForm iFrm = new ImportForm();
            if(ask)
                if (iFrm.ShowDialog() != DialogResult.OK)
                    return;

            bool[] nCI = iFrm.getCheckedIPoints();
            for(int i = 0; i < 9; i++) {
                Point center = new Point(next(file), next(file));
                Point sBody = new Point(next(file), next(file));
                Point sHead = new Point(next(file), next(file));
                Point head = new Point(next(file), next(file));
                Point lFoot = new Point(next(file), next(file));
                Point rFoot = new Point(next(file), next(file));
                if (!nCI[i]) continue;
                info[i] = new HitboxInfo(center, sBody, sHead, head, lFoot, rFoot);
            }

            bool[] nCS = iFrm.getCheckedSpriteHB();
            for (int i = 0; i < 4; i++) {
                short x = next(file);
                short y = next(file);
                byte w = (byte)file.ReadByte();
                byte h = (byte)file.ReadByte();
                if (!nCS[i]) continue;
                info[9 + i] = new HitboxInfo(x, y, w, h);
            }

            file.Close();
        }

        private void tsmi_create_file_Click(object sender, EventArgs e) {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Hitbox info file|*.iedt";
            if (sfd.ShowDialog() == DialogResult.OK)
                saveFile(sfd.FileName);
        }

        private void saveFile(string path) {
            byte[] file = new byte[0xF4];
            file[0] = 0x00;
            file[1] = 0xFC;
            file[2] = 0x1C;
            file[3] = 0xA8;

            for (int i = 0; i < 9; i++) {
                file[i * 24 + 4 + 00] = getLo(info[i].center.XOFF);
                file[i * 24 + 4 + 01] = getHi(info[i].center.XOFF);
                file[i * 24 + 4 + 02] = getLo(info[i].center.YOFF);
                file[i * 24 + 4 + 03] = getHi(info[i].center.YOFF);

                file[i * 24 + 4 + 04] = getLo(info[i].sBody.XOFF);
                file[i * 24 + 4 + 05] = getHi(info[i].sBody.XOFF);
                file[i * 24 + 4 + 06] = getLo(info[i].sBody.YOFF);
                file[i * 24 + 4 + 07] = getHi(info[i].sBody.YOFF);

                file[i * 24 + 4 + 08] = getLo(info[i].sHead.XOFF);
                file[i * 24 + 4 + 09] = getHi(info[i].sHead.XOFF);
                file[i * 24 + 4 + 10] = getLo(info[i].sHead.YOFF);
                file[i * 24 + 4 + 11] = getHi(info[i].sHead.YOFF);

                file[i * 24 + 4 + 12] = getLo(info[i].head.XOFF);
                file[i * 24 + 4 + 13] = getHi(info[i].head.XOFF);
                file[i * 24 + 4 + 14] = getLo(info[i].head.YOFF);
                file[i * 24 + 4 + 15] = getHi(info[i].head.YOFF);

                file[i * 24 + 4 + 16] = getLo(info[i].lFoot.XOFF);
                file[i * 24 + 4 + 17] = getHi(info[i].lFoot.XOFF);
                file[i * 24 + 4 + 18] = getLo(info[i].lFoot.YOFF);
                file[i * 24 + 4 + 19] = getHi(info[i].lFoot.YOFF);

                file[i * 24 + 4 + 20] = getLo(info[i].rFoot.XOFF);
                file[i * 24 + 4 + 21] = getHi(info[i].rFoot.XOFF);
                file[i * 24 + 4 + 22] = getLo(info[i].rFoot.YOFF);
                file[i * 24 + 4 + 23] = getHi(info[i].rFoot.YOFF);
            }

            for (int i = 0; i < 4; i++) {
                file[i * 6 + 220] = getLo(info[9 + i].XOFF);
                file[i * 6 + 221] = getHi(info[9 + i].XOFF);
                file[i * 6 + 222] = getLo(info[9 + i].YOFF);
                file[i * 6 + 223] = getHi(info[9 + i].YOFF);
                file[i * 6 + 224] = getLo(info[9 + i].WIDTH);
                file[i * 6 + 225] = getLo(info[9 + i].HEIGHT);
            }

            File.WriteAllBytes(path, file);
        }

        private byte getLo(short val) {
            return (byte)(val&0xFF);
        }

        private byte getHi(short val) {
            return (byte)((val>>8)&0xFF);
        }

        private short next(FileStream stream) {
            int l = stream.ReadByte();
            int h = stream.ReadByte();
            return (short)(h*0x100+l);
        }

        private void resetInfo() {
            Point n = new Point(0, 0);
            for(int i = 0; i < 9; i++)
                info[i] = new HitboxInfo(n.Copy(), n.Copy(), n.Copy(), n.Copy(), n.Copy(), n.Copy());

            for (int i = 0; i < 4; i++)
                info[9 + i] = new HitboxInfo(0, 0, 0, 0);
        }

        private void lb_hitboxtype_SelectedIndexChanged(object sender, EventArgs e) {
            gb_points.Visible = (lb_hitboxtype.SelectedIndex < 9);
            loadHitbox(info[lb_hitboxtype.SelectedIndex]);
        }

        private void loadHitbox(HitboxInfo hb) {
            Bitmap points = new Bitmap(212, 181);
            Graphics g = Graphics.FromImage(points);
            g.DrawImage(refr[lb_hitboxtype.SelectedIndex], xorigin * 2, yorigin * 2);
            if (hb.type == HitboxType.LAYER) {
                g.DrawRectangle(new Pen(Color.White), (xorigin + hb.center.XOFF) * 2, (yorigin + hb.center.YOFF) * 2, 1, 1);
                g.DrawRectangle(new Pen(Color.Orange), (xorigin + hb.sBody.XOFF) * 2, (yorigin + hb.sBody.YOFF) * 2, 1, 1);
                g.DrawRectangle(new Pen(Color.Red), (xorigin + hb.sHead.XOFF) * 2, (yorigin + hb.sHead.YOFF) * 2, 1, 1);
                g.DrawRectangle(new Pen(Color.Yellow), (xorigin + hb.head.XOFF) * 2, (yorigin + hb.head.YOFF) * 2, 1, 1);
                g.DrawRectangle(new Pen(Color.Lime), (xorigin + hb.lFoot.XOFF) * 2, (yorigin + hb.lFoot.YOFF) * 2, 1, 1);
                g.DrawRectangle(new Pen(Color.Pink), (xorigin + hb.rFoot.XOFF) * 2, (yorigin + hb.rFoot.YOFF) * 2, 1, 1);
            } else {
                int x1 = xorigin + hb.XOFF;
                int x2 = x1 + hb.WIDTH;
                int y1 = yorigin + hb.YOFF;
                int y2 = y1 + hb.HEIGHT;
                
                g.DrawLine(new Pen(Color.White), x1 * 2, y1 * 2, x2 * 2, y1 * 2);
                g.DrawLine(new Pen(Color.White), x1 * 2, y1 * 2, x1 * 2, y2 * 2);
                g.DrawLine(new Pen(Color.White), x2 * 2, y2 * 2, x1 * 2, y2 * 2);
                g.DrawLine(new Pen(Color.White), x2 * 2, y2 * 2, x2 * 2, y1 * 2);
            }
            pb_points.Image = points;
            updateText(hb);
        }

        private void updateText(HitboxInfo hb) {
            if (hb.type == HitboxType.LAYER) {
                Point p = hb.getPoint(current);
                tb_X.Text = p.XOFF.ToString("x4").ToUpper();
                tb_Y.Text = p.YOFF.ToString("x4").ToUpper();
                tb_width.Text = "--";
                tb_height.Text = "--";
            } else {
                tb_X.Text = hb.XOFF.ToString("x4").ToUpper();
                tb_Y.Text = hb.YOFF.ToString("x4").ToUpper();
                tb_width.Text = hb.WIDTH.ToString("x2").ToUpper();
                tb_height.Text = hb.HEIGHT.ToString("x2").ToUpper();
            }
        }

        private void warn(string warning) {
            MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void err(string error) {
            MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void tsmi_create_patch_Click(object sender, EventArgs e) {
            string layerX = "dw ";
            string layerY = "dw ";
            for (int i = 0; i < 9; i++) {
                layerX += info[i].getX() + ((i == 8) ? "" : ",");
                layerY += info[i].getY() + ((i == 8) ? "" : ",");
            }

            string spriteX, spriteY, spriteW, spriteH, spriteXh, spriteYh;
            if (tsmi_16bitsprite.Checked) {
                spriteX = "dw ";
                spriteY = "dw ";
                spriteW = "dw ";
                spriteH = "dw ";
                spriteXh = ""; // Unused in 16-bit mode
                spriteYh = "";
            } else {
                spriteX = "db ";
                spriteY = "db ";
                spriteXh = "db ";
                spriteYh = "db ";
                spriteW = "db ";
                spriteH = "db ";
            }
            for (int i = 0; i < 4; i++) {
                spriteX += info[9 + i].getX(tsmi_16bitsprite.Checked) + ((i == 3) ? "" : ",");
                spriteY += info[9 + i].getY(tsmi_16bitsprite.Checked) + ((i == 3) ? "" : ",");
                spriteW += info[9 + i].getW(tsmi_16bitsprite.Checked) + ((i == 3) ? "" : ",");
                spriteH += info[9 + i].getH(tsmi_16bitsprite.Checked) + ((i == 3) ? "" : ",");
                if (!tsmi_16bitsprite.Checked) {
                    spriteXh += info[9 + i].getXh() + ((i == 3) ? "" : ",");
                    spriteYh += info[9 + i].getYh() + ((i == 3) ? "" : ",");
                }
            }

            displayCode(layerX, layerY, spriteX, spriteY, spriteXh, spriteYh, spriteW, spriteH, template);
        }

        private void  displayCode(string layerX, string layerY, string spriteX, string spriteY, string spriteXh, string spriteYh, string spriteW, string spriteH, string template){
            if(!File.Exists(template)) {
                warn("Cannot find file '" + template + "'. Tables are written without a patch.");
                string[] content = new string[8];
                content[0] = "IPointX:\n" + layerX;
                content[1] = "IPointY:\n" + layerY;
                content[2] = "SpriteW:\n" + spriteW;
                content[3] = "SpriteH:\n" + spriteH;
                content[4] = "SpriteX:\n" + spriteX;
                content[5] = "SpriteY:\n" + spriteY;
                content[6] = (tsmi_16bitsprite.Checked) ? "" : "SpriteXh:\n" + spriteXh;
                content[7] = (tsmi_16bitsprite.Checked) ? "" : "SpriteYh:\n" + spriteYh;

                CodeDisplay disp = new CodeDisplay(content);
                disp.ShowDialog(this);
            } else {
                string[] content = File.ReadAllLines(template);
                if (content[0] == ";require 8bit" && tsmi_16bitsprite.Checked) {
                    err("The template file requires a 8-bit sprite hitbox");
                    return;
                } else if (content[0] == ";require 16bit" && !tsmi_16bitsprite.Checked) {
                    err("The template file requires a 16-bit sprite hitbox");
                    return;
                }
                for(int i = 0; i < content.Length; i++) {
                    content[i] = content[i]
                        .Replace("IPointX:", "IPointX:\n" + layerX)
                        .Replace("IPointY:", "IPointY:\n" + layerY)
                        .Replace("SpriteX:", "SpriteX:\n" + spriteX)
                        .Replace("SpriteY:", "SpriteY:\n" + spriteY)
                        .Replace("SpriteXh:", "SpriteXh:\n" + spriteXh)
                        .Replace("SpriteYh:", "SpriteYh:\n" + spriteYh)
                        .Replace("SpriteW:", "SpriteW:\n" + spriteW)
                        .Replace("SpriteH:", "SpriteH:\n" + spriteH);
                }

                CodeDisplay disp = new CodeDisplay(content);
                disp.ShowDialog(this);
            }
        }

        private void tsmi_open_file_Click(object sender, EventArgs e) {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Hitbox info file|*.iedt";
            if (ofd.ShowDialog() == DialogResult.OK) {
                loadHitboxInfo(ofd.FileName, true);
                loadHitbox(info[lb_hitboxtype.SelectedIndex]);
            }
        }

        private void pb_points_Click(object sender, MouseEventArgs e) {
             if (lb_hitboxtype.SelectedIndex < 9) {
                HitboxInfo box = info[lb_hitboxtype.SelectedIndex];
                switch (current) {
                    case HitboxType.CENTER:
                        box.center.XOFF = (short)(e.X/2 - xorigin);
                        box.center.YOFF = (short)(e.Y/2 - yorigin);
                        break;
                    case HitboxType.SBODY:
                        box.sBody.XOFF = (short)(e.X/2 - xorigin);
                        box.sBody.YOFF = (short)(e.Y/2 - yorigin);
                        break;
                    case HitboxType.SHEAD:
                        box.sHead.XOFF = (short)(e.X/2 - xorigin);
                        box.sHead.YOFF = (short)(e.Y/2 - yorigin);
                        break;
                    case HitboxType.HEAD:
                        box.head.XOFF = (short)(e.X/2 - xorigin);
                        box.head.YOFF = (short)(e.Y/2 - yorigin);
                        break;
                    case HitboxType.LFOOT:
                        box.lFoot.XOFF = (short)(e.X/2 - xorigin);
                        box.lFoot.YOFF = (short)(e.Y/2 - yorigin);
                        break;
                    case HitboxType.RFOOT:
                        box.rFoot.XOFF = (short)(e.X/2 - xorigin);
                        box.rFoot.YOFF = (short)(e.Y/2 - yorigin);
                        break;
                }
            } else {
                HitboxInfo box = info[lb_hitboxtype.SelectedIndex];
                switch (current) {
                    case HitboxType.CENTER:
                        box.XOFF = (short)(e.X - xorigin);
                        break;
                    case HitboxType.SBODY:
                        short w = (short)(e.X - (xorigin + box.XOFF));
                        if (w > 0)
                            box.WIDTH = w;
                        break;
                    case HitboxType.SHEAD:
                        box.YOFF = (short)(e.Y - yorigin);
                        break;
                    case HitboxType.HEAD:
                        short h = (short)(e.Y - (yorigin + box.YOFF));
                        if (h > 0)
                            box.HEIGHT = h;
                        break;
                }
            }

            loadHitbox(info[lb_hitboxtype.SelectedIndex]);
        }

        private void rb_center_CheckedChanged(object sender, EventArgs e) {
            if (rb_center.Checked) {
                current = HitboxType.CENTER;
                updateText(info[lb_hitboxtype.SelectedIndex]);
            }
        }

        private void rb_side_body_CheckedChanged(object sender, EventArgs e) {
            if (rb_side_body.Checked) {
                current = HitboxType.SBODY;
                updateText(info[lb_hitboxtype.SelectedIndex]);
            }
        }

        private void rb_side_head_CheckedChanged(object sender, EventArgs e) {
            if (rb_side_head.Checked) {
                current = HitboxType.SHEAD;
                updateText(info[lb_hitboxtype.SelectedIndex]);
            }
        }

        private void rb_head_CheckedChanged(object sender, EventArgs e) {
            if (rb_head.Checked) {
                current = HitboxType.HEAD;
                updateText(info[lb_hitboxtype.SelectedIndex]);
            }
        }

        private void rb_lfoot_CheckedChanged(object sender, EventArgs e) {
            if (rb_lfoot.Checked) {
                current = HitboxType.LFOOT;
                updateText(info[lb_hitboxtype.SelectedIndex]);
            }
        }

        private void rb_rfoot_CheckedChanged(object sender, EventArgs e) {
            if (rb_rfoot.Checked) {
                current = HitboxType.RFOOT;
                updateText(info[lb_hitboxtype.SelectedIndex]);
            }
        }

        private void tsmi_hide_Click(object sender, EventArgs e) {
            loadHitbox(info[lb_hitboxtype.SelectedIndex]);
        }

        private void btn_update_Click(object sender, EventArgs e) {
            HitboxInfo box = info[lb_hitboxtype.SelectedIndex];
            try {
                box.setX(Convert.ToInt16(tb_X.Text, 16), current);
            } catch {}
            try {
                box.setY(Convert.ToInt16(tb_Y.Text, 16), current);
            } catch {}
            try {
                box.setW(Convert.ToInt16(tb_width.Text, 16));
            } catch {}
            try {
                box.setH(Convert.ToInt16(tb_height.Text, 16));
            } catch {}

            loadHitbox(info[lb_hitboxtype.SelectedIndex]);
        }

        private void tsmi_open_template_Click(object sender, EventArgs e) {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "ASM files | *.asm";
            if (ofd.ShowDialog() == DialogResult.OK) {
                this.template = ofd.FileName;
                MessageBox.Show("Changed template file to \"" + ofd.FileName + "\"");
            }
        }
    }
}
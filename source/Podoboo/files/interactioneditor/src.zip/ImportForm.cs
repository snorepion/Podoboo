﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace InteractionEditor {
    public partial class ImportForm : Form {
        public ImportForm() {
            InitializeComponent();
        }

        public bool[] getCheckedIPoints() {
            bool[] ret = new bool[9];

            ret[0] = cb_small_r.Checked;
            ret[1] = cb_small_l.Checked;
            ret[2] = cb_big_r.Checked;
            ret[3] = cb_big_l.Checked;
            ret[4] = cb_yoshi_small_r.Checked;
            ret[5] = cb_yoshi_small_l.Checked;
            ret[6] = cb_yoshi_big_r.Checked;
            ret[7] = cb_yoshi_big_l.Checked;
            ret[8] = cb_wall.Checked;

            return ret;
        }

        public bool[] getCheckedSpriteHB() {
            bool[] ret = new bool[4];

            ret[0] = cb_spr_big.Checked;
            ret[1] = cb_spr_small.Checked;
            ret[2] = cb_spr_yoshi_big.Checked;
            ret[3] = cb_spr_yoshi_small.Checked;

            return ret;
        }

        private void btn_confirm_Click(object sender, EventArgs e) {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btn_cancel_Click(object sender, EventArgs e) {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btn_uncheck_Click(object sender, EventArgs e) {
            cb_small_r.Checked = false;
            cb_small_l.Checked = false;
            cb_big_r.Checked = false;
            cb_big_l.Checked = false;
            cb_yoshi_small_r.Checked = false;
            cb_yoshi_small_l.Checked = false;
            cb_yoshi_big_r.Checked = false;
            cb_yoshi_big_l.Checked = false;
            cb_wall.Checked = false;
            cb_spr_big.Checked = false;
            cb_spr_small.Checked = false;
            cb_spr_yoshi_big.Checked = false;
            cb_spr_yoshi_small.Checked = false;
        }
    }
}

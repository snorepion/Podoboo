﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InteractionEditor {
    class HitboxInfo {
        public HitboxType type;
        public short XOFF,YOFF,WIDTH,HEIGHT;
        public Point center, sBody, sHead, head, lFoot, rFoot;

        public HitboxInfo(Point center, Point sBody, Point sHead, Point head, Point lFoot, Point rFoot) {
            this.type = HitboxType.LAYER;
            this.center = center;
            this.sBody = sBody;
            this.sHead = sHead;
            this.head = head;
            this.lFoot = lFoot;
            this.rFoot = rFoot;
        }

        public HitboxInfo(short XOFF, short YOFF, byte WIDTH, byte HEIGHT) {
            this.type = HitboxType.SPRITE;
            this.XOFF = XOFF;
            this.YOFF = YOFF;
            this.WIDTH = WIDTH;
            this.HEIGHT = HEIGHT;
        }

        public string getX(bool useword = false) {
            switch (type) {
                case HitboxType.LAYER:
                    StringBuilder x = new StringBuilder();
                    x.AppendFormat("{0},{1},{2},{3},{4},{5}", center.getX(), sBody.getX(), sHead.getX(), head.getX(), lFoot.getX(), rFoot.getX());
                    return x.ToString();
                case HitboxType.SPRITE:
                    if (useword)
                        return "$" + (this.XOFF).ToString("x4");
                    else
                        return "$" + (this.XOFF & 0xFF).ToString("x2");
                default:
                    return "";
            }
        }

        public string getY(bool useword = false) {
            switch (type) {
                case HitboxType.LAYER:
                    StringBuilder x = new StringBuilder();
                    x.AppendFormat("{0},{1},{2},{3},{4},{5}", center.getY(), sBody.getY(), sHead.getY(), head.getY(), lFoot.getY(), rFoot.getY());
                    return x.ToString();
                case HitboxType.SPRITE:
                    if (useword)
                        return "$" + (this.YOFF).ToString("x4");
                    else
                        return "$" + (this.YOFF & 0xFF).ToString("x2");
                default:
                    return "";
            }
        }

        public string getXh() {
            switch (type) {
                case HitboxType.SPRITE:
                    return "$" + ((this.XOFF >> 8) & 0xFF).ToString("x2");
                default:
                    return "";
            }
        }

        public string getYh() {
            switch (type) {
                case HitboxType.SPRITE:
                    return "$" + ((this.YOFF >> 8) & 0xFF).ToString("x2");
                default:
                    return "";
            }
        }

        public string getW(bool useword) {
            switch (type) {
                case HitboxType.SPRITE:
                    if (useword)
                        return "$" + (this.WIDTH).ToString("x4");
                    else
                        return "$" + (this.WIDTH & 0xFF).ToString("x2");
                default:
                    return "";
            }
        }

        public string getH(bool useword) {
            switch (type) {
                case HitboxType.SPRITE:
                    if (useword)
                        return "$" + (this.HEIGHT).ToString("x4");
                    else
                        return "$" + (this.HEIGHT & 0xFF).ToString("x2");
                default:
                    return "";
            }
        }

        public Point getPoint(HitboxType type) {
            switch (type) {
                case HitboxType.CENTER:
                    return this.center;
                case HitboxType.SBODY:
                    return this.sBody;
                case HitboxType.SHEAD:
                    return this.sHead;
                case HitboxType.HEAD:
                    return this.head;
                case HitboxType.LFOOT:
                    return this.lFoot;
                case HitboxType.RFOOT:
                    return this.rFoot;
                default:
                    return new Point(0,0);
            }
        }

        public void setX(short x, HitboxType s) {
            if(this.type == HitboxType.LAYER) {
                switch(s){
                    case HitboxType.CENTER:
                        this.center.XOFF = x;
                        break;
                    case HitboxType.SBODY:
                        this.sBody.XOFF = x;
                        break;
                    case HitboxType.SHEAD:
                        this.sHead.XOFF = x;
                        break;
                    case HitboxType.HEAD:
                        this.head.XOFF = x;
                        break;
                    case HitboxType.LFOOT:
                        this.lFoot.XOFF = x;
                        break;
                    case HitboxType.RFOOT:
                        this.rFoot.XOFF = x;
                        break;
                }
            } else {
                this.XOFF = x;
            }
        }

        public void setY(short y, HitboxType s) {
            if (this.type == HitboxType.LAYER) {
                switch(s){
                    case HitboxType.CENTER:
                        this.center.YOFF = y;
                        break;
                    case HitboxType.SBODY:
                        this.sBody.YOFF = y;
                        break;
                    case HitboxType.SHEAD:
                        this.sHead.YOFF = y;
                        break;
                    case HitboxType.HEAD:
                        this.head.YOFF = y;
                        break;
                    case HitboxType.LFOOT:
                        this.lFoot.YOFF = y;
                        break;
                    case HitboxType.RFOOT:
                        this.rFoot.YOFF = y;
                        break;
                }
            } else {
                this.YOFF = y;
            }
        }

        public void setW(short w) {
            if (this.type == HitboxType.SPRITE)
                this.WIDTH = w;
        }

        public void setH(short h) {
            if (this.type == HitboxType.SPRITE)
                this.HEIGHT = h;
        }
    }
}
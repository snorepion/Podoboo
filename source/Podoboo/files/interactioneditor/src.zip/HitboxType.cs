﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InteractionEditor {
    enum HitboxType {
        LAYER,SPRITE,CENTER,SBODY,SHEAD,HEAD,LFOOT,RFOOT
    }
}
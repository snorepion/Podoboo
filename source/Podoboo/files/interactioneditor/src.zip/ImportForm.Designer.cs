﻿namespace InteractionEditor
{
    partial class ImportForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Automatically generated code

        private void InitializeComponent()
        {
            this.gb_ipoints = new System.Windows.Forms.GroupBox();
            this.cb_wall = new System.Windows.Forms.CheckBox();
            this.cb_yoshi_big_l = new System.Windows.Forms.CheckBox();
            this.cb_yoshi_big_r = new System.Windows.Forms.CheckBox();
            this.cb_yoshi_small_l = new System.Windows.Forms.CheckBox();
            this.cb_yoshi_small_r = new System.Windows.Forms.CheckBox();
            this.cb_big_l = new System.Windows.Forms.CheckBox();
            this.cb_big_r = new System.Windows.Forms.CheckBox();
            this.cb_small_l = new System.Windows.Forms.CheckBox();
            this.cb_small_r = new System.Windows.Forms.CheckBox();
            this.gb_sprhitbox = new System.Windows.Forms.GroupBox();
            this.cb_spr_yoshi_big = new System.Windows.Forms.CheckBox();
            this.cb_spr_big = new System.Windows.Forms.CheckBox();
            this.cb_spr_yoshi_small = new System.Windows.Forms.CheckBox();
            this.cb_spr_small = new System.Windows.Forms.CheckBox();
            this.btn_confirm = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_uncheck = new System.Windows.Forms.Button();
            this.gb_ipoints.SuspendLayout();
            this.gb_sprhitbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_ipoints
            // 
            this.gb_ipoints.Controls.Add(this.cb_wall);
            this.gb_ipoints.Controls.Add(this.cb_yoshi_big_l);
            this.gb_ipoints.Controls.Add(this.cb_yoshi_big_r);
            this.gb_ipoints.Controls.Add(this.cb_yoshi_small_l);
            this.gb_ipoints.Controls.Add(this.cb_yoshi_small_r);
            this.gb_ipoints.Controls.Add(this.cb_big_l);
            this.gb_ipoints.Controls.Add(this.cb_big_r);
            this.gb_ipoints.Controls.Add(this.cb_small_l);
            this.gb_ipoints.Controls.Add(this.cb_small_r);
            this.gb_ipoints.Location = new System.Drawing.Point(12, 12);
            this.gb_ipoints.Name = "gb_ipoints";
            this.gb_ipoints.Size = new System.Drawing.Size(242, 141);
            this.gb_ipoints.TabIndex = 0;
            this.gb_ipoints.TabStop = false;
            this.gb_ipoints.Text = "Interaction points";
            // 
            // cb_wall
            // 
            this.cb_wall.AutoSize = true;
            this.cb_wall.Checked = true;
            this.cb_wall.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_wall.Location = new System.Drawing.Point(75, 113);
            this.cb_wall.Name = "cb_wall";
            this.cb_wall.Size = new System.Drawing.Size(108, 17);
            this.cb_wall.TabIndex = 8;
            this.cb_wall.Text = "Running up wall?";
            this.cb_wall.UseVisualStyleBackColor = true;
            // 
            // cb_yoshi_big_l
            // 
            this.cb_yoshi_big_l.AutoSize = true;
            this.cb_yoshi_big_l.Checked = true;
            this.cb_yoshi_big_l.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_yoshi_big_l.Location = new System.Drawing.Point(138, 88);
            this.cb_yoshi_big_l.Name = "cb_yoshi_big_l";
            this.cb_yoshi_big_l.Size = new System.Drawing.Size(94, 17);
            this.cb_yoshi_big_l.TabIndex = 7;
            this.cb_yoshi_big_l.Text = "Big (yoshi, left)";
            this.cb_yoshi_big_l.UseVisualStyleBackColor = true;
            // 
            // cb_yoshi_big_r
            // 
            this.cb_yoshi_big_r.AutoSize = true;
            this.cb_yoshi_big_r.Checked = true;
            this.cb_yoshi_big_r.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_yoshi_big_r.Location = new System.Drawing.Point(138, 65);
            this.cb_yoshi_big_r.Name = "cb_yoshi_big_r";
            this.cb_yoshi_big_r.Size = new System.Drawing.Size(100, 17);
            this.cb_yoshi_big_r.TabIndex = 6;
            this.cb_yoshi_big_r.Text = "Big (yoshi, right)";
            this.cb_yoshi_big_r.UseVisualStyleBackColor = true;
            // 
            // cb_yoshi_small_l
            // 
            this.cb_yoshi_small_l.AutoSize = true;
            this.cb_yoshi_small_l.Checked = true;
            this.cb_yoshi_small_l.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_yoshi_small_l.Location = new System.Drawing.Point(15, 88);
            this.cb_yoshi_small_l.Name = "cb_yoshi_small_l";
            this.cb_yoshi_small_l.Size = new System.Drawing.Size(104, 17);
            this.cb_yoshi_small_l.TabIndex = 5;
            this.cb_yoshi_small_l.Text = "Small (yoshi, left)";
            this.cb_yoshi_small_l.UseVisualStyleBackColor = true;
            // 
            // cb_yoshi_small_r
            // 
            this.cb_yoshi_small_r.AutoSize = true;
            this.cb_yoshi_small_r.Checked = true;
            this.cb_yoshi_small_r.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_yoshi_small_r.Location = new System.Drawing.Point(15, 65);
            this.cb_yoshi_small_r.Name = "cb_yoshi_small_r";
            this.cb_yoshi_small_r.Size = new System.Drawing.Size(110, 17);
            this.cb_yoshi_small_r.TabIndex = 4;
            this.cb_yoshi_small_r.Text = "Small (yoshi, right)";
            this.cb_yoshi_small_r.UseVisualStyleBackColor = true;
            // 
            // cb_big_l
            // 
            this.cb_big_l.AutoSize = true;
            this.cb_big_l.Checked = true;
            this.cb_big_l.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_big_l.Location = new System.Drawing.Point(138, 42);
            this.cb_big_l.Name = "cb_big_l";
            this.cb_big_l.Size = new System.Drawing.Size(64, 17);
            this.cb_big_l.TabIndex = 3;
            this.cb_big_l.Text = "Big (left)";
            this.cb_big_l.UseVisualStyleBackColor = true;
            // 
            // cb_big_r
            // 
            this.cb_big_r.AutoSize = true;
            this.cb_big_r.Checked = true;
            this.cb_big_r.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_big_r.Location = new System.Drawing.Point(138, 19);
            this.cb_big_r.Name = "cb_big_r";
            this.cb_big_r.Size = new System.Drawing.Size(70, 17);
            this.cb_big_r.TabIndex = 2;
            this.cb_big_r.Text = "Big (right)";
            this.cb_big_r.UseVisualStyleBackColor = true;
            // 
            // cb_small_l
            // 
            this.cb_small_l.AutoSize = true;
            this.cb_small_l.Checked = true;
            this.cb_small_l.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_small_l.Location = new System.Drawing.Point(15, 42);
            this.cb_small_l.Name = "cb_small_l";
            this.cb_small_l.Size = new System.Drawing.Size(74, 17);
            this.cb_small_l.TabIndex = 1;
            this.cb_small_l.Text = "Small (left)";
            this.cb_small_l.UseVisualStyleBackColor = true;
            // 
            // cb_small_r
            // 
            this.cb_small_r.AutoSize = true;
            this.cb_small_r.Checked = true;
            this.cb_small_r.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_small_r.Location = new System.Drawing.Point(15, 19);
            this.cb_small_r.Name = "cb_small_r";
            this.cb_small_r.Size = new System.Drawing.Size(80, 17);
            this.cb_small_r.TabIndex = 0;
            this.cb_small_r.Text = "Small (right)";
            this.cb_small_r.UseVisualStyleBackColor = true;
            // 
            // gb_sprhitbox
            // 
            this.gb_sprhitbox.Controls.Add(this.cb_spr_yoshi_big);
            this.gb_sprhitbox.Controls.Add(this.cb_spr_big);
            this.gb_sprhitbox.Controls.Add(this.cb_spr_yoshi_small);
            this.gb_sprhitbox.Controls.Add(this.cb_spr_small);
            this.gb_sprhitbox.Location = new System.Drawing.Point(12, 159);
            this.gb_sprhitbox.Name = "gb_sprhitbox";
            this.gb_sprhitbox.Size = new System.Drawing.Size(242, 72);
            this.gb_sprhitbox.TabIndex = 8;
            this.gb_sprhitbox.TabStop = false;
            this.gb_sprhitbox.Text = "Sprite hitboxes";
            // 
            // cb_spr_yoshi_big
            // 
            this.cb_spr_yoshi_big.AutoSize = true;
            this.cb_spr_yoshi_big.Checked = true;
            this.cb_spr_yoshi_big.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_spr_yoshi_big.Location = new System.Drawing.Point(138, 42);
            this.cb_spr_yoshi_big.Name = "cb_spr_yoshi_big";
            this.cb_spr_yoshi_big.Size = new System.Drawing.Size(76, 17);
            this.cb_spr_yoshi_big.TabIndex = 3;
            this.cb_spr_yoshi_big.Text = "Big (Yoshi)";
            this.cb_spr_yoshi_big.UseVisualStyleBackColor = true;
            // 
            // cb_spr_big
            // 
            this.cb_spr_big.AutoSize = true;
            this.cb_spr_big.Checked = true;
            this.cb_spr_big.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_spr_big.Location = new System.Drawing.Point(138, 19);
            this.cb_spr_big.Name = "cb_spr_big";
            this.cb_spr_big.Size = new System.Drawing.Size(41, 17);
            this.cb_spr_big.TabIndex = 2;
            this.cb_spr_big.Text = "Big";
            this.cb_spr_big.UseVisualStyleBackColor = true;
            // 
            // cb_spr_yoshi_small
            // 
            this.cb_spr_yoshi_small.AutoSize = true;
            this.cb_spr_yoshi_small.Checked = true;
            this.cb_spr_yoshi_small.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_spr_yoshi_small.Location = new System.Drawing.Point(15, 42);
            this.cb_spr_yoshi_small.Name = "cb_spr_yoshi_small";
            this.cb_spr_yoshi_small.Size = new System.Drawing.Size(86, 17);
            this.cb_spr_yoshi_small.TabIndex = 1;
            this.cb_spr_yoshi_small.Text = "Small (Yoshi)";
            this.cb_spr_yoshi_small.UseVisualStyleBackColor = true;
            // 
            // cb_spr_small
            // 
            this.cb_spr_small.AutoSize = true;
            this.cb_spr_small.Checked = true;
            this.cb_spr_small.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_spr_small.Location = new System.Drawing.Point(15, 19);
            this.cb_spr_small.Name = "cb_spr_small";
            this.cb_spr_small.Size = new System.Drawing.Size(51, 17);
            this.cb_spr_small.TabIndex = 0;
            this.cb_spr_small.Text = "Small";
            this.cb_spr_small.UseVisualStyleBackColor = true;
            // 
            // btn_confirm
            // 
            this.btn_confirm.Location = new System.Drawing.Point(12, 237);
            this.btn_confirm.Name = "btn_confirm";
            this.btn_confirm.Size = new System.Drawing.Size(75, 23);
            this.btn_confirm.TabIndex = 9;
            this.btn_confirm.Text = "Confirm";
            this.btn_confirm.UseVisualStyleBackColor = true;
            this.btn_confirm.Click += new System.EventHandler(this.btn_confirm_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(179, 237);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_cancel.TabIndex = 10;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_uncheck
            // 
            this.btn_uncheck.Location = new System.Drawing.Point(93, 237);
            this.btn_uncheck.Name = "btn_uncheck";
            this.btn_uncheck.Size = new System.Drawing.Size(80, 23);
            this.btn_uncheck.TabIndex = 11;
            this.btn_uncheck.Text = "Uncheck all";
            this.btn_uncheck.UseVisualStyleBackColor = true;
            this.btn_uncheck.Click += new System.EventHandler(this.btn_uncheck_Click);
            // 
            // ImportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 266);
            this.Controls.Add(this.btn_uncheck);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_confirm);
            this.Controls.Add(this.gb_sprhitbox);
            this.Controls.Add(this.gb_ipoints);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ImportForm";
            this.Text = "Import Hitbox Info";
            this.gb_ipoints.ResumeLayout(false);
            this.gb_ipoints.PerformLayout();
            this.gb_sprhitbox.ResumeLayout(false);
            this.gb_sprhitbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_ipoints;
        private System.Windows.Forms.GroupBox gb_sprhitbox;
        private System.Windows.Forms.CheckBox cb_small_r;
        private System.Windows.Forms.CheckBox cb_big_l;
        private System.Windows.Forms.CheckBox cb_big_r;
        private System.Windows.Forms.CheckBox cb_small_l;
        private System.Windows.Forms.CheckBox cb_yoshi_small_l;
        private System.Windows.Forms.CheckBox cb_yoshi_small_r;
        private System.Windows.Forms.CheckBox cb_yoshi_big_l;
        private System.Windows.Forms.CheckBox cb_yoshi_big_r;
        private System.Windows.Forms.CheckBox cb_spr_yoshi_big;
        private System.Windows.Forms.CheckBox cb_spr_big;
        private System.Windows.Forms.CheckBox cb_spr_yoshi_small;
        private System.Windows.Forms.CheckBox cb_spr_small;
        private System.Windows.Forms.CheckBox cb_wall;
        private System.Windows.Forms.Button btn_confirm;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_uncheck;
    }
}
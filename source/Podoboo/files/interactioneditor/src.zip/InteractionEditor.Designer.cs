﻿namespace InteractionEditor
{
    partial class InteractionEditor
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Automatically generated code
        private void InitializeComponent()
        {
            this.gb_vis = new System.Windows.Forms.GroupBox();
            this.pb_points = new System.Windows.Forms.PictureBox();
            this.gb_hitbox = new System.Windows.Forms.GroupBox();
            this.lb_hitboxtype = new System.Windows.Forms.ListBox();
            this.ms_main = new System.Windows.Forms.MenuStrip();
            this.tsmi_file = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_open_file = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_open_template = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_patch = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_create_patch = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_create_file = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_settings = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_16bitsprite = new System.Windows.Forms.ToolStripMenuItem();
            this.gb_points = new System.Windows.Forms.GroupBox();
            this.rb_rfoot = new System.Windows.Forms.RadioButton();
            this.rb_lfoot = new System.Windows.Forms.RadioButton();
            this.rb_head = new System.Windows.Forms.RadioButton();
            this.rb_side_head = new System.Windows.Forms.RadioButton();
            this.rb_side_body = new System.Windows.Forms.RadioButton();
            this.rb_center = new System.Windows.Forms.RadioButton();
            this.gb_val = new System.Windows.Forms.GroupBox();
            this.btn_update = new System.Windows.Forms.Button();
            this.tb_height = new System.Windows.Forms.TextBox();
            this.lbl_height = new System.Windows.Forms.Label();
            this.tb_width = new System.Windows.Forms.TextBox();
            this.lbl_width = new System.Windows.Forms.Label();
            this.tb_Y = new System.Windows.Forms.TextBox();
            this.lbl_Y = new System.Windows.Forms.Label();
            this.tb_X = new System.Windows.Forms.TextBox();
            this.lbl_X = new System.Windows.Forms.Label();
            this.gb_vis.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_points)).BeginInit();
            this.gb_hitbox.SuspendLayout();
            this.ms_main.SuspendLayout();
            this.gb_points.SuspendLayout();
            this.gb_val.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_vis
            // 
            this.gb_vis.Controls.Add(this.pb_points);
            this.gb_vis.ForeColor = System.Drawing.Color.White;
            this.gb_vis.Location = new System.Drawing.Point(12, 26);
            this.gb_vis.Name = "gb_vis";
            this.gb_vis.Size = new System.Drawing.Size(218, 200);
            this.gb_vis.TabIndex = 0;
            this.gb_vis.TabStop = false;
            // 
            // pb_points
            // 
            this.pb_points.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pb_points.Location = new System.Drawing.Point(3, 16);
            this.pb_points.Name = "pb_points";
            this.pb_points.Size = new System.Drawing.Size(212, 181);
            this.pb_points.TabIndex = 1;
            this.pb_points.TabStop = false;
            // 
            // gb_hitbox
            // 
            this.gb_hitbox.Controls.Add(this.lb_hitboxtype);
            this.gb_hitbox.ForeColor = System.Drawing.Color.White;
            this.gb_hitbox.Location = new System.Drawing.Point(240, 26);
            this.gb_hitbox.Name = "gb_hitbox";
            this.gb_hitbox.Size = new System.Drawing.Size(244, 200);
            this.gb_hitbox.TabIndex = 1;
            this.gb_hitbox.TabStop = false;
            this.gb_hitbox.Text = "Interaction Points/Hitbox";
            // 
            // lb_hitboxtype
            // 
            this.lb_hitboxtype.BackColor = System.Drawing.Color.Black;
            this.lb_hitboxtype.ForeColor = System.Drawing.Color.White;
            this.lb_hitboxtype.FormattingEnabled = true;
            this.lb_hitboxtype.Items.AddRange(new object[] {
            "Small (right)",
            "Small (left)",
            "Big (right)",
            "Big (left)",
            "Small (Yoshi, right)",
            "Small (Yoshi, left)",
            "Big (Yoshi, right)",
            "Big (Yoshi, left)",
            "Running up wall?",
            "Sprite hitbox (Big)",
            "Sprite hitbox (Small)",
            "Sprite hitbox (Yoshi, big)",
            "Sprite hitbox (Yoshi, small)"});
            this.lb_hitboxtype.Location = new System.Drawing.Point(6, 19);
            this.lb_hitboxtype.Name = "lb_hitboxtype";
            this.lb_hitboxtype.Size = new System.Drawing.Size(232, 173);
            this.lb_hitboxtype.TabIndex = 0;
            this.lb_hitboxtype.SelectedIndexChanged += new System.EventHandler(this.lb_hitboxtype_SelectedIndexChanged);
            // 
            // ms_main
            // 
            this.ms_main.BackColor = System.Drawing.SystemColors.Control;
            this.ms_main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_file,
            this.tsmi_patch,
            this.tsmi_settings});
            this.ms_main.Location = new System.Drawing.Point(0, 0);
            this.ms_main.Name = "ms_main";
            this.ms_main.Size = new System.Drawing.Size(496, 24);
            this.ms_main.TabIndex = 2;
            // 
            // tsmi_file
            // 
            this.tsmi_file.BackColor = System.Drawing.SystemColors.Control;
            this.tsmi_file.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_open_file,
            this.tsmi_open_template});
            this.tsmi_file.ForeColor = System.Drawing.Color.Black;
            this.tsmi_file.Name = "tsmi_file";
            this.tsmi_file.Size = new System.Drawing.Size(37, 20);
            this.tsmi_file.Text = "File";
            // 
            // tsmi_open_file
            // 
            this.tsmi_open_file.Name = "tsmi_open_file";
            this.tsmi_open_file.Size = new System.Drawing.Size(162, 22);
            this.tsmi_open_file.Text = "Open Hitbox File";
            this.tsmi_open_file.Click += new System.EventHandler(this.tsmi_open_file_Click);
            // 
            // tsmi_open_template
            // 
            this.tsmi_open_template.Name = "tsmi_open_template";
            this.tsmi_open_template.Size = new System.Drawing.Size(165, 22);
            this.tsmi_open_template.Text = "Change template";
            this.tsmi_open_template.Click += new System.EventHandler(this.tsmi_open_template_Click);
            // 
            // tsmi_patch
            // 
            this.tsmi_patch.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_create_patch,
            this.tsmi_create_file});
            this.tsmi_patch.Name = "tsmi_patch";
            this.tsmi_patch.Size = new System.Drawing.Size(49, 20);
            this.tsmi_patch.Text = "Patch";
            // 
            // tsmi_create_patch
            // 
            this.tsmi_create_patch.Name = "tsmi_create_patch";
            this.tsmi_create_patch.Size = new System.Drawing.Size(141, 22);
            this.tsmi_create_patch.Text = "Create patch";
            this.tsmi_create_patch.Click += new System.EventHandler(this.tsmi_create_patch_Click);
            // 
            // tsmi_create_file
            // 
            this.tsmi_create_file.Name = "tsmi_create_file";
            this.tsmi_create_file.Size = new System.Drawing.Size(141, 22);
            this.tsmi_create_file.Text = "Create file";
            this.tsmi_create_file.Click += new System.EventHandler(this.tsmi_create_file_Click);
            // 
            // tsmi_settings
            // 
            this.tsmi_settings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_16bitsprite});
            this.tsmi_settings.Name = "tsmi_settings";
            this.tsmi_settings.Size = new System.Drawing.Size(61, 20);
            this.tsmi_settings.Text = "Settings";
            // 
            // tsmi_16bitsprite
            // 
            this.tsmi_16bitsprite.CheckOnClick = true;
            this.tsmi_16bitsprite.Name = "tsmi_16bitsprite";
            this.tsmi_16bitsprite.Size = new System.Drawing.Size(255, 22);
            this.tsmi_16bitsprite.Text = "16-bit Sprite hitbox";
            // 
            // gb_points
            // 
            this.gb_points.Controls.Add(this.rb_rfoot);
            this.gb_points.Controls.Add(this.rb_lfoot);
            this.gb_points.Controls.Add(this.rb_head);
            this.gb_points.Controls.Add(this.rb_side_head);
            this.gb_points.Controls.Add(this.rb_side_body);
            this.gb_points.Controls.Add(this.rb_center);
            this.gb_points.Location = new System.Drawing.Point(12, 232);
            this.gb_points.Name = "gb_points";
            this.gb_points.Size = new System.Drawing.Size(472, 35);
            this.gb_points.TabIndex = 3;
            this.gb_points.TabStop = false;
            // 
            // rb_rfoot
            // 
            this.rb_rfoot.AutoSize = true;
            this.rb_rfoot.ForeColor = System.Drawing.Color.Pink;
            this.rb_rfoot.Location = new System.Drawing.Point(375, 12);
            this.rb_rfoot.Name = "rb_rfoot";
            this.rb_rfoot.Size = new System.Drawing.Size(71, 17);
            this.rb_rfoot.TabIndex = 6;
            this.rb_rfoot.Text = "Right foot";
            this.rb_rfoot.UseVisualStyleBackColor = true;
            this.rb_rfoot.CheckedChanged += new System.EventHandler(this.rb_rfoot_CheckedChanged);
            // 
            // rb_lfoot
            // 
            this.rb_lfoot.AutoSize = true;
            this.rb_lfoot.ForeColor = System.Drawing.Color.Lime;
            this.rb_lfoot.Location = new System.Drawing.Point(305, 12);
            this.rb_lfoot.Name = "rb_lfoot";
            this.rb_lfoot.Size = new System.Drawing.Size(64, 17);
            this.rb_lfoot.TabIndex = 5;
            this.rb_lfoot.Text = "Left foot";
            this.rb_lfoot.UseVisualStyleBackColor = true;
            this.rb_lfoot.CheckedChanged += new System.EventHandler(this.rb_lfoot_CheckedChanged);
            // 
            // rb_head
            // 
            this.rb_head.AutoSize = true;
            this.rb_head.ForeColor = System.Drawing.Color.Yellow;
            this.rb_head.Location = new System.Drawing.Point(248, 12);
            this.rb_head.Name = "rb_head";
            this.rb_head.Size = new System.Drawing.Size(51, 17);
            this.rb_head.TabIndex = 4;
            this.rb_head.Text = "Head";
            this.rb_head.UseVisualStyleBackColor = true;
            this.rb_head.CheckedChanged += new System.EventHandler(this.rb_head_CheckedChanged);
            // 
            // rb_side_head
            // 
            this.rb_side_head.AutoSize = true;
            this.rb_side_head.ForeColor = System.Drawing.Color.Red;
            this.rb_side_head.Location = new System.Drawing.Point(169, 12);
            this.rb_side_head.Name = "rb_side_head";
            this.rb_side_head.Size = new System.Drawing.Size(73, 17);
            this.rb_side_head.TabIndex = 2;
            this.rb_side_head.Text = "Side head";
            this.rb_side_head.UseVisualStyleBackColor = true;
            this.rb_side_head.CheckedChanged += new System.EventHandler(this.rb_side_head_CheckedChanged);
            // 
            // rb_side_body
            // 
            this.rb_side_body.AutoSize = true;
            this.rb_side_body.ForeColor = System.Drawing.Color.Orange;
            this.rb_side_body.Location = new System.Drawing.Point(91, 12);
            this.rb_side_body.Name = "rb_side_body";
            this.rb_side_body.Size = new System.Drawing.Size(72, 17);
            this.rb_side_body.TabIndex = 1;
            this.rb_side_body.Text = "Side body";
            this.rb_side_body.UseVisualStyleBackColor = true;
            this.rb_side_body.CheckedChanged += new System.EventHandler(this.rb_side_body_CheckedChanged);
            // 
            // rb_center
            // 
            this.rb_center.AutoSize = true;
            this.rb_center.Checked = true;
            this.rb_center.ForeColor = System.Drawing.Color.White;
            this.rb_center.Location = new System.Drawing.Point(29, 12);
            this.rb_center.Name = "rb_center";
            this.rb_center.Size = new System.Drawing.Size(56, 17);
            this.rb_center.TabIndex = 0;
            this.rb_center.TabStop = true;
            this.rb_center.Text = "Center";
            this.rb_center.UseVisualStyleBackColor = true;
            this.rb_center.CheckedChanged += new System.EventHandler(this.rb_center_CheckedChanged);
            // 
            // gb_val
            // 
            this.gb_val.Controls.Add(this.btn_update);
            this.gb_val.Controls.Add(this.tb_height);
            this.gb_val.Controls.Add(this.lbl_height);
            this.gb_val.Controls.Add(this.tb_width);
            this.gb_val.Controls.Add(this.lbl_width);
            this.gb_val.Controls.Add(this.tb_Y);
            this.gb_val.Controls.Add(this.lbl_Y);
            this.gb_val.Controls.Add(this.tb_X);
            this.gb_val.Controls.Add(this.lbl_X);
            this.gb_val.ForeColor = System.Drawing.Color.White;
            this.gb_val.Location = new System.Drawing.Point(12, 273);
            this.gb_val.Name = "gb_val";
            this.gb_val.Size = new System.Drawing.Size(472, 49);
            this.gb_val.TabIndex = 4;
            this.gb_val.TabStop = false;
            // 
            // btn_update
            // 
            this.btn_update.ForeColor = System.Drawing.Color.Black;
            this.btn_update.Location = new System.Drawing.Point(197, 16);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 9;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // tb_height
            // 
            this.tb_height.BackColor = System.Drawing.Color.Black;
            this.tb_height.ForeColor = System.Drawing.Color.White;
            this.tb_height.Location = new System.Drawing.Point(446, 18);
            this.tb_height.MaxLength = 2;
            this.tb_height.Name = "tb_height";
            this.tb_height.Size = new System.Drawing.Size(20, 20);
            this.tb_height.TabIndex = 8;
            this.tb_height.Text = "00";
            // 
            // lbl_height
            // 
            this.lbl_height.AutoSize = true;
            this.lbl_height.Location = new System.Drawing.Point(396, 21);
            this.lbl_height.Name = "lbl_height";
            this.lbl_height.Size = new System.Drawing.Size(47, 13);
            this.lbl_height.TabIndex = 7;
            this.lbl_height.Text = "Height =";
            // 
            // tb_width
            // 
            this.tb_width.BackColor = System.Drawing.Color.Black;
            this.tb_width.ForeColor = System.Drawing.Color.White;
            this.tb_width.Location = new System.Drawing.Point(370, 18);
            this.tb_width.MaxLength = 2;
            this.tb_width.Name = "tb_width";
            this.tb_width.Size = new System.Drawing.Size(20, 20);
            this.tb_width.TabIndex = 6;
            this.tb_width.Text = "00";
            // 
            // lbl_width
            // 
            this.lbl_width.AutoSize = true;
            this.lbl_width.Location = new System.Drawing.Point(320, 21);
            this.lbl_width.Name = "lbl_width";
            this.lbl_width.Size = new System.Drawing.Size(44, 13);
            this.lbl_width.TabIndex = 5;
            this.lbl_width.Text = "Width =";
            // 
            // tb_Y
            // 
            this.tb_Y.BackColor = System.Drawing.Color.Black;
            this.tb_Y.ForeColor = System.Drawing.Color.White;
            this.tb_Y.Location = new System.Drawing.Point(103, 18);
            this.tb_Y.MaxLength = 4;
            this.tb_Y.Name = "tb_Y";
            this.tb_Y.Size = new System.Drawing.Size(32, 20);
            this.tb_Y.TabIndex = 3;
            this.tb_Y.Text = "0000";
            // 
            // lbl_Y
            // 
            this.lbl_Y.AutoSize = true;
            this.lbl_Y.Location = new System.Drawing.Point(74, 21);
            this.lbl_Y.Name = "lbl_Y";
            this.lbl_Y.Size = new System.Drawing.Size(23, 13);
            this.lbl_Y.TabIndex = 2;
            this.lbl_Y.Text = "Y =";
            // 
            // tb_X
            // 
            this.tb_X.BackColor = System.Drawing.Color.Black;
            this.tb_X.ForeColor = System.Drawing.Color.White;
            this.tb_X.Location = new System.Drawing.Point(35, 18);
            this.tb_X.MaxLength = 4;
            this.tb_X.Name = "tb_X";
            this.tb_X.Size = new System.Drawing.Size(32, 20);
            this.tb_X.TabIndex = 1;
            this.tb_X.Text = "0000";
            // 
            // lbl_X
            // 
            this.lbl_X.AutoSize = true;
            this.lbl_X.Location = new System.Drawing.Point(6, 21);
            this.lbl_X.Name = "lbl_X";
            this.lbl_X.Size = new System.Drawing.Size(23, 13);
            this.lbl_X.TabIndex = 0;
            this.lbl_X.Text = "X =";
            // 
            // InteractionEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(496, 333);
            this.Controls.Add(this.gb_val);
            this.Controls.Add(this.gb_points);
            this.Controls.Add(this.gb_hitbox);
            this.Controls.Add(this.gb_vis);
            this.Controls.Add(this.ms_main);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.ms_main;
            this.MaximizeBox = false;
            this.Name = "InteractionEditor";
            this.ShowIcon = false;
            this.Text = "Player hitbox editor by TheBiob";
            this.gb_vis.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_points)).EndInit();
            this.gb_hitbox.ResumeLayout(false);
            this.ms_main.ResumeLayout(false);
            this.ms_main.PerformLayout();
            this.gb_points.ResumeLayout(false);
            this.gb_points.PerformLayout();
            this.gb_val.ResumeLayout(false);
            this.gb_val.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_vis;
        private System.Windows.Forms.GroupBox gb_hitbox;
        private System.Windows.Forms.ListBox lb_hitboxtype;
        private System.Windows.Forms.MenuStrip ms_main;
        private System.Windows.Forms.ToolStripMenuItem tsmi_file;
        private System.Windows.Forms.ToolStripMenuItem tsmi_patch;
        private System.Windows.Forms.ToolStripMenuItem tsmi_create_patch;
        private System.Windows.Forms.ToolStripMenuItem tsmi_create_file;
        private System.Windows.Forms.ToolStripMenuItem tsmi_open_file;
        private System.Windows.Forms.GroupBox gb_points;
        private System.Windows.Forms.RadioButton rb_center;
        private System.Windows.Forms.RadioButton rb_side_body;
        private System.Windows.Forms.RadioButton rb_side_head;
        private System.Windows.Forms.RadioButton rb_lfoot;
        private System.Windows.Forms.RadioButton rb_head;
        private System.Windows.Forms.RadioButton rb_rfoot;
        private System.Windows.Forms.PictureBox pb_points;
        private System.Windows.Forms.ToolStripMenuItem tsmi_settings;
        private System.Windows.Forms.ToolStripMenuItem tsmi_16bitsprite;
        private System.Windows.Forms.ToolStripMenuItem tsmi_open_template;
        private System.Windows.Forms.GroupBox gb_val;
        private System.Windows.Forms.TextBox tb_X;
        private System.Windows.Forms.Label lbl_X;
        private System.Windows.Forms.TextBox tb_Y;
        private System.Windows.Forms.Label lbl_Y;
        private System.Windows.Forms.TextBox tb_height;
        private System.Windows.Forms.Label lbl_height;
        private System.Windows.Forms.TextBox tb_width;
        private System.Windows.Forms.Label lbl_width;
        private System.Windows.Forms.Button btn_update;
    }
}


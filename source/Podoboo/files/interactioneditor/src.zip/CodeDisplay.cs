﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace InteractionEditor {
    public partial class CodeDisplay : Form {
        public CodeDisplay(string[] code) {
            InitializeComponent();
            string n = "";
            foreach (string s in code)
                n += s + "\n";
            rtb_code.Text = n;
        }

        private void btn_save_Click(object sender, EventArgs e) {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "ASM files | *.asm";
            if (sfd.ShowDialog() == DialogResult.OK)
                File.WriteAllText(sfd.FileName, rtb_code.Text);
        }
    }
}

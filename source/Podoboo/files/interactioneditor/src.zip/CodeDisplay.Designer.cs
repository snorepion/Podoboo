﻿namespace InteractionEditor
{
    partial class CodeDisplay
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Automatically generated code
		
        private void InitializeComponent()
        {
            this.rtb_code = new System.Windows.Forms.RichTextBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtb_code
            // 
            this.rtb_code.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_code.Location = new System.Drawing.Point(0, 0);
            this.rtb_code.Name = "rtb_code";
            this.rtb_code.ReadOnly = true;
            this.rtb_code.Size = new System.Drawing.Size(384, 362);
            this.rtb_code.TabIndex = 0;
            this.rtb_code.Text = "";
            // 
            // btn_save
            // 
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Location = new System.Drawing.Point(291, 12);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(59, 26);
            this.btn_save.TabIndex = 1;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // CodeDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 362);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.rtb_code);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "CodeDisplay";
            this.ShowIcon = false;
            this.Text = "Code";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtb_code;
        private System.Windows.Forms.Button btn_save;
    }
}
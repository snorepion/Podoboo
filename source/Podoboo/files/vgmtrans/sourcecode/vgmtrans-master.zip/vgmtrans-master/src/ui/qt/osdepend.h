#ifndef OSDEPEND_H
#define OSDEPEND_H

void Alert(const wchar_t *fmt, ...);
void LogDebug(const wchar_t *fmt, ...);

#endif // OSDEPEND_H

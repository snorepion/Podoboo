#pragma once
#include "Format.h"
#include "Root.h"
#include "VGMColl.h"
#include "QSoundScanner.h"


BEGIN_FORMAT(QSound)
	USING_SCANNER(QSoundScanner)
END_FORMAT()


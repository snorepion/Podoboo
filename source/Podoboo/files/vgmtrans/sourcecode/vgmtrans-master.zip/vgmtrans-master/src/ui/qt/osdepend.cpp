#pragma once

#include "osdepend.h"

void Alert(const wchar_t *fmt, ...)
{

}

void LogDebug(const wchar_t *fmt, ...)
{

}

#pragma once

#if defined(_MSC_VER)

#include <windows.h>

enum {
	PATH_MAX = MAX_PATH
};

#endif

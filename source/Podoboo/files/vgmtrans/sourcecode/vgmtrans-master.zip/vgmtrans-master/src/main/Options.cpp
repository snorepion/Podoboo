#include "pch.h"
#include "Options.h"

int ConversionOptions::numSequenceLoops = 1;

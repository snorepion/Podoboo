#pragma once
#include "Format.h"
#include "Root.h"
#include "VGMColl.h"
#include "KonamiGXScanner.h"


BEGIN_FORMAT(KonamiGX)
	USING_SCANNER(KonamiGXScanner)
END_FORMAT()


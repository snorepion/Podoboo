#ifdef _WIN32
	#include "stdafx.h"
#endif
#include "ToggleView.h"

ToggleView::ToggleView(void)
{
}

ToggleView::~ToggleView(void)
{
}
